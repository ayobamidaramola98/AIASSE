export EPSRbin=/home/ayobami/EPSR/AIASSE/EPSR25-2017-10/EPSR/bin/
export EPSRrun=/home/ayobami/EPSR/AIASSE/Test/Large_box/Large/
while :
do
  "$EPSRbin"'epsr' "$EPSRrun" epsr Largebox
  if ([ -e "$EPSRrun"killepsr ])
  then break
  fi
done
rm -r "$EPSRrun"killepsr
