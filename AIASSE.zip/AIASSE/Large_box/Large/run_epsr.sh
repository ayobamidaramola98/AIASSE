#!/bin/bash

# Ensure the directory exists
mkdir -p Accumulation_dependence
startAcc=100

# Set the base directory to the location of this script
base_dir="$(cd "$(dirname "$0")" && pwd)"

# Copy epsr25 from the base directory to Accumulation_dependence
epsr25_source="$base_dir/epsr25"
cp "$epsr25_source" "$base_dir/Accumulation_dependence/epsr25"

# Create the DFT box folder inside Accumulation_dependence
dft_box_dir="$base_dir/Accumulation_dependence/DFT_box"
mkdir -p "$dft_box_dir"

# Start the accumulation checking loop in the background
(
    while true; do
        line=$(grep 'nsumt' *.EPSR.inp)
        set -- $line
        AccNum=$2

        # Check if the accumulation number matches the startAcc
        if [ "$AccNum" -eq "$startAcc" ]; then

            # Check if files are being written
            while lsof *.EPSR.g01 *.EPSR.z01 *box.ato >/dev/null; do
                sleep 1
            done

            # Copy the files
            cp *.EPSR.g01 Accumulation_dependence/"${AccNum}acc.g01" &
            cp *.EPSR.z01 Accumulation_dependence/"${AccNum}acc.z01" &
            cp *box.ato Accumulation_dependence/"${AccNum}acc.ato" &

            # Wait for all copy operations to finish
            wait

            # Increment the startAcc for the next cycle
            startAcc=$((startAcc + 100))
        fi
    done
) &  # Run this in the background

# Wait for the accumulation loop to complete, if necessary
wait

