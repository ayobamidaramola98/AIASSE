import os
import pty
import select
import shutil
import os
import pty
import select
import shutil
import threading
import random
import subprocess
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QTextEdit, QLineEdit, QMessageBox, QMainWindow, QFileDialog, QAction, QMenu, QLabel, QStatusBar

from PyQt5.QtCore import QThread, pyqtSignal


# Thread class to run EPSR in a separate thread without showing output in the GUI
class RunEpsrThread(QThread):
    finished_signal = QtCore.pyqtSignal(int, str)  # Signal to indicate process finished

    def __init__(self, epsr_path, parent=None):
        super().__init__(parent)
        self.epsr_path = epsr_path

    def run(self):
        try:
            os.makedirs("Large_box", exist_ok=True)
            process = subprocess.Popen(
                [self.epsr_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            process.wait()  # Wait for process to finish
            self.finished_signal.emit(process.returncode, "EPSR process finished")
        except Exception as e:
            self.finished_signal.emit(-1, f"Error running EPSR: {str(e)}")


# Main window class for the GUI
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setWindowTitle("AIASSE version 1.0 by Ayobami and Cip")

        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.gridLayout = QtWidgets.QGridLayout(self.centralWidget)

        # Menu bar
        self.menuBar = QtWidgets.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 800, 22))
        self.menuSettings = QtWidgets.QMenu(self.menuBar)
        self.menuDocumentation = QtWidgets.QMenu(self.menuBar)
        MainWindow.setMenuBar(self.menuBar)
        self.menuBar.addAction(self.menuSettings.menuAction())
        self.menuBar.addAction(self.menuDocumentation.menuAction())
        self.menuSettings.setTitle("Settings")
        self.menuDocumentation.setTitle("Documentation")

        # Settings Menu Actions
        self.setEpsrPathAction = QAction("Set EPSR Path", MainWindow)
        self.setCp2kPathAction = QAction("Set CP2K Path", MainWindow)
        self.setCastepPathAction = QAction("Set CASTEP Path", MainWindow)
        self.menuSettings.addAction(self.setEpsrPathAction)
        self.menuSettings.addAction(self.setCp2kPathAction)
        self.menuSettings.addAction(self.setCastepPathAction)

        # Button layout
        self.buttonLayout = QtWidgets.QHBoxLayout()

        # Run Large Box button
        self.runLargeBoxButton = QtWidgets.QPushButton("Run Large Box", self.centralWidget)
        self.runLargeBoxMenu = QtWidgets.QMenu(self.runLargeBoxButton)
        self.transferfilesAction = QAction("Transfer Files", MainWindow)
        self.deleteLargeBoxAction = QAction("Delete Large Box", MainWindow)
        self.extractLargeBoxAction = QAction("Extract DFT Box", MainWindow)
        self.stopExtractButton = QAction("Stop Extracting Large Box", MainWindow)
        self.runLargeBoxMenu.addAction(self.transferfilesAction)
        self.runLargeBoxMenu.addAction(self.deleteLargeBoxAction)
        self.runLargeBoxMenu.addAction(self.extractLargeBoxAction)
        self.runLargeBoxMenu.addAction(self.stopExtractButton)
        self.runLargeBoxButton.setMenu(self.runLargeBoxMenu)
        self.buttonLayout.addWidget(self.runLargeBoxButton)

        # Run Small Box button
        self.runSmallBoxButton = QtWidgets.QPushButton("Run Small Box", self.centralWidget)
        self.runSmallBoxMenu = QtWidgets.QMenu(self.runSmallBoxButton)
        self.createBoxButton = QAction("Create Box", MainWindow)
        self.deleteSmallBoxAction = QAction("Delete Small Box", MainWindow)
        self.runSmallBoxMenu.addAction(self.createBoxButton)
        self.runSmallBoxMenu.addAction(self.deleteSmallBoxAction)
        self.runSmallBoxButton.setMenu(self.runSmallBoxMenu)
        self.buttonLayout.addWidget(self.runSmallBoxButton)

        # DFT Setup Button
        self.dftSetupButton = QtWidgets.QPushButton("DFT Setup", self.centralWidget)
        self.buttonLayout.addWidget(self.dftSetupButton)

        # Add button layout
        self.gridLayout.addLayout(self.buttonLayout, 0, 0, 1, 1)

        # Container widget for EPSR outputs (removed real-time output display)
        self.outputTextEdit = QTextEdit(self.centralWidget)
        self.gridLayout.addWidget(self.outputTextEdit, 1, 0, 1, 1)

        # Set up central widget and status bar
        MainWindow.setCentralWidget(self.centralWidget)
        self.statusbar = QStatusBar(MainWindow)
        MainWindow.setStatusBar(self.statusbar)

        # Version label at the bottom of the window
        self.versionLabel = QLabel(self.centralWidget)
        self.versionLabel.setText("AIASSE version 1.0")
        self.versionLabel.setGeometry(QtCore.QRect(10, MainWindow.height() - 30, 200, 20))

        # Connect actions to functions
        self.setEpsrPathAction.triggered.connect(lambda: self.set_executable_path("epsr"))
        self.setCp2kPathAction.triggered.connect(lambda: self.set_executable_path("cp2k"))
        self.setCastepPathAction.triggered.connect(lambda: self.set_executable_path("castep"))
        self.transferfilesAction.triggered.connect(self.transfer_files)
        self.deleteLargeBoxAction.triggered.connect(self.delete_large_box)
        self.extractLargeBoxAction.triggered.connect(self.extract_large_box)
        self.createBoxButton.triggered.connect(self.create_box)
        self.deleteSmallBoxAction.triggered.connect(self.delete_small_box)
        self.runLargeBoxButton.clicked.connect(self.run_large_box)
        self.runSmallBoxButton.clicked.connect(self.run_small_box)
        self.dftSetupButton.clicked.connect(self.dft_setup)

        # Paths and thread attributes
        self.epsr_path = None
        self.cp2k_path = None
        self.castep_path = None
        self.epsr_thread = None

        MainWindow.resizeEvent = self.resize_event

    def resize_event(self, event):
        self.versionLabel.move(10, event.size().height() - 30)
        super(Ui_MainWindow, self.centralWidget).resizeEvent(event)

    def set_executable_path(self, exec_type):
        options = QFileDialog.Options()
        options |= QFileDialog.ReadOnly
        fileName, _ = QFileDialog.getOpenFileName(None, "Select Executable", "", "Executables (*);;All Files (*)", options=options)

        if fileName:
            if exec_type == "epsr":
                self.epsr_path = fileName
                self.statusbar.showMessage(f"EPSR path set to: {fileName}")
                # Run EPSR immediately
                self.run_large_box()
            elif exec_type == "cp2k":
                self.cp2k_path = fileName
                self.statusbar.showMessage(f"CP2K path set to: {fileName}")
            elif exec_type == "castep":
                self.castep_path = fileName
                self.statusbar.showMessage(f"CASTEP path set to: {fileName}")

    def show_error_dialog(self, message):
        msgBox = QMessageBox()
        msgBox.setIcon(QMessageBox.Critical)
        msgBox.setText(message)
        msgBox.setWindowTitle("Error")
        msgBox.setStandardButtons(QMessageBox.Ok)
        msgBox.exec_()

    def run_large_box(self):
        if not self.epsr_path:
            self.show_error_dialog("EPSR path is not set. Please set it in the Settings menu.")
            return

        if not os.path.isfile(self.epsr_path):
            self.show_error_dialog(f"EPSR path is not valid: {self.epsr_path}")
            return

        # Start the EPSR process in a separate thread without real-time output display
        self.epsr_thread = RunEpsrThread(self.epsr_path)
        self.epsr_thread.finished_signal.connect(self.on_epsr_process_finished)
        self.epsr_thread.start()

    def on_epsr_process_finished(self, exit_code, message):
        if exit_code == 0:
            self.statusbar.showMessage("EPSR process completed successfully.")
        else:
            self.statusbar.showMessage(f"EPSR process finished with errors. Exit code: {exit_code}")


    def runSmallBox(self):
        # Create Small_box and Small directories
        if not os.path.exists('Small_box'):
            os.makedirs('Small_box/Small')


        print("Small box setup complete.")        
   
    def delete_large_box(self):
        folder_path = 'Large_box'
        if os.path.exists(folder_path):
            shutil.rmtree(folder_path)
            print(f'{folder_path} deleted successfully.')
        else:
            print(f'{folder_path} does not exist.')

    def delete_small_box(self):
        folder_path = 'Small_box'
        if os.path.exists(folder_path):
            shutil.rmtree(folder_path)
            print(f'{folder_path} deleted successfully.')
        else:
            print(f'{folder_path} does not exist.')
    
    def transfer_files(self):
        source_folder = 'Large_box/Large'
        destination_folder = 'Small_box/Small'
    
        if not os.path.exists(destination_folder):
            os.makedirs(destination_folder)
    
        files_to_modify = {
            'Largebox.EPSR.p01': 'Smallbox.EPSR.p01',
            'Largebox.EPSR.inp': 'Smallbox.EPSR.inp',
            'Large.ato': 'Small.ato',
            'Largebox.pcof': 'Smallbox.pcof',
            'Large.mol': 'Small.mol',
            'Large.EPSR.pro': 'Small.EPSR.pro',
            'Large.jmol': 'Small.jmol',
        }
    
        for filename, new_filename in files_to_modify.items():
            source_file = os.path.join(source_folder, filename)
            destination_file = os.path.join(destination_folder, new_filename)
        
            if os.path.exists(source_file) and 'Largebox.ato' not in filename:
                # Copy the file
                shutil.copyfile(source_file, destination_file)
                
                # Modify the file content if needed
                if filename == 'Largebox.EPSR.inp':
                    self.modify_epsr_inp(destination_file)
            
                if filename == 'Large.EPSR.pro':
                    self.modify_epsr_pro(destination_file)
                
                # Set the file to read-only if it's .EPSR.p01
                if filename == 'Largebox.EPSR.p01':
                    os.chmod(destination_file, 0o444)  # read-only
                
                print(f'File {filename} copied and renamed to {new_filename}')
    
        # Transfer additional files without modification
        additional_files = ['.mint01', '.NWTStot.wts']
        for filename in os.listdir(source_folder):
            if any(filename.endswith(ext) for ext in additional_files):
                source_file = os.path.join(source_folder, filename)
                destination_file = os.path.join(destination_folder, filename)
                
                # Copy the file
                shutil.copyfile(source_file, destination_file)
                print(f'File {filename} copied to {destination_folder}')

    def modify_epsr_inp(self, filepath):
        with open(filepath, 'r+') as file:
            content = file.read()
            content = content.replace('Largebox.EPSR', 'Smallbox.EPSR')
            content = content.replace('fnameato    Largebox.ato', 'fnameato    Smallbox.ato')
            content = content.replace('fnamepcof   Largebox.pcof', 'fnamepcof   Smallbox.pcof')
            content = content.replace('potfac      1.0', 'potfac      0.0')
            content = content.replace('nsumt       -1', 'nsumt       0')
            
            # Move the pointer to the beginning of the file and overwrite it
            file.seek(0)
            file.write(content)
            file.truncate()

    def modify_epsr_pro(self, filepath):
        with open(filepath, 'r+') as file:
            content = file.read()
            content = content.replace('mol Large.mol 1000', 'mol Small.mol 150')
            content = content.replace('boxAtoFileName Largebox.ato', 'boxAtoFileName Smallbox.ato')
            content = content.replace('data 5 SLS72899.mint01 0', 'data 5 SLS72899.mint01 0')
            content = content.replace('wts SLS72899.NWTStot.wts', 'wts SLS72899.NWTStot.wts') 
            content = content.replace('EPSRinp Largebox', 'EPSRinp Smallbox')
          
            # Move the pointer to the beginning of the file and overwrite it
            file.seek(0)
            file.write(content)
            file.truncate()


    def run_shell_script(self, script_path, cwd):
        try:
            # Run the shell script using 'expect'
            process = subprocess.Popen(
                ['expect', script_path],
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout, stderr = process.communicate()

            # Display output and errors
            if stdout:
                self.outputTextEdit.append(f"Output: {stdout.decode()}")
            if stderr:
                self.outputTextEdit.append(f"Error: {stderr.decode()}")

        except Exception as e:
            self.show_error_dialog(f"Error occurred: {e}")

    def create_box(self):
        small_box_dir = os.path.join("Small_box", "Small")
        epsr25_file = "epsr25"
        shell_script_file = "shell.sh"

        dest_epsr25_file = os.path.join(small_box_dir, epsr25_file)
        dest_shell_script_file = os.path.join(small_box_dir, shell_script_file)

        try:
            # Ensure the directory exists
            if not os.path.exists(small_box_dir):
                os.makedirs(small_box_dir)

            # Copy files
            shutil.copy(epsr25_file, dest_epsr25_file)
            shutil.copy(shell_script_file, dest_shell_script_file)

            # Make the files executable
            os.chmod(dest_epsr25_file, 0o755)
            os.chmod(dest_shell_script_file, 0o755)

            # Debug prints to verify file presence and paths
            if not os.path.isfile(dest_epsr25_file):
                self.show_error_dialog(f"File '{dest_epsr25_file}' not found after copy.")
            if not os.path.isfile(dest_shell_script_file):
                self.show_error_dialog(f"File '{dest_shell_script_file}' not found after copy.")
            
            self.outputTextEdit.append(f"Files '{epsr25_file}' and '{shell_script_file}' successfully copied to '{small_box_dir}'.")

            # Print the current working directory for debugging
            self.outputTextEdit.append(f"Current working directory: {os.getcwd()}")
            
            # Print files in the target directory
            self.outputTextEdit.append(f"Files in '{small_box_dir}': {os.listdir(small_box_dir)}")

            # Run the shell script in a separate thread
            script_thread = threading.Thread(
                target=self.run_shell_script,
                args=(shell_script_file, small_box_dir)
            )
            script_thread.start()

        except Exception as e:
            self.show_error_dialog(f"Error occurred: {e}")


    def read_output(self):
        output = self.process.readAllStandardOutput().data().decode()
        self.outputTextEdit.append(output)

    def send_command(self):
        command = self.inputLineEdit.text().strip()
        if self.process and self.process.state() == QtCore.QProcess.Running:
            self.process.write((command + '\n').encode())
            self.inputLineEdit.clear()
        else:
            self.outputTextEdit.append("No active process to send command to.")

    def on_epsr_process_finished(self, exit_code, exit_status):
        if exit_code == 0:
            self.outputTextEdit.append("EPSR file execution completed successfully.")
        else:
            self.outputTextEdit.append(f"EPSR process finished with exit code {exit_code} and status {exit_status}")

    def run_small_box(self):
        os.makedirs("Small_box", exist_ok=True)
        self.outputTextEdit.append("Created directory: Small_box")
        self.outputTextEdit.append("Run Small Box button clicked.")
        # Implement the functionality to run small box here

    def dft_setup(self):
        self.outputTextEdit.append("DFT Setup button clicked.")
        # Implement the functionality for DFT setup here

    def extract_large_box(self):
        large_dir = "Large_box/Large"
        
        # Ensure the Large directory exists
        if not os.path.exists(large_dir):
            self.show_error_dialog(f"Directory does not exist: {large_dir}")
            return

        # Define the script path in the current directory
        script_source_path = "run_epsr.sh"
        
        # Define the destination script path in the Large directory
        script_destination_path = os.path.join(large_dir, "run_epsr.sh")
        
        # Check if the source script file exists
        if not os.path.isfile(script_source_path):
            self.show_error_dialog(f"Script file does not exist: {script_source_path}")
            return

        # Copy the script file to the Large directory
        shutil.copy(script_source_path, script_destination_path)

        # Make the script executable
        os.chmod(script_destination_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(large_dir)  # Set working directory to the Large directory
        self.extract_process.setProgram("/bin/bash")
        self.extract_process.setArguments([f"./run_epsr.sh"])
        self.extract_process.start()

        # Connect signals to handle output and completion
        self.extract_process.readyReadStandardOutput.connect(lambda: self.outputTextEdit.append(self.extract_process.readAllStandardOutput().data().decode()))
        self.extract_process.readyReadStandardError.connect(lambda: self.outputTextEdit.append(f"Error: {self.extract_process.readAllStandardError().data().decode()}"))
        self.extract_process.finished.connect(self.on_extraction_finished)

    def on_extraction_finished(self, exit_code, exit_status):
        self.outputTextEdit.append(f"Extraction script finished with exit code {exit_code} and status {exit_status}")
        
        # Check if the expected folder was created
        expected_folder = os.path.join("Large_box/Large", "accumulation_dependence")
        if os.path.exists(expected_folder):
            self.outputTextEdit.append(f"Success: {expected_folder} was created.")
        else:
            self.outputTextEdit.append(f"Error: {expected_folder} was not created. Check the script output for details.")

    def stop_extracting_large_box(self):
        if hasattr(self, 'extract_process') and self.extract_process.state() == QtCore.QProcess.Running:
            self.extract_process.terminate()
            self.outputTextEdit.append("Extraction script terminated")

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

