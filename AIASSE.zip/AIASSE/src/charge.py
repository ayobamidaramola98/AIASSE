import os
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from PyQt5.QtCore import QObject, pyqtSignal

class ChargeCalculator(QObject):
    charge_figures_signal = pyqtSignal(list)  # Signal to send figures back to the GUI
    log_signal = pyqtSignal(str)  # Signal to send log messages

    def __init__(self, cp2k_directory):
        super().__init__()
        self.cp2k_directory = cp2k_directory

    def process_last_mulliken_data(self, file_path):
        """Process the last Mulliken population analysis data from a file."""
        try:
            with open(file_path, 'r') as file:
                file_content = file.readlines()

            # Extract total charge from the relevant line
            total_charge_lines = [line for line in file_content if "# Total charge" in line]
            if not total_charge_lines:
                raise ValueError("No 'Total charge' line found in the file.")

            total_charge_line = total_charge_lines[-1]
            total_charge = float(total_charge_line.split()[-1])  # Extract the last value (sum of charges)

            # Identify the last Mulliken Population Analysis section
            section_indices = [i for i, line in enumerate(file_content) if "Mulliken Population Analysis" in line]
            if not section_indices:
                raise ValueError("No Mulliken Population Analysis section found in the file.")

            last_section_index = section_indices[-1]
            data_lines = file_content[last_section_index + 1:]

            data = []
            for line in data_lines:
                if line.strip() and not line.startswith("#"):
                    parts = line.split()
                    try:
                        atom = int(parts[0])
                        element = parts[1]
                        kind = int(parts[2])
                        atomic_population = float(parts[3])
                        net_charge = float(parts[4])
                        data.append((atom, element, kind, atomic_population, net_charge))
                    except (ValueError, IndexError):
                        continue

            columns = ["Atom", "Element", "Kind", "Atomic Population", "Net Charge"]
            return pd.DataFrame(data, columns=columns), total_charge

        except Exception as e:
            self.log_signal.emit(f"Error processing Mulliken file: {file_path}. Error: {str(e)}")
            return None, None

    def calculate_charge(self):
        """Calculate the average charge distribution for all elements across all folders."""
        try:
            # Set global font properties for all plots
            plt.rcParams.update({
                'font.family': 'Times New Roman',
                'font.size': 16,
                'font.weight': 'bold',
                'axes.labelweight': 'bold',
                'axes.titlesize': 16,
                'axes.labelsize': 16,
                'xtick.labelsize': 16,
                'ytick.labelsize': 16,
                'legend.fontsize': 16
            })

            if not os.path.exists(self.cp2k_directory):
                self.log_signal.emit(f"CP2K directory not found: {self.cp2k_directory}")
                return

            subdirectories = [d for d in os.listdir(self.cp2k_directory) if os.path.isdir(os.path.join(self.cp2k_directory, d))]
            all_element_charges = {}
            total_charges = []

            for subdir in subdirectories:
                subdir_path = os.path.join(self.cp2k_directory, subdir)
                mulliken_file = os.path.join(subdir_path, 'aiasse_out-1.mulliken')

                if not os.path.isfile(mulliken_file):
                    self.log_signal.emit(f"No 'aiasse_out-1.mulliken' file found in {subdir}")
                    continue

                df, total_charge = self.process_last_mulliken_data(mulliken_file)
                if df is not None:
                    total_charges.append(total_charge)
                    element_means = df.groupby("Element")["Net Charge"].mean()
                    for element, mean_charge in element_means.items():
                        if element not in all_element_charges:
                            all_element_charges[element] = []
                        all_element_charges[element].append(mean_charge)

            # Calculate final averages
            final_averages = {element: sum(charges) / len(charges) for element, charges in all_element_charges.items()}
            total_charge_sum = sum(total_charges)

            # Plotting
            fig, ax = plt.subplots(figsize=(10, 6))
            elements = list(final_averages.keys())
            averages = list(final_averages.values())

            colors = plt.cm.tab20(range(len(elements)))  # Distinct colors
            bars = ax.bar(elements, averages, color=colors, edgecolor='black')

            for bar, avg in zip(bars, averages):
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.01,
                    f"{avg:.2f}",
                    ha='center', va='bottom', fontsize=12, color='black'
                )

            summary_text = (
                f"Total Charge Sum: {total_charge_sum:.2f}\n"
                + "\n".join(f"{element}: {avg:.2f}" for element, avg in zip(elements, averages))
            )
            ax.text(
                1.05, 0.5, summary_text, transform=ax.transAxes, fontsize=12, color='black',
                verticalalignment='center', horizontalalignment='left',
                bbox=dict(facecolor='white', alpha=0.7, edgecolor='black', boxstyle='round,pad=1')
            )

            ax.set_title('Average Net Charge from DFT', fontsize=16)
            ax.set_xlabel('Element', fontsize=14)
            ax.set_ylabel('Average Net Charge', fontsize=14)
            ax.grid(axis='y', linestyle='--', alpha=0.7)
            plt.tight_layout()

            # Emit the figure
            self.charge_figures_signal.emit([fig])

        except Exception as e:
            self.log_signal.emit(f"Error during charge calculation: {e}")

