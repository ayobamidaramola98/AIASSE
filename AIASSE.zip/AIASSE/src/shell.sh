#!/usr/bin/expect

set timeout -1

# Debugging output
puts "Starting search for Large_box/Large directory..."

# Use the known directory path directly
set search_path "/home/ayobami/EPSR/AIASSE/Test"

# Run a find command within the specified directory
set largebox_dir [exec /bin/bash -c "find $search_path -type d -path '*/Large_box/Large' | head -n 1"]

# Check if the directory was found
if {[string length $largebox_dir] == 0} {
    puts "Error: Large_box/Large directory not found."
    exit 1
}

puts "Found Large_box/Large directory at: $largebox_dir"

# Define the path to the Largebox.ato file and verify it exists
set largebox_ato_file [file join $largebox_dir "Largebox.ato"]
if {![file exists $largebox_ato_file]} {
    puts "Error: Largebox.ato file not found."
    exit 1
}

# Retrieve the atomic number density value
set density [exec awk "/Atomic number density =/ {print \$NF}" $largebox_ato_file]
if {[string length $density] == 0} {
    puts "Error: Could not retrieve atomic number density."
    exit 1
}
puts "Atomic number density: $density"

# Interact with epsr25
spawn sh epsr25

expect "EPSRshell> " { send "mixato\r" }
expect "How many .ATO files do you want to mix? " { send "1\r" }
expect "Search for .ato file" { send "y\r" }
expect "How many of these molecules do you want in the mixture? " { send "300\r" }
expect "Give atomic number density (per A**3) of mixture: " { send "$density\r" }
expect "Type name of file to put mixture in: " { send "Smallbox\r" }
expect "EPSRshell> " { send "randomise Smallbox\r" }
expect "EPSRshell> " { send "fmole Smallbox 100000\r" }
expect "EPSRshell> " { send "epsr Smallbox\r" }
expect "EPSRshell> " { send "exit\r" }

expect eof

