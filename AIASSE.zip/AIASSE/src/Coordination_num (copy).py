import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks, savgol_filter
from scipy.interpolate import interp1d

def plot_cn(directory='.', divisor=1):
    """
    Plot the Coordination Number (CN) for each pair type using the g(r) and z01 data.

    Parameters:
        directory (str): The path to the directory containing the data files.
        divisor (int): A divisor to normalize CN data.

    Returns:
        matplotlib.figure.Figure: The figure containing the CN plot.
    """
    cn_data = {}  # Dictionary to store CN values, errors, and accumulations for each CN type

    # Set global font properties for all plots
    plt.rcParams.update({
        'font.family': 'Times New Roman',
        'font.size': 16,
        'font.weight': 'bold',
        'axes.labelweight': 'bold',
        'axes.titlesize': 16,
        'axes.labelsize': 16,
        'xtick.labelsize': 16,
        'ytick.labelsize': 16,
        'legend.fontsize': 16
    })

    # Open output file
    with open(os.path.join(directory, "coordination_number.txt"), "w") as coordination_file:
        coordination_file.write("# accumulation r_cut_1nn CN_Type CN_Value Error\n")

        # Dynamically find the maximum accumulation value in the directory
        max_accumulation = 0
        for filename in os.listdir(directory):
            if filename.endswith('acc.g01'):
                try:
                    accumulation_value = int(filename.split('acc')[0])
                    max_accumulation = max(max_accumulation, accumulation_value)
                except ValueError:
                    print(f"Skipping file due to format issue: {filename}")

        # Create accumulation range based on found files
        accumulation_range = range(100, max_accumulation + 100, 100)

        # Process each accumulation value
        for accumulation_value in accumulation_range:
            gr_filename = os.path.join(directory, f"{accumulation_value}acc.g01")
            ep_filename = os.path.join(directory, f"{accumulation_value}acc.z01")

            print(f"Processing {gr_filename} and {ep_filename}")

            # Check if both files exist
            if not os.path.exists(gr_filename) or not os.path.exists(ep_filename):
                print(f"One or both files do not exist: {gr_filename}, {ep_filename}")
                continue

            try:
                # Load g(r) data with headers
                with open(gr_filename, 'r') as f:
                    gr_headers = f.readline().split()[1:]  # Skip the first 'r' column (which is at index 0)
                gr_data = np.loadtxt(gr_filename, skiprows=1)

                if gr_data.shape[0] == 0:
                    print(f"Skipping {gr_filename}: data length is 0")
                    continue

                r_values = gr_data[:, 0]  # r values are in the first column

                # Load z(r) data with headers
                ep_data = np.loadtxt(ep_filename, skiprows=1)
                with open(ep_filename, 'r') as f:
                    ep_headers = f.readline().split()

                if ep_data.shape[0] == 0:
                    print(f"Skipping {ep_filename}: data length is 0")
                    continue

                # Get the valid headers (skip 'r' and only keep pair names)
                valid_headers = [header for header in gr_headers if '-' in header]
                
                # Loop through each pair type (2nd, 4th, 6th columns in gr_data)
                for col_idx, pair_name in enumerate(valid_headers):
                    # Extract g(r) values for the current pair type
                    gr_values = gr_data[:, 2 * col_idx + 1]  # Get the data for each pair column (skipping 'r')

                    # Interpolate for finer resolution
                    interp_func = interp1d(r_values, gr_values, kind='cubic')
                    r_fine = np.linspace(r_values.min(), r_values.max(), 5000)
                    gr_fine = interp_func(r_fine)

                    # Apply Savitzky-Golay filter for smoothing
                    gr_smooth = savgol_filter(gr_fine, window_length=21, polyorder=3)

                    # Detect peaks in the smoothed g(r) curve
                    peaks, _ = find_peaks(gr_smooth)

                    # Find the index of the tallest peak
                    if len(peaks) > 0:
                        tallest_peak_idx = peaks[np.argmax(gr_smooth[peaks])]

                        # Search for the first minimum after the tallest peak
                        gr_tail = gr_smooth[tallest_peak_idx:]  # Focus on the region to the right of the tallest peak
                        mins, _ = find_peaks(-gr_tail)  # Invert g(r) to find minima
                        if len(mins) > 0:
                            # Index of the first minimum in the original data
                            first_min_idx = tallest_peak_idx + mins[0]
                            first_min_val = r_fine[first_min_idx]

                            # Map the minimum r value to z01 data
                            distances = np.abs(ep_data[:, 0] - first_min_val)
                            idx = np.argmin(distances)
                            cn_val = float(ep_data[idx, 2 * col_idx + 1]) / divisor  # Get the corresponding value for the pair
                            cn_error = np.std(ep_data[:idx + 1, 2 * col_idx + 1]) / 2  # Error calculation

                            # Store CN data
                            if pair_name not in cn_data:
                                cn_data[pair_name] = {'accumulation': [], 'cn_values': [], 'errors': []}

                            cn_data[pair_name]['accumulation'].append(accumulation_value)
                            cn_data[pair_name]['cn_values'].append(cn_val)
                            cn_data[pair_name]['errors'].append(cn_error)

                            # Write to file
                            coordination_file.write(
                                f"{accumulation_value} {first_min_val:.4f} {pair_name} {cn_val:.4f} {cn_error:.4f}\n"
                            )

            except Exception as e:
                print(f"An error occurred while processing {gr_filename} or {ep_filename}: {e}")
                continue

    # Plotting the coordination numbers
    fig, ax = plt.subplots(figsize=(8, 6))

    # Ensure legend starts with correct pair names (e.g., A-A, A-B, B-B...)
    for cn_type, data in cn_data.items():
        # Adjust the legend order dynamically by pair name
        ax.plot(data['accumulation'], data['cn_values'],
                label=f"{cn_type}: {data['cn_values'][-1]:.2f} ± {data['errors'][-1]:.2f}",
                marker='o', linestyle='-', linewidth=2)

    ax.set_xlabel('EPSR Accumulation')
    ax.set_ylabel('Coordination Number')
    ax.set_title('Coordination Numbers vs EPSR Accumulation')

    # Add legend with dynamically mapped names (from .g01 header)
    ax.legend()
    ax.grid(True, which='both', linestyle='--', linewidth=1.5, color='gray')

    return fig

