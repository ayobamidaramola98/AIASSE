import os
import subprocess

class EPSRModifier:
    def __init__(self):
        pass  # Initialize any required attributes if necessary

    def modify_epsr_inp(self, filepath):
        if not os.path.exists(filepath):
            print(f"File not found: {filepath}")
            return

        try:
            # AWK command for replacing multiple strings
            awk_command = (
                f"""awk '{{"""
                f"""gsub("Largebox\\.EPSR", "Smallbox.EPSR");"""
                f"""gsub("fnameato    Largebox\\.ato", "fnameato    Smallbox.ato");"""
                f"""gsub("fnamepcof   Largebox\\.pcof", "fnamepcof   Smallbox.pcof");"""
                f"""gsub("potfac      1\\.0", "potfac      0.0");"""
                f"""if ($1 == "nsumt" && $2 == "-1") {{$2 = "0"}};"""
                f"""print}}' {filepath} > temp_file && mv temp_file {filepath}"""
            )

            # Run the AWK command
            subprocess.run(awk_command, shell=True, check=True)

            print("File modified using AWK successfully.")

        except subprocess.CalledProcessError as e:
            print(f"AWK command failed: {e}")
        except Exception as e:
            print(f"An error occurred: {e}")


# Example usage:
modifier = EPSRModifier()
modifier.modify_epsr_inp('Smallbox.EPSR.inp')  # Replace with your actual file path

