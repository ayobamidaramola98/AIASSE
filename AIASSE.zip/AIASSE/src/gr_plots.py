import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

def plot_rdf_gr(directory='.'):
    # Function to read data from a file and extract labels
    def read_file(filename):
        with open(filename, 'r') as file:
            lines = file.readlines()
            # Get headers starting from column 2 (skipping 'r')
            header = lines[0].strip().split()[1:] if lines else None
            if len(lines) <= 1:  # Skip files with no data
                return None, None
            data = np.loadtxt(filename, skiprows=1)
        return data, header

    # Initialize lists to store all data and headers
    all_data = []
    all_headers = []

    # Loop through the files in the specified directory
    for filename in os.listdir(directory):
        if filename.endswith('.g01'):
            data, header = read_file(os.path.join(directory, filename))
            if data is not None:
                all_data.append(data)
                all_headers.append(header)

    if not all_data:
        raise ValueError("No valid .g01 files found in the directory")

    # Ensure only headers with '-' are selected
    valid_headers = []
    for header in all_headers:
        if header:
            # Only keep headers that contain a '-' (indicating a valid pair type like Si-Si, Si-O, O-O)
            valid_headers.append([h for h in header if '-' in h])

    # Determine the number of plots needed based on the number of valid pair types
    num_plots = len(valid_headers[0])  # The number of valid pair types is the same for each file

    # Set global font properties for all plots
    plt.rcParams.update({
        'font.family': 'Times New Roman',
        'font.size': 16,
        'font.weight': 'bold',
        'axes.labelweight': 'bold',
        'axes.titlesize': 16,
        'axes.labelsize': 16,
        'xtick.labelsize': 16,
        'ytick.labelsize': 16,
        'legend.fontsize': 16
    })

    # Create a figure with subplots, sharing the x-axis
    fig, axes = plt.subplots(nrows=num_plots, figsize=(10, 5 * num_plots), sharex=True)

    # Ensure axes is always a list (even if there's only one subplot)
    if num_plots == 1:
        axes = [axes]

    # Loop over each pair type (Si-Si, Si-O, O-O, etc.)
    for plot_idx in range(num_plots):
        all_x_values = []
        all_y_values = []
        header_labels = []

        # Loop through all files and extract relevant columns for each pair type
        for data, header in zip(all_data, valid_headers):
            x = data[:, 0]  # First column is always the x-axis (r)
            
            # Extract the appropriate column for y values (2, 4, 6, 8, etc.)
            y_column_index = 2 * plot_idx + 1  # Select columns 2, 4, 6, ...
            if y_column_index < data.shape[1]:
                y = data[:, y_column_index]
                all_x_values.append(x)
                all_y_values.append(y)
                
                # Use the header label for this pair type
                header_labels.append(header[plot_idx])

        # Interpolate arrays to have the same length
        max_length = max(len(arr) for arr in all_x_values)
        interpolated_x_values = [np.linspace(x.min(), x.max(), max_length) for x in all_x_values]
        interpolated_y_values = [interp1d(x, y)(interpolated_x_values[i]) for i, (x, y) in enumerate(zip(all_x_values, all_y_values))]

        # Plot individual g(r) over several EPSR accumulations for the current pair type
        for i in range(len(interpolated_x_values)):
            axes[plot_idx].plot(interpolated_x_values[i], interpolated_y_values[i], alpha=0.5)

        # Place header inside the plot area at a specific position
        title_label = header_labels[0] if header_labels else f'Pair {plot_idx + 1}'
        axes[plot_idx].text(0.05, 0.95, title_label, transform=axes[plot_idx].transAxes, fontsize=16,
                            verticalalignment='top', horizontalalignment='left', color='black', fontweight='bold')

        # Set labels for the y-axis and x-axis
        axes[plot_idx].set_ylabel('g(r)', fontsize=16, fontweight='bold')
        if plot_idx == num_plots - 1:  # Only add x-axis label to the last subplot
            axes[plot_idx].set_xlabel('r/Angstrom', fontsize=16, fontweight='bold')
        axes[plot_idx].tick_params(axis='both', which='major', labelsize=16)

        # Add a grid with customized style
        axes[plot_idx].grid(True, which='both', axis='both', linestyle='--', linewidth=1.5, color='gray')

    # Adjust layout to avoid overlap
    plt.tight_layout(pad=3.0)  # Increased padding to reduce overlap between subplots

    # Return the figure
    return fig

