#!/bin/bash

# Ensure the directory exists
mkdir -p Accumulation_dependence
startAcc=100

while true; do
    line=$(grep 'nsumt' *.EPSR.inp)
    set -- $line
    AccNum=$2
   
    # Check if the accumulation number matches the startAcc
    if [ "$AccNum" -eq "$startAcc" ]; then
        
        # Check if files are being written
        while lsof *.EPSR.g01 *.EPSR.z01 *box.ato >/dev/null; do
            sleep 1
        done
        
        # Copy the files
        cp *.EPSR.g01 Accumulation_dependence/"$AccNum"acc.g01 &
        cp *.EPSR.z01 Accumulation_dependence/"$AccNum"acc.z01 &
        cp *box.ato Accumulation_dependence/"$AccNum"acc.ato &
        
        # Wait for all copy operations to finish
        wait
        
        # Increment the startAcc for the next cycle
        startAcc=$((startAcc+100))
    fi
done

