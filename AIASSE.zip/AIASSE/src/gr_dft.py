import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.stats import norm
import os

def read_xyz_last_frame(file_path):
    """Reads the last frame from an XYZ file and returns particle coordinates and number of particles."""
    with open(file_path, 'r') as file:
        lines = file.readlines()

        # Variable to store the coordinates of the last frame and number of particles
        coordinates = []
        elements = []  # Store the elements as well
        num_particles = 0
        found_last_frame = False

        # Iterate over lines to find the last frame
        for line in lines:
            if 'i =     5' in line:  # Check for last frame indicator, adjust as needed
                found_last_frame = True
                continue  # Move to the next line where the coordinates start

            if found_last_frame:
                # If it's a number, it's the number of particles
                if line.strip().isdigit():
                    num_particles = int(line.strip())
                    continue

                # We are now reading particle coordinates
                parts = line.split()
                if len(parts) >= 4:  # Ensure there are enough parts (element, x, y, z)
                    elements.append(parts[0])  # Save element
                    coordinates.append([float(parts[1]), float(parts[2]), float(parts[3])])

        if not coordinates:
            raise ValueError(f"No coordinates found for the last frame in file: {file_path}")

    return np.array(coordinates), np.array(elements), num_particles

def periodic_distance(a, b, box_size):
    """Calculates the minimum image distance between two points."""
    delta = a - b
    return delta - np.round(delta / box_size) * box_size

def calculate_g_r(particles, radii, box_size, dr, rho):
    """Calculate the radial distribution function g(r)."""
    N_radii = len(radii)
    g_r = np.zeros(N_radii)
    N = len(particles)

    for i, r in enumerate(radii):
        for particle in particles:
            distances = periodic_distance(particles, particle, box_size)
            distances = np.linalg.norm(distances, axis=1)
            count_in_shell = np.sum((distances >= r) & (distances < r + dr))
            shell_volume = (4 / 3) * np.pi * ((r + dr)**3 - r**3)
            g_r[i] += count_in_shell / (N * shell_volume * rho)  # Normalize by density

    return g_r

def rdf(particles, dr, box_size):
    """Computes the radial distribution function g(r) of a set of particle coordinates."""
    rho = len(particles) / (box_size ** 3)  # Assuming cubic box
    r_max = box_size / 2  # Use half of box size for radial cutoff
    radii = np.arange(dr, r_max, dr)
    g_r = calculate_g_r(particles, radii, box_size, dr, rho)
    return g_r, radii

def cubic(x, a, b, c, d):
    """Cubic function for fitting."""
    return a * x**3 + b * x**2 + c * x + d

def find_first_peak(radii, g_r, window=10):
    """Fit a cubic around the first peak to find its maximum."""
    first_peak_index = np.argmax(g_r)
    start = max(first_peak_index - window // 2, 0)
    end = min(first_peak_index + window // 2, len(radii))
    popt, _ = curve_fit(cubic, radii[start:end], g_r[start:end])
    cubic_derivative = np.polyder([popt[0], popt[1], popt[2], popt[3]])
    roots = np.roots(cubic_derivative)
    peak_radius = roots[(roots > radii[start]) & (roots < radii[end])][0]
    return peak_radius, cubic(peak_radius, *popt)

def fit_gaussian(data):
    """Fits a Gaussian distribution to the data and returns mean and std."""
    mu, std = norm.fit(data)
    return mu, std

def calculate_bond_angles(particles, elements, box_size):
    """Calculates bond angles between triplets of particles."""
    bond_angles = []
    
    for i, particle in enumerate(particles):
        distances = np.linalg.norm(periodic_distance(particles, particle, box_size), axis=1)
        neighbor_indices = np.argsort(distances)[1:4]  # Get three closest neighbors
        
        # Check number of neighbors
        if len(neighbor_indices) < 3:
            print(f"Not enough neighbors found for particle index {i}.")
            continue
        
        vec1 = periodic_distance(particles[neighbor_indices[0]], particle, box_size)
        vec2 = periodic_distance(particles[neighbor_indices[1]], particle, box_size)
        vec3 = periodic_distance(particles[neighbor_indices[2]], particle, box_size)
        
        # Check for two bonded elements (this means a bond angle of zero)
        if elements[neighbor_indices[0]] == elements[neighbor_indices[1]] == elements[neighbor_indices[2]]:
            bond_angles.append(0.0)  # Zero bond angle for same bonded elements
            continue

        # Calculate the angle between vec1 and vec2 using the dot product
        cos_theta = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
        angle = np.degrees(np.arccos(np.clip(cos_theta, -1.0, 1.0)))
        bond_angles.append(angle)
        
        print(f"Calculated angle between {elements[neighbor_indices[0]]}, {elements[neighbor_indices[1]]}, "
              f"{elements[neighbor_indices[2]]} at index {i}: {angle:.2f} degrees.")

    return bond_angles

def process_folders(folder_paths, box_size, dr):
    """Processes all specified folders to calculate bond lengths and bond angles, and returns a single plot figure with subplots and statistical text annotations."""
    bond_lengths = []
    bond_angles = []
    particle_counts = []

    for folder in folder_paths:
        file_path = os.path.join(folder, 'aiasse_out-pos-1.xyz')
        if os.path.exists(file_path):
            try:
                # Read particle coordinates and number of particles
                particles, elements, num_particles = read_xyz_last_frame(file_path)
                
                # Ensure particles are read correctly
                if particles.size == 0 or elements.size == 0:
                    print(f"Warning: No particles or elements found in {file_path}.")
                    continue
                
                # Compute the radial distribution function
                g_r, radii = rdf(particles, dr, box_size)
                
                # Find the first peak of the g(r) function (bond length)
                peak_radius, _ = find_first_peak(radii, g_r)

                if np.isnan(peak_radius) or peak_radius <= 0:
                    print(f"Warning: Invalid peak radius in {file_path}.")
                    continue

                # Calculate bond angles
                angles = calculate_bond_angles(particles, elements, box_size)
                
                # Store bond length and particle count
                bond_lengths.append(peak_radius)
                bond_angles.extend(angles)  # Collect angles for all folders
                particle_counts.append(num_particles)

                # Print the bond length, bond angles, and number of particles for the current folder
                print(f"Folder: {folder}, Bond Length: {peak_radius:.2f} Å, Number of Particles: {num_particles}")
            except Exception as e:
                print(f"Error processing folder {folder}: {e}")
        else:
            print(f"File not found: {file_path}")

    # Fit the bond lengths to a Gaussian distribution
    if bond_lengths:
        mu_length, std_length = fit_gaussian(bond_lengths)
        x_length = np.linspace(min(bond_lengths), max(bond_lengths), 100)
        p_length = norm.pdf(x_length, mu_length, std_length)

        # Calculate the mean of bond lengths (overall mean)
        mean_bond_length = np.mean(bond_lengths)
        
        # Fit the bond angles to a Gaussian distribution if available
        if bond_angles:
            mu_angle, std_angle = fit_gaussian(bond_angles)
        else:
            mu_angle, std_angle = (0, 0)

        # Calculate stats for bond length and bond angle
        stats = {
            'Mean Bond length': mu_length,
            'Std Dev bond length': std_length,
            'Min bond length': np.min(bond_lengths),
            'Max bond length': np.max(bond_lengths),
            'Mean Bond angle': mu_angle,
            'Std Dev bond angle': std_angle,
            'Min bond angle': np.min(bond_angles) if bond_angles else 0,
            'Max bond angle': np.max(bond_angles) if bond_angles else 0
        }

        # Create a single plot figure with two subplots
        fig1, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        # Plot the bond length distribution
        ax1.hist(bond_lengths, bins=20, density=True, alpha=0.6, color='g', label='Bond Length Data')
        ax1.plot(x_length, p_length, 'k', linewidth=2, label=f'Gaussian Fit: $\mu={mu_length:.2f}$, $\sigma={std_length:.2f}$')

        # Add a marker/bar for the overall mean bond length
        ax1.axvline(mean_bond_length, color='r', linestyle='--', label=f'Mean Bond Length: {mean_bond_length:.2f} Å')

        ax1.set_xlabel('Bond Length (Å)')
        ax1.set_ylabel('Probability Density')
        ax1.set_title('Gaussian Distribution of Bond Lengths')
        ax1.legend()

        # Add text with stats on the bond length subplot
        ax1.text(0.95, 0.95, f"Mean: {stats['Mean Bond length']:.3f} Å\n"
                             f"Std Dev: {stats['Std Dev bond length']:.3f} Å\n"
                             f"Min: {stats['Min bond length']:.3f} Å\n"
                             f"Max: {stats['Max bond length']:.3f} Å",
                 transform=ax1.transAxes, ha='right', va='top', fontsize=10,
                 bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', boxstyle='round,pad=0.5'))

        # Plot the bond angle distribution
        ax2.hist(bond_angles, bins=30, alpha=0.6, color='b', label='Bond Angle Data')

        # Add a marker/bar for the overall mean bond angle
        ax2.axvline(mu_angle, color='r', linestyle='--', label=f'Mean Bond Angle: {mu_angle:.2f} °')

        ax2.set_xlabel('Bond Angle (degrees)')
        ax2.set_ylabel('Frequency')
        ax2.set_title('Distribution of Bond Angles')
        ax2.legend()

        # Add text with stats on the bond angle subplot
        ax2.text(0.95, 0.95, f"Mean: {stats['Mean Bond angle']:.3f} °\n"
                             f"Std Dev: {stats['Std Dev bond angle']:.3f} °\n"
                             f"Min: {stats['Min bond angle']:.3f} °\n"
                             f"Max: {stats['Max bond angle']:.3f} °",
                 transform=ax2.transAxes, ha='right', va='top', fontsize=10,
                 bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', boxstyle='round,pad=0.5'))

        # Print the mean values
        print(f"Mean Bond Length: {mean_bond_length:.2f} Å")
        print(f"Mean Bond Angle: {mu_angle:.2f} degrees")
        print(f"Calculated {len(bond_angles)} bond angles.")

        # Save the results to a text file
        with open("New_bond_length_and_angle.txt", "w") as f:
            f.write("# iteration mean_bond_length mean_bond_angle\n")
            f.write(f"1 {mean_bond_length:.2f} {mu_angle:.2f}\n")
            print("Results saved to New_bond_length_and_angle.txt")

        return fig1  # Return the single figure with both subplots
    else:
        print(f"No bond angles calculated for the provided folders: {folder_paths}")
        raise ValueError("No bond lengths or angles were calculated from the provided folders.")

# Example usage
if __name__ == "__main__":
    folder_paths = ['path/to/folder1', 'path/to/folder2']  # Update with actual folder paths
    box_size = 20.565067  # Example box size in Ångstroms
    dr = 0.01  # Step size for radial distribution in Ångstroms

    try:
        fig1 = process_folders(folder_paths, box_size, dr)
        plt.show()
    except Exception as e:
        print(f"An error occurred: {e}")




