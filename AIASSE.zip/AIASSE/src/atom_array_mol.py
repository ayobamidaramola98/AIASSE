#! /usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Dictionary of atomic masses (in amu)
atom_masses = {
    "H": 1.008, "He": 4.0026, "Li": 6.94, "Be": 9.0122, "B": 10.81,
    "C": 12.011, "N": 14.007, "O": 15.999, "F": 18.998, "Ne": 20.18,
    "Na": 22.99, "Mg": 24.305, "Al": 26.982, "Si": 28.085, "P": 30.974,
    "S": 32.06, "Cl": 35.45, "Ar": 39.948, "Br": 79.904, "I": 126.9,
    "Kr": 83.798, "Xe": 131.293
}

class Atom_cluster(object):
    def __init__(self, atom_positions, cell_params, atom_types, monatomic=False, bonds=None):
        self.atoms = atom_positions
        self.atom_types = atom_types  # Store atom types
        self.cell_params = cell_params[:, 1]  # Use cell parameters for distance calculations
        if not monatomic:
            if bonds is not None:
                self.bonds = bonds
            else:
                self.bond_pairer()  # Call bond_pairer if bonds are not provided
            self.molecule_maker()  # Compute COM for molecules
        else:
            self.molecules = self.atoms  # Treat as monatomic (COM = atom positions)

    def bond_pairer(self):
        """Pair atoms to form molecules based on distance."""
        list_length = len(self.atoms)
        indices = np.arange(0, list_length)
        counter = 0
        molecule_indices = []
        while counter < list_length:
            if counter in indices:
                pair = [counter]
                indices = indices[indices != counter]
                differences = self.atoms[:] - self.atoms[counter]
                differences = np.linalg.norm(differences, axis=1)
                differences[np.where(differences == np.amin(differences))[0][0]] += 2**8  # Avoid self-pairing
                new_index = np.where(differences == np.amin(differences))[0][0]
                pair.append(new_index)
                indices = indices[indices != new_index]
                molecule_indices.append(np.array(pair))
            counter += 1
        self.bonds = np.array(molecule_indices)

    def molecule_maker(self):
        """Compute the center-of-mass positions for molecules."""
        self.molecules = []
        for bond in self.bonds:
            com_x, com_y, com_z = 0.0, 0.0, 0.0
            total_mass = 0.0

            # Compute COM for each molecule (bond pair in this case)
            for atom_idx in bond:
                atom_type = self.atom_types[atom_idx]
                mass = atom_masses.get(atom_type, 0)  # Get mass for atom

                # Print atom type and mass to ensure correctness
                print(f"Atom: {atom_type}, Mass: {mass} amu")

                position = self.atoms[atom_idx]
                
                com_x += mass * position[0]
                com_y += mass * position[1]
                com_z += mass * position[2]
                total_mass += mass
            
            if total_mass > 0:
                com_x /= total_mass
                com_y /= total_mass
                com_z /= total_mass
                self.molecules.append([com_x, com_y, com_z])
            else:
                self.molecules.append([0.0, 0.0, 0.0])

        self.molecules = np.array(self.molecules)

    def rms_stuff(self):
        """Perform structure analysis based on COM positions."""
        r_op = []
        self.results = []
        for i, molecule in enumerate(self.molecules):
            differences_2 = np.zeros((len(self.molecules), 4))
            differences_2[:, 0:3] = self.molecules - molecule
            for j, param in enumerate(self.cell_params):
                differences_2[:, j][differences_2[:, j] > param / 2] -= param
                differences_2[:, j][differences_2[:, j] < -param / 2] += param
            differences_sq = np.square(np.linalg.norm(differences_2, axis=1))
            differences_2[:, 3] = differences_sq

            # Sort by distance and compute metrics
            differences_2 = differences_2[differences_2[:, 3].argsort()]
            r_0_sq = np.sum(differences_2[1:7, 3]) / 6
            r_op.append(r_0_sq)

            # Compute neighbor counts and categorize structures
            N_0 = np.sum(1.45 * r_0_sq > differences_2[:, 3]) - 1
            N_1 = np.sum(1.55 * r_0_sq > differences_2[:, 3]) - 1
            N_0_2 = differences_2[1:N_0 + 1]

            cos_array = np.zeros((N_0 - 1, N_0))
            for k in range(N_0 - 1):
                N_0_3 = np.roll(N_0_2, k + 1, axis=0)
                cos_array[k] = np.sum(
                    np.multiply(N_0_2[:, 0:3], N_0_3[:, 0:3]), axis=1
                ) / (np.sqrt(N_0_2[:, 3] * N_0_3[:, 3]))

            chi = np.zeros(8)
            chi[0] = np.sum((-1.1 <= cos_array) & (cos_array < -0.945))
            chi[1] = np.sum((-0.945 <= cos_array) & (cos_array < -0.915))
            chi[2] = np.sum((-0.915 <= cos_array) & (cos_array < -0.755))
            chi[3] = np.sum((-0.755 <= cos_array) & (cos_array < -0.195))
            chi[4] = np.sum((-0.195 <= cos_array) & (cos_array < 0.195))
            chi[5] = np.sum((0.195 <= cos_array) & (cos_array < 0.245))
            chi[6] = np.sum((0.245 <= cos_array) & (cos_array < 0.795))
            chi[7] = np.sum((0.795 <= cos_array) & (cos_array <= 1))
            chi /= 2

            del_bcc = 0.35 * chi[4] / (chi[5] + chi[6] + chi[7] - chi[4])
            del_cp = 0.61 * np.abs(1 - chi[6] / 24)
            del_fcc = 0.61 * (np.abs(chi[0] + chi[1] - 6) + chi[2]) / 6
            del_hcp = (np.abs(chi[3] - 3) + np.abs(chi[0] + chi[1] + chi[2] + chi[3] - 9)) / 12

            # Assign structure based on computed metrics
            structure = 'none'
            if chi[0] == 7:
                structure = 'bcc'
            elif chi[0] == 6:
                structure = 'fcc'
            elif chi[0] == 3:
                structure = 'hcp'
            elif del_bcc < 0.1 and del_cp < 0.1 and del_fcc < 0.1 and del_hcp < 0.1:
                structure = 'none'
            elif del_bcc < del_cp and 10 < N_1 < 13:
                structure = 'bcc'
            elif N_0 > 12:
                structure = 'none'
            elif del_hcp < del_fcc:
                structure = 'hcp'
            elif del_hcp > del_fcc:
                structure = 'fcc'

            self.results.append(np.array([i, structure]))
        self.results = np.array(self.results)
        self.proportions_meth()

    def proportions_meth(self):
        """Compute proportions of each structure type."""
        self.proportions = {}
        self.proportions['fcc'] = np.sum(('fcc' == self.results[:, 1])) / len(self.results)
        self.proportions['bcc'] = np.sum(('bcc' == self.results[:, 1])) / len(self.results)
        self.proportions['hcp'] = np.sum(('hcp' == self.results[:, 1])) / len(self.results)
        self.proportions['none'] = np.sum(('none' == self.results[:, 1])) / len(self.results)
        self.proportions['all'] = len(self.results)

