#! /usr/bin/env python3
import numpy as np

import matplotlib.pyplot as plt 
from mpl_toolkits.mplot3d import Axes3D

class Atom_cluster(object):
    def __init__(self,atom_positions,cell_params,monatomic=False,bonds=None):
        self.atoms=atom_positions
        #self.timestep=timestep
        self.cell_params=cell_params[:,1]
        if monatomic==False:
            if bonds!=None:
                self.bonds=bonds
            else:
                self.bond_pairer()
            self.molecule_maker()
        else:
            self.molecules=self.atoms

    def bond_pairer(self):
        list_length=len(self.atoms)
        indicies=np.arange(0,list_length)
        counter=0
        molecule_indicies=[]
        while counter < list_length:
            if counter in indicies:
                pair=[]
                pair.append(counter)
                indicies=indicies[indicies!=counter]
                differences=self.atoms[:]-self.atoms[counter]
                differences=np.linalg.norm(differences, axis=1)
                differences[np.where(differences == np.amin(differences))[0][0]]+=2**8
                new_index=np.where(differences == np.amin(differences))[0][0]
                pair.append(new_index)
                indicies=indicies[indicies!=new_index]
                pair=np.array(pair)
                molecule_indicies.append(pair)
            counter+=1
        molecule_indicies=np.array(molecule_indicies)
        self.bonds=molecule_indicies
        #print(self.bonds)

    def molecule_maker(self):
        self.molecules=[]
        for bond in self.bonds:
            self.molecules.append(np.array((1/2)*(self.atoms[bond[0]]+self.atoms[bond[1]])))
        self.molecules=np.array(self.molecules)

    def rms_stuff(self):
        r_op=[]
        counter_temp=0
        self.results=[]
        for i, molecule in enumerate(self.molecules):
            differences_2=np.zeros((len(self.molecules),4))
            #print(differences_2.shape)
            differences_2[:,0:3]=self.molecules-molecule
            for j, param in enumerate(self.cell_params):
                differences_2[:,j][differences_2[:,j]>param/2]-=param
                differences_2[:,j][differences_2[:,j]<-param/2]+=param
            differences_sq=np.square(np.linalg.norm(differences_2,axis=1))
            differences_2[:,3]=differences_sq

            #print(differences_2)
            differences_2=differences_2[differences_2[:, 3].argsort()]
            #print(differences_2)
            #print(molecule)
            #print(differences_sq[0:7])
            r_0_sq=np.sum(differences_2[1:7,3])/6
            #print(r_0_sq,'is the r_0')
            r_op.append(r_0_sq)
            N_0=np.sum(1.45*r_0_sq>differences_2[:,3])-1
            #print(differences_sq[0:16])
            #print(str(N_0))
            N_1=np.sum(1.55*r_0_sq>differences_2[:,3])-1
            #print(str(N_1)+'\n')
            N_0_2=differences_2[1:N_0+1]

            cos_array=np.zeros((N_0-1,N_0))
            for k in range(N_0-1):
                N_0_3=np.roll(N_0_2,k+1,axis=0)
                cos_array[k]=np.sum(np.multiply(N_0_2[:,0:3],N_0_3[:,0:3]),axis=1)/(np.sqrt(N_0_2[:,3]*N_0_3[:,3]))
            #print(cos_array)
            int_array=np.zeros(cos_array.shape)
            chi=np.zeros(8)
            chi[0]=np.sum((-1.1<=cos_array) & (cos_array<-0.945))
            chi[1]=np.sum((-0.945<=cos_array)&(cos_array<-0.915))
            chi[2]=np.sum((-0.915<=cos_array)&(cos_array<-0.755))
            chi[3]=np.sum((-0.755<=cos_array)&(cos_array<-0.195))
            chi[4]=np.sum((-0.195<=cos_array)&(cos_array<0.195))
            chi[5]=np.sum((0.195<=cos_array)&(cos_array<0.245))
            chi[6]=np.sum((0.245<=cos_array)&(cos_array<0.795))
            chi[7]=np.sum((0.795<=cos_array)&(cos_array<=1))
            chi/=2
            #print(chi)
            del_bcc=0.35*chi[4]/(chi[5]+chi[6]+chi[7]-chi[4])
            del_cp=0.61*np.abs(1-chi[6]/24)
            del_fcc=0.61*(np.abs(chi[0]+chi[1]-6)+chi[2])/6
            del_hcp=(np.abs(chi[3]-3)+np.abs(chi[0]+chi[1]+chi[2]+chi[3]-9))/12
            abs_vals=False
            if chi[0]==7:
                structure='bcc'
            elif chi[0]==6:
                structure='fcc'
            elif chi[0]==3:
                structure='hcp'
            else:
                abs_vals=True
            if abs_vals==True:
                if (del_bcc<0.1) and (del_cp<0.1) and (del_fcc<0.1) and (del_hcp<0.1):
                    structure='none'
                elif (del_bcc<del_cp) and (10<N_1<13):
                    structure='bcc'
                elif (N_0>12):
                    structure='none'
                elif (del_hcp<del_fcc):
                    structure='hcp'
                elif (del_hcp>del_fcc):
                    structure='fcc'

            else:
                pass
            self.results.append(np.array([i,structure]))
        self.results=np.array(self.results)
        self.proportions_meth()

    def proportions_meth(self):
        self.proportions={}
        self.proportions['fcc']=np.sum(('fcc'==self.results[:,1]))/len(self.results)
        self.proportions['bcc']=np.sum(('bcc'==self.results[:,1]))/len(self.results)
        self.proportions['hcp']=np.sum(('hcp'==self.results[:,1]))/len(self.results)
        self.proportions['none']=np.sum(('none'==self.results[:,1]))/len(self.results)

