#!/usr/bin/expect

set timeout -1

# Get the current working directory
set current_dir [exec pwd]
puts "Current working directory: $current_dir"

# Define the path for Large_box/Large (already in this directory)
set largebox_dir $current_dir
puts "Using Large_box/Large directory at: $largebox_dir"

# Define the absolute path for Small_box/Small
# Construct the absolute path based on the known structure
set Smallbox_dir "/home/ayobami/EPSR/AIASSE/Test/Small_box/Small"
puts "Using Small_box/Small directory at: $Smallbox_dir"

# Verify Smallbox.ato file
set Smallbox_ato_file [file join $Smallbox_dir "Smallbox.ato"]
if {![file exists $Smallbox_ato_file]} {
    puts "Error: Smallbox.ato file not found."
    exit 1
}

# Retrieve atomic number density value
set density [exec awk "/Atomic number density =/ {print \$NF}" $Smallbox_ato_file]
if {[string length $density] == 0} {
    puts "Error: Could not retrieve atomic number density."
    exit 1
}
puts "Atomic number density: $density"

# Switch to Large_box/Large directory (current working directory already)
puts "Starting operations in Large_box/Large directory..."
cd $largebox_dir
puts "Current working directory: [pwd]"

# Interact with epsr25
puts "Starting EPSR..."
spawn sh epsr25 

# Handle EPSR interactions
expect "EPSRshell> " { send "mixato\r" }
expect "How many .ATO files do you want to mix? " { send "1\r" }
expect "Search for .ato file" { send "y\r" }
expect "How many of these molecules do you want in the mixture? " { send "1000\r" }
expect "Give atomic number density (per A**3) of mixture: " { send "$density\r" }
expect "Type name of file to put mixture in: " { send "Largebox\r" }
expect "EPSRshell> " { send "randomise Largebox\r" }
expect "EPSRshell> " { send "fmole Largebox 10000\r" }
expect "EPSRshell> " { send "epsr Largebox\r" }

expect eof
puts "EPSR script completed."

