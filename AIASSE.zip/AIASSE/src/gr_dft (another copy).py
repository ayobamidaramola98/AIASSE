import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.stats import norm
import os

# Read last frame from an XYZ file
def read_xyz_last_frame(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        coordinates = []
        elements = []
        num_particles = 0
        found_last_frame = False

        for line in lines:
            if 'i =     1000' in line:
                found_last_frame = True
                continue

            if found_last_frame:
                if line.strip().isdigit():
                    num_particles = int(line.strip())
                    continue

                parts = line.split()
                if len(parts) >= 4:
                    elements.append(parts[0])
                    coordinates.append([float(parts[1]), float(parts[2]), float(parts[3])])

        if not coordinates:
            raise ValueError(f"No coordinates found for the last frame in file: {file_path}")

    return np.array(coordinates), np.array(elements), num_particles

# Minimum image distance
def periodic_distance(a, b, box_size):
    delta = a - b
    return delta - np.round(delta / box_size) * box_size

# Calculate radial distribution function
def calculate_g_r(particles, radii, box_size, dr, rho):
    N_radii = len(radii)
    g_r = np.zeros(N_radii)
    N = len(particles)

    for i, r in enumerate(radii):
        for particle in particles:
            distances = periodic_distance(particles, particle, box_size)
            distances = np.linalg.norm(distances, axis=1)
            count_in_shell = np.sum((distances >= r) & (distances < r + dr))
            shell_volume = (4 / 3) * np.pi * ((r + dr)**3 - r**3)
            g_r[i] += count_in_shell / (N * shell_volume * rho)

    return g_r

# Radial distribution function
def rdf(particles, dr, box_size):
    rho = len(particles) / (box_size ** 3)
    r_max = box_size / 2
    radii = np.arange(dr, r_max, dr)
    g_r = calculate_g_r(particles, radii, box_size, dr, rho)
    return g_r, radii

# Cubic function for fitting
def cubic(x, a, b, c, d):
    return a * x**3 + b * x**2 + c * x + d

# Find the first peak
def find_first_peak(radii, g_r, window=10):
    first_peak_index = np.argmax(g_r)
    start = max(first_peak_index - window // 2, 0)
    end = min(first_peak_index + window // 2, len(radii))
    popt, _ = curve_fit(cubic, radii[start:end], g_r[start:end])
    cubic_derivative = np.polyder([popt[0], popt[1], popt[2], popt[3]])
    roots = np.roots(cubic_derivative)
    peak_radius = roots[(roots > radii[start]) & (roots < radii[end])][0]
    return peak_radius, cubic(peak_radius, *popt)

# Gaussian fitting
def fit_gaussian(data):
    mu, std = norm.fit(data)
    return mu, std

# Calculate bond angles
def calculate_bond_angles(particles, elements, box_size):
    bond_angles = []
    for i, particle in enumerate(particles):
        distances = np.linalg.norm(periodic_distance(particles, particle, box_size), axis=1)
        neighbor_indices = np.argsort(distances)[1:4]
        if len(neighbor_indices) < 3:
            continue
        vec1 = periodic_distance(particles[neighbor_indices[0]], particle, box_size)
        vec2 = periodic_distance(particles[neighbor_indices[1]], particle, box_size)
        cos_theta = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
        angle = np.degrees(np.arccos(np.clip(cos_theta, -1.0, 1.0)))
        bond_angles.append(angle)
    return bond_angles

# Calculate dihedral angle
def calculate_dihedral_angle(atom1, atom2, atom3, atom4, box_size):
    r12 = periodic_distance(atom1, atom2, box_size)
    r23 = periodic_distance(atom2, atom3, box_size)
    r34 = periodic_distance(atom3, atom4, box_size)
    n1 = np.cross(r12, r23)
    n2 = np.cross(r23, r34)
    n1 /= np.linalg.norm(n1)
    n2 /= np.linalg.norm(n2)
    cos_phi = np.dot(n1, n2)
    phi = np.degrees(np.arccos(np.clip(cos_phi, -1.0, 1.0)))
    if np.dot(np.cross(n1, n2), r23) < 0:
        phi = -phi
    return phi

# Calculate all dihedral angles
def calculate_dihedral_angles(particles, box_size):
    dihedral_angles = []
    for i in range(len(particles) - 3):
        for j in range(i + 1, len(particles) - 2):
            for k in range(j + 1, len(particles) - 1):
                for l in range(k + 1, len(particles)):
                    try:
                        angle = calculate_dihedral_angle(particles[i], particles[j], particles[k], particles[l], box_size)
                        dihedral_angles.append(angle)
                    except Exception as e:
                        print(f"Error calculating dihedral for indices ({i}, {j}, {k}, {l}): {e}")
    return dihedral_angles

def process_folders(folder_paths, box_size, dr):
    bond_lengths = []
    bond_angles = []
    dihedral_angles = []
    particle_counts = []

    for folder in folder_paths:
        file_path = os.path.join(folder, 'aiasse_out-pos-1.xyz')
        if os.path.exists(file_path):
            try:
                particles, elements, num_particles = read_xyz_last_frame(file_path)
                
                if particles.size == 0 or elements.size == 0:
                    print(f"Warning: No particles or elements found in {file_path}.")
                    continue
                
                g_r, radii = rdf(particles, dr, box_size)
                peak_radius, _ = find_first_peak(radii, g_r)

                if np.isnan(peak_radius) or peak_radius <= 0:
                    print(f"Warning: Invalid peak radius in {file_path}.")
                    continue

                angles = calculate_bond_angles(particles, elements, box_size)
                dihedrals = calculate_dihedral_angles(particles, box_size)

                bond_lengths.append(peak_radius)
                bond_angles.extend(angles)
                dihedral_angles.extend(dihedrals)
                particle_counts.append(num_particles)

                print(f"Folder: {folder}, Bond Length: {peak_radius:.2f} Å, Number of Particles: {num_particles}")
                print(f"Dihedral angles for folder {folder}: {dihedrals}")

            except Exception as e:
                print(f"Error processing folder {folder}: {e}")
        else:
            print(f"File not found: {file_path}")

    if bond_lengths:
        mu_length, std_length = fit_gaussian(bond_lengths)
        x_length = np.linspace(min(bond_lengths), max(bond_lengths), 100)
        p_length = norm.pdf(x_length, mu_length, std_length)

        fig1, ax1 = plt.subplots(figsize=(10, 6))
        ax1.hist(bond_lengths, bins=20, density=True, alpha=0.6, color='g', label='Bond Length Data')
        ax1.plot(x_length, p_length, 'k', linewidth=2, label=f'Gaussian Fit: $\mu={mu_length:.2f}$, $\sigma={std_length:.2f}$')
        ax1.set_xlabel('Bond Length (Å)')
        ax1.set_ylabel('Probability Density')
        ax1.set_title('Gaussian Distribution of Bond Lengths')
        ax1.legend()
        
        print(f"Mean Bond Length: {mu_length:.2f} Å")

    if bond_angles:
        mu_angle, std_angle = fit_gaussian(bond_angles) if bond_angles else (0, 0)
        fig2, ax2 = plt.subplots(figsize=(10, 6))
        ax2.hist(bond_angles, bins=30, alpha=0.6, color='b', label='Bond Angle Data')
        ax2.set_xlabel('Bond Angle (degrees)')
        ax2.set_ylabel('Frequency')
        ax2.set_title('Distribution of Bond Angles')
        ax2.legend()
        
        print(f"Mean Bond Angle: {mu_angle:.2f} degrees")
        print(f"Calculated {len(bond_angles)} bond angles.")

        # Save results to a text file
        with open("New_bond_length_and_angle.txt", "w") as f:
            f.write("# iteration mean_bond_length mean_bond_angle dihedral_angles\n")
            f.write(f"1 {mu_length:.2f} {mu_angle:.2f} {' '.join(map(str, dihedral_angles))}\n")
            print("Results saved to New_bond_length_and_angle.txt")
        
        return fig1, fig2
    else:
        print(f"No bond angles calculated for the provided folders: {folder_paths}")
        raise ValueError("No bond lengths or angles were calculated from the provided folders.")

