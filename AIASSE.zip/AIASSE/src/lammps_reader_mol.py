#! /usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import os
from atom_array_mol import Atom_cluster  # Assuming Atom_cluster is defined in atom_array_mol.py

# Function to read the XYZ file and extract positions and atom types
def xyz_reader(filename: str):
    with open(filename, 'r') as fp:
        atom_count = int(fp.readline().strip())
        fp.readline()  # Skip the comment line
        
        positions = []
        atom_types = []
        
        for _ in range(atom_count):
            line = fp.readline().strip().split()
            atom_type = line[0]  # Atom type from the first column
            position = np.array([float(line[1]), float(line[2]), float(line[3])])
            atom_types.append(atom_type)
            positions.append(position)
        
        positions = np.array(positions)
        box_size = np.array([[0, 37.893383], [0, 37.893383], [0, 37.893383]])
        
        return {
            'atomic positions': positions,
            'atom types': atom_types,
            'box size': box_size,
            'molecule number': atom_count,
        }

# Function to generate COM (Center of Mass) only XYZ files
def generate_com_xyz_files(input_dir, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    xyz_files = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if f.endswith('.xyz')]
    xyz_files.sort()

    if not xyz_files:
        print(f"No .xyz files found in {input_dir}")
        return False

    for file_path in xyz_files:
        print(f"Processing file: {file_path}")
        output = xyz_reader(file_path)
        atom_positions = output['atomic positions']
        atom_types = output['atom types']  # Extract atom types
        box_size = output['box size']
        
        # Create Atom_cluster object with atom_types argument
        cluster = Atom_cluster(atom_positions, box_size, atom_types, monatomic=False)
        
        # Extract COM positions
        com_positions = cluster.molecules  # COMs are already computed as `self.molecules`
        
        com_file_path = os.path.join(output_dir, os.path.basename(file_path))
        with open(com_file_path, 'w') as fp:
            fp.write(f"{len(com_positions)}\n")
            fp.write("COM positions only\n")
            for position in com_positions:
                # Use atom_type from the original file
                fp.write(f"{atom_types[0]} {position[0]} {position[1]} {position[2]}\n")
        print(f"COM-only file written: {com_file_path}")

    return True

# Function to plot local structure
def plot_local_structure_mol(directory_path):
    plt.rcParams.update({
        'font.family': 'Times New Roman',
        'font.size': 16,
        'font.weight': 'bold',
        'axes.labelweight': 'bold',
        'axes.titlesize': 16,
        'axes.labelsize': 16,
        'xtick.labelsize': 16,
        'ytick.labelsize': 16,
        'legend.fontsize': 16
    })

    if not generate_com_xyz_files(directory_path, os.path.join(directory_path, "mol")):
        print("No .xyz files generated. Cannot proceed with plotting.")
        return None

    xyz_files = [os.path.join(directory_path, "mol", f) for f in os.listdir(os.path.join(directory_path, "mol")) if f.endswith('.xyz')]
    xyz_files.sort()

    if not xyz_files:
        print("No .xyz files found in the directory. Cannot generate plot.")
        return None

    accumulations = []
    proportions = {
        'fcc': [],
        'bcc': [],
        'hcp': [],
        'none': [],
    }

    for file_path in xyz_files:
        output = xyz_reader(file_path)
        atom_positions = output['atomic positions']
        atom_types = output['atom types']  # Extract atom types
        box_size = output['box size']
        
        # Pass atom_types to Atom_cluster when creating an object
        file_cluster = Atom_cluster(atom_positions, box_size, atom_types, monatomic=True)
        file_cluster.rms_stuff()

        accumulations.append(len(accumulations) + 1)
        proportions['fcc'].append(file_cluster.proportions['fcc'])
        proportions['bcc'].append(file_cluster.proportions['bcc'])
        proportions['hcp'].append(file_cluster.proportions['hcp'])
        proportions['none'].append(file_cluster.proportions['none'])

    avg_fcc = np.mean(proportions['fcc']) * 100
    avg_bcc = np.mean(proportions['bcc']) * 100
    avg_hcp = np.mean(proportions['hcp']) * 100
    avg_none = np.mean(proportions['none']) * 100

    fig, ax = plt.subplots(figsize=(12, 6))

    scaled_accumulations = [accum * 100 for accum in accumulations]
    ax.plot(scaled_accumulations, proportions['fcc'], label=f'FCC (avg: {avg_fcc:.2f}%)', marker='o')
    ax.plot(scaled_accumulations, proportions['bcc'], label=f'BCC (avg: {avg_bcc:.2f}%)', marker='o')
    ax.plot(scaled_accumulations, proportions['hcp'], label=f'HCP (avg: {avg_hcp:.2f}%)', marker='o')
    ax.plot(scaled_accumulations, proportions['none'], label=f'None (avg: {avg_none:.2f}%)', marker='o')

    ax.set_title('Structure Type Proportions vs Accumulations')
    ax.set_xlabel('EPSR Accumulations')
    ax.set_ylabel('Structure Proportion')
    ax.legend()
    ax.grid(True, which='both', axis='both', linestyle='--', linewidth=1.5, color='gray')

    return fig

# Main Execution Logic
if __name__ == "__main__":
    input_dir = "/home/ayobami/EPSR/AIASSE/Test/Large_box/Large/Accumulation_dependence/DFT_box/"
    output_dir = os.path.join(input_dir, "mol")  # Output folder for .xyz files

    try:
        if not generate_com_xyz_files(input_dir, output_dir):
            print("No .xyz files generated. Exiting.")
        else:
            fig = plot_local_structure_mol(output_dir)
            if fig:
                print("Displaying plot...")
                plt.show()  # Display the plot if it's valid
            else:
                print("Error: Failed to generate valid plot.")
    except Exception as e:
        print(f"Error in generating files or plotting: {e}")

