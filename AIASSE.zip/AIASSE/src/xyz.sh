#!/usr/bin/expect
# Set the initial iteration value
set i 100
set step 100

# Set the target directory for the .xyz files
set target_dir "/home/ayobami/EPSR/AIASSE/Test/Small_box/Small/Accumulation_dependence/DFT_box"

# Check if the DFT_box directory exists, create it if it doesn't
if {![file exists $target_dir]} {
    file mkdir $target_dir
    puts "Created directory: $target_dir"
} else {
    puts "Directory already exists: $target_dir"
}

# Start an infinite loop
while {1} {
    # Build the file prefix based on the current iteration (e.g., 100acc, 200acc, etc.)
    set filename "${i}acc"
    set filepath "/home/ayobami/EPSR/AIASSE/Test/Small_box/Small/Accumulation_dependence/${filename}.ato"

    # Check if the necessary files exist before executing
    if {[file exists $filepath]} {
        # Open the .ato file and read the first line
        set file_id [open $filepath r]
        set first_line [gets $file_id]
        close $file_id

        # Log what was extracted from the first line for debugging
        puts "First line extracted from $filepath: $first_line"

        # Use regex to match the specific value format
        if {[regexp {(\d+\.\d+E[+-]\d+)} $first_line match_value]} {
            # Log the extracted value
            puts "Extracted value from first line: $match_value"

            # Convert the scientific notation value to a floating-point number
            set float_value [scan $match_value %e] ; # This converts it to a floating point

            # Log the conversion result
            puts "Converted value: $float_value"

            # Prepare the positive and negative values for the writexyz command
            set positive_value $float_value
            set negative_value [expr {-$float_value}]

            # Interact with epsr25
            spawn sh epsr25

            # Wait for the EPSRshell prompt
            expect "EPSRshell> " { 
                # Send the writexyz command with dynamic values
                send "writexyz $filename append 0 $positive_value $positive_value $negative_value $positive_value 0 0 0 0\r" 
            }

            # Expect the end of file
            expect eof

            # Define the source and target paths for the generated .xyz file
            set original_xyz_file "${filename}append.xyz"  ; # The original generated name
            set new_xyz_file "${filename}.xyz"              ; # The new desired name
            set source_path "/home/ayobami/EPSR/AIASSE/Test/Small_box/Small/Accumulation_dependence/$original_xyz_file"
            set target_path "$target_dir/$new_xyz_file"

            # Move and rename the generated .xyz file to the DFT_box directory
            if {[file exists $source_path]} {
                file rename $source_path $target_path
                puts "Moved and renamed $original_xyz_file to $target_path"
            } else {
                puts "XYZ file not found: $source_path"
            }
        } else {
            puts "Expected value not found in file $filepath"
        }
    } else {
        puts "File ${filename}.ato not found, stopping."
        break ;# Stop the loop if the file is not found
    }

    # Increment the iteration value by the step (100)
    incr i $step
}

