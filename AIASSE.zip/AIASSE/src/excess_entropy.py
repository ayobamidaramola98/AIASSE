import os
import numpy as np
import matplotlib.pyplot as plt

def calculate_excess_entropy(gr_file, num_atoms, cell_length, col_index=1):
    """
    Calculate the excess two-body entropy from the g(r) data in gr_file for a specific column.
    
    :param gr_file: Path to the file containing g(r) data.
    :param num_atoms: Number of atoms in the system.
    :param cell_length: Length of the cubic cell.
    :param col_index: Column index to use for g(r).
    :return: Excess two-body entropy (S2).
    """
    # Load g(r) data: assuming it's two columns with r and g(r)
    data = np.loadtxt(gr_file, comments='#')
    r = data[:, 0]  # First column: radial distances
    g_r = data[:, col_index]  # Selected column for g(r)

    # Handle cases where g(r) is zero to avoid log(0)
    g_r_safe = np.where(g_r > 0, g_r, 1e-10)  # Replace 0 with a small value (1e-10) for safety

    # Calculate number density (rho = N_atoms / V_cell)
    volume = cell_length**3
    number_density = num_atoms / volume

    # Compute the integrand for the two-body excess entropy
    integrand = 4 * np.pi * r**2 * (g_r_safe * np.log(g_r_safe) - g_r + 1)

    # Compute the integral using the trapezoidal rule
    s2 = -0.5 * number_density * np.trapz(integrand, r)
    
    return s2

def plot_excess_entropy(directory, num_atoms, cell_length):
    """
    Generate the excess two-body entropy for all g(r) files in the specified directory.
    
    :param directory: Path to the directory containing g(r) files.
    :param num_atoms: Number of atoms in the system.
    :param cell_length: Length of the cubic cell.
    :return: Matplotlib figure.
    """
    print("Calculating Excess Entropy")

    # Dynamically find the maximum accumulation value in the directory
    max_accumulation = 0
    for filename in os.listdir(directory):
        if filename.endswith('acc.g01'):
            try:
                accumulation_value = int(filename.split('acc')[0])  # Extract accumulation value
                max_accumulation = max(max_accumulation, accumulation_value)
            except ValueError:
                print(f"Skipping file due to format issue: {filename}")

    # Create accumulation range based on found files
    accumulation_range = range(100, max_accumulation + 100, 100)

    # Store entropy values for each column
    entropy_results = {}

    # Process each accumulation value
    for accumulation_value in accumulation_range:
        gr_filename = os.path.join(directory, f"{accumulation_value}acc.g01")
        if os.path.exists(gr_filename):
            print(f"Processing {gr_filename}")  # Debug output

            # Extract headers
            with open(gr_filename, 'r') as f:
                header_line = f.readline().strip()
            headers = header_line.split()[1:]  # Skip the first "#" and split into headers
            headers = headers[1:]  # Ignore the `r` header, start from the first pair header

            # Load the data to determine number of columns
            data = np.loadtxt(gr_filename, comments='#')
            num_columns = data.shape[1]

            # Initialize entropy lists if not already done
            for col_idx in range(1, num_columns, 2):  # Iterate over even columns
                header_index = col_idx // 2  # Map column to corresponding header
                if headers[header_index] not in entropy_results:
                    entropy_results[headers[header_index]] = {"accumulation": [], "entropy": []}

                # Calculate entropy for the current column
                s2 = calculate_excess_entropy(gr_filename, num_atoms, cell_length, col_index=col_idx)
                
                # Append results
                entropy_results[headers[header_index]]["accumulation"].append(accumulation_value)
                entropy_results[headers[header_index]]["entropy"].append(s2)

    # Set global font properties for all plots
    plt.rcParams.update({
        'font.family': 'Times New Roman',
        'font.size': 16,
        'font.weight': 'bold',
        'axes.labelweight': 'bold',
        'axes.titlesize': 16,
        'axes.labelsize': 16,
        'xtick.labelsize': 16,
        'ytick.labelsize': 16,
        'legend.fontsize': 16
    })

    # Plot the results
    fig = plt.figure(figsize=(12, 10))

    for idx, (header, results) in enumerate(entropy_results.items()):
        plt.plot(results["accumulation"], results["entropy"], marker='o', linestyle='-', label=header)
    
    plt.xlabel('Accumulation Value')
    plt.ylabel('Excess Two-Body Entropy ($S_2 / k_B$)')
    plt.title('Excess Two-Body Entropy vs Accumulation Value')

    # Enhanced grid styling
    plt.grid(True, which='both', axis='both', linestyle='--', linewidth=1.5, color='gray')

    plt.legend()
    
    # Save entropy data to a text file
    with open("Excess_entropy.txt", "w") as file:
        for header, results in entropy_results.items():
            file.write(f"# {header}\n")
            for acc, s2 in zip(results["accumulation"], results["entropy"]):
                file.write(f"{acc}\t{s2}\n")
        
    return fig

