import os

def read_ato_file(input_name):
    name, ext = input_name.split('.ato')
    return str(name)

# Create a folder for output files if it doesn't exist
output_folder = "output_files"
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Iterate through all files
for input_file in os.listdir():
    if input_file.endswith(".ato"):
        name = read_ato_file(input_file)
        output_file = os.path.join(output_folder, name + '.xyz')  # Construct the output file path

        with open(input_file, "r") as file:
            print(input_file)

            atom_list = []
            position_list = []
            ato = file.readlines()
            i = 0
            N_lines = len(ato)

            try:
                while i < N_lines:
                    if i == 0:
                        N_mol, size, temp = ato[i].split()
                        i += 1
                    elif i == 1:
                        i += 1
                        pass
                    else:
                        tokens = ato[i].split()
                        N_atoms_per_molecule, x_mol, y_mol, z_mol = int(tokens[0]), float(tokens[1]), float(tokens[2]), float(tokens[3])
                        for j in range(0, N_atoms_per_molecule):
                            try:
                                tokens1 = ato[j*3+i+1].split()
                                atom_list.append(tokens1[0])
                                tokens2 = ato[j*3+i+2].split()
                                x_rel, y_rel, z_rel = float(tokens2[0]), float(tokens2[1]), float(tokens2[2])
                                position_list.append([x_mol+x_rel, y_mol+y_rel, z_mol+z_rel])
                            except IndexError:
                                print("Error occurred at line:", i)
                                print("Index out of range for atom", j, "of molecule", i)

                        i = i + 3 * N_atoms_per_molecule + 2
                        N_lines = 2 + int(N_mol) * (3 * N_atoms_per_molecule+2)
            except IndexError:
                print("Skipping file due to IndexError.")
                continue

        # Build xyz file
        num_atoms = len(atom_list)
        with open(output_file, "w") as f:
            f.write(str(num_atoms) + "\n")
            f.write(name + "\n")
            for i in range(num_atoms):
                x, y, z = position_list[i]
                f.write("{:<2} {: >11.3f} {: >11.3f} {: >11.3f}\n".format(atom_list[i], x, y, z))

