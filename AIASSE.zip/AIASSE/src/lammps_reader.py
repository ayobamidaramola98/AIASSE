#! /usr/bin/env python3

import os
import numpy as np
import matplotlib.pyplot as plt
from atom_array import Atom_cluster

def xyz_reader(filename: str):
    with open(filename, 'r') as fp:
        atom_count = int(fp.readline().strip())
        fp.readline()  # Skip the comment line
        
        positions = []
        atom_types = []
        
        for _ in range(atom_count):
            line = fp.readline().strip().split()
            atom_type = line[0]  
            position = np.array([float(line[1]), float(line[2]), float(line[3])])
            atom_types.append(atom_type)
            positions.append(position)
        
        positions = np.array(positions)
        
        box_size = np.array([[0,  37.893383], [0,  37.893383], [0, 37.893383]])
        
        return {
            'atomic positions': positions,
            'atom types': atom_types,
            'box size': box_size,
            'molecule number': atom_count,
        }

def plot_local_structure(directory_path):
    # Set global font properties for all plots
    plt.rcParams.update({
        'font.family': 'Times New Roman',
        'font.size': 16,
        'font.weight': 'bold',
        'axes.labelweight': 'bold',
        'axes.titlesize': 16,
        'axes.labelsize': 16,
        'xtick.labelsize': 16,
        'ytick.labelsize': 16,
        'legend.fontsize': 16
    })
    
    # Find all .xyz files in the directory and sort them
    xyz_files = [os.path.join(directory_path, f) for f in os.listdir(directory_path) if f.endswith('.xyz')]
    xyz_files.sort()

    accumulations = []
    proportions = {
        'fcc': [],
        'bcc': [],
        'hcp': [],
        'none': [],
    }

    for file_path in xyz_files:
        output = xyz_reader(file_path)
        file_cluster = Atom_cluster(output['atomic positions'], output['box size'], monatomic=True)
        file_cluster.rms_stuff()

        accumulations.append(len(accumulations) + 1)
        proportions['fcc'].append(file_cluster.proportions['fcc'])
        proportions['bcc'].append(file_cluster.proportions['bcc'])
        proportions['hcp'].append(file_cluster.proportions['hcp'])
        proportions['none'].append(file_cluster.proportions['none'])

    # Calculate average proportions
    avg_fcc = np.mean(proportions['fcc']) * 100
    avg_bcc = np.mean(proportions['bcc']) * 100
    avg_hcp = np.mean(proportions['hcp']) * 100
    avg_none = np.mean(proportions['none']) * 100

    # Plotting the results
    fig, ax = plt.subplots(figsize=(12, 6))

    scaled_accumulations = [accum * 100 for accum in accumulations]
    ax.plot(scaled_accumulations, proportions['fcc'], label=f'FCC (avg: {avg_fcc:.2f}%)', marker='o')
    ax.plot(scaled_accumulations, proportions['bcc'], label=f'BCC (avg: {avg_bcc:.2f}%)', marker='o')
    ax.plot(scaled_accumulations, proportions['hcp'], label=f'HCP (avg: {avg_hcp:.2f}%)', marker='o')
    ax.plot(scaled_accumulations, proportions['none'], label=f'None (avg: {avg_none:.2f}%)', marker='o')

    ax.set_title('Structure Type Proportions vs Accumulations')
    ax.set_xlabel('EPSR Accumulations')
    ax.set_ylabel('Structure Proportion')

    max_scaled = max(scaled_accumulations)
    min_tick = 500  
    max_tick = ((max_scaled // 500) + 1) * 500
    ticks = np.arange(min_tick, max_tick + 1, 500)
    ax.set_xticks(ticks)

    ax.legend()
    
    # Adding grid to the plot with customization
    ax.grid(True, which='both', axis='both', linestyle='--', linewidth=1.5, color='gray')

    return fig

