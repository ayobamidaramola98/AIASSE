import pexpect
import os
import sys
import re

def run_pexpect_script():
    try:
        # Debugging output
        print("Starting search for Large_box/Large directory...")

        # Use the known directory path directly
        search_path = "/home/adaramo2/AIASSE_Nov_2024/"

        # Run a find command within the specified directory
        largebox_dir = pexpect.spawn(f"/bin/bash -c 'find {search_path} -type d -path \"*/Large_box/Large\" | head -n 1'").read().decode().strip()

        # Check if the directory was found
        if len(largebox_dir) == 0:
            print("Error: Large_box/Large directory not found.")
            sys.exit(1)

        print(f"Found Large_box/Large directory at: {largebox_dir}")

        # Define the path to the Largebox.ato file and verify it exists
        largebox_ato_file = os.path.join(largebox_dir, "Largebox.ato")
        if not os.path.exists(largebox_ato_file):
            print("Error: Largebox.ato file not found.")
            sys.exit(1)

        # Retrieve the atomic number density value
        with open(largebox_ato_file, 'r') as f:
            content = f.read()

        # Debugging: Print content of the file to inspect it
        print("Content of Largebox.ato file (first 200 chars):")
        print(content[:200])  # Only print the first 200 characters for brevity

        # Extract the atomic number density using regex or a simple string search
        match = re.search(r"Atomic number density\s*=\s*(\S+)", content)
        if match:
            density = match.group(1)
        else:
            print("Error: Could not retrieve atomic number density.")
            sys.exit(1)

        print(f"Atomic number density: {density}")

        # Interact with epsr25 shell using pexpect
        child = pexpect.spawn('sh epsr25')

        # Define the expected prompts and responses
        child.expect("EPSRshell> ")
        child.sendline("mixato")

        child.expect("How many .ATO files do you want to mix? ")
        child.sendline("1")

        child.expect("Search for .ato file")
        child.sendline("y")

        child.expect("How many of these molecules do you want in the mixture? ")
        child.sendline("150")

        child.expect("Give atomic number density (per A**3) of mixture: ")
        child.sendline(density)

        child.expect("Type name of file to put mixture in: ")
        child.sendline("Smallbox")

        child.expect("EPSRshell> ")
        child.sendline("randomise Smallbox")

        child.expect("EPSRshell> ")
        child.sendline("fmole Smallbox 100000")

        child.expect("EPSRshell> ")
        child.sendline("epsr Smallbox")

        child.expect("EPSRshell> ")
        child.sendline("exit")

        child.expect(pexpect.EOF)
        print("EPSR25 shell script completed successfully.")

    except pexpect.exceptions.ExceptionPexpect as e:
        print(f"pexpect error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    run_pexpect_script()

