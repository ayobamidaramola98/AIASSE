import os
import sys
import pty
import select
import shutil
import threading
import random
import subprocess
import time
import re

import numpy as np
import matplotlib.pyplot as plt
import pexpect

from subprocess import Popen, PIPE
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtCore import QThread
from PyQt5.QtWidgets import (
    QMainWindow, QAction, QMenu, QFileDialog, QMessageBox, QTextEdit, QLineEdit, QInputDialog
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from PyQt5.QtWidgets import QInputDialog, QMessageBox, QSplitter

# Project-specific imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))
from gr_plots import plot_rdf_gr
from Coordination_num import plot_cn
from gr_dft import process_folders
from excess_entropy import plot_excess_entropy
from lammps_reader import plot_local_structure 
from lammps_reader_mol import generate_com_xyz_files
from lammps_reader_mol import plot_local_structure_mol
from charge import ChargeCalculator


class Worker(QtCore.QThread):
    finished = QtCore.pyqtSignal(object)  # Generalized to accept any type
    error = QtCore.pyqtSignal(str)        # Emit error messages as strings

    def __init__(self, func, args=(), kwargs=None):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs or {}

    def run(self):
        """Run the specified function."""
        try:
            result = self.func(*self.args, **self.kwargs)  # Execute the function
            self.finished.emit(result)  # Emit the result (any type)
        except Exception as e:
            self.error.emit(str(e))  # Emit the error message


class MovingAtomsWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(MovingAtomsWidget, self).__init__(parent)
        self.setFixedSize(200, 200)  # Size of the widget

        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_positions)
        self.timer.start(50)  # Update every 50 milliseconds

        self.atoms = self.generate_atoms(300)  # Generate 300 atoms

    def generate_atoms(self, count):
        atoms = []
        colors = [QtGui.QColor("red"), QtGui.QColor("green"), QtGui.QColor("blue"),
                  QtGui.QColor("yellow"), QtGui.QColor("cyan"), QtGui.QColor("magenta")]

        for _ in range(count):
            color = random.choice(colors)
            x = random.randint(0, self.width() - 10)
            y = random.randint(0, self.height() - 10)
            dx = random.choice([-2, -1, 1, 2])
            dy = random.choice([-2, -1, 1, 2])
            atoms.append({"color": color, "x": x, "y": y, "dx": dx, "dy": dy})
        return atoms

    def update_positions(self):
        for atom in self.atoms:
            atom["x"] += atom["dx"]
            atom["y"] += atom["dy"]

            if atom["x"] <= 0 or atom["x"] >= self.width() - 10:
                atom["dx"] *= -1
            if atom["y"] <= 0 or atom["y"] >= self.height() - 10:
                atom["dy"] *= -1

        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)

        for atom in self.atoms:
            painter.setBrush(QtGui.QBrush(atom["color"]))
            painter.drawEllipse(atom["x"], atom["y"], 10, 10)  # Draw the atoms as circles

class BondLengthCalculator(QtCore.QObject):
    bond_length_figures_signal = pyqtSignal(list)  # Signal to send figures back to the GUI
    log_signal = pyqtSignal(str)  # Signal to send log messages

    def __init__(self, cp2k_directory, box_size, dr):
        super().__init__()
        self.cp2k_directory = cp2k_directory
        self.box_size = box_size
        self.dr = dr

    def calculate_bond_length(self):
        """Run bond length calculation directly using imported functions."""
        try:
            # Check if the CP2K directory exists
            if not os.path.exists(self.cp2k_directory):
                self.log_signal.emit(f"CP2K directory not found: {self.cp2k_directory}")
                return

            # Identify subdirectories in CP2K (e.g., 100acc, 200acc)
            subdirectories = [d for d in os.listdir(self.cp2k_directory) if os.path.isdir(os.path.join(self.cp2k_directory, d))]
            
            # Process each subdirectory
            bond_length_figures = []  # To hold the figures from the plots
            for subdir in subdirectories:
                subdir_path = os.path.join(self.cp2k_directory, subdir)
                try:
                    # Use the process_folders function from gr_dft to calculate bond lengths
                    fig = process_folders([subdir_path], self.box_size, self.dr)
                    bond_length_figures.append(fig)
                    self.log_signal.emit(f"Bond length calculation successful for {subdir}")
                except Exception as e:
                    self.log_signal.emit(f"Error in bond length calculation for {subdir}: {str(e)}")
            
            # Emit the signal with the bond length figures
            self.bond_length_figures_signal.emit(bond_length_figures)
        
        except Exception as e:
            self.log_signal.emit(f"Error during bond length calculation: {e}")

class DihedralAngleCalculator(QtCore.QObject):
    dihedral_angle_figures_signal = pyqtSignal(list)  # Signal to send figures back to the GUI
    log_signal = pyqtSignal(str)  # Signal to send log messages

    def __init__(self, cp2k_directory, box_size, dr):
        super().__init__()
        self.cp2k_directory = cp2k_directory
        self.box_size = box_size
        self.dr = dr

    def calculate_dihedral_angle(self):
        """Run dihedral angle calculation directly using imported functions."""
        try:
            # Check if the CP2K directory exists
            if not os.path.exists(self.cp2k_directory):
                self.log_signal.emit(f"CP2K directory not found: {self.cp2k_directory}")
                return

            # Identify subdirectories in CP2K (e.g., 100acc, 200acc)
            subdirectories = [d for d in os.listdir(self.cp2k_directory) if os.path.isdir(os.path.join(self.cp2k_directory, d))]

            # Process each subdirectory
            dihedral_angle_figures = []  # To hold the figures from the dihedral plots
            for subdir in subdirectories:
                subdir_path = os.path.join(self.cp2k_directory, subdir)
                try:
                    # Use the process_folders function (modified to calculate dihedral angles) to calculate dihedral angles
                    _, fig_dihedral = process_folders([subdir_path], self.box_size, self.dr)  # Returns bond length, bond angle and dihedral angle figures
                    dihedral_angle_figures.append(fig_dihedral)
                    self.log_signal.emit(f" Dihedral angles calculation successful for {subdir}")
                except Exception as e:
                    self.log_signal.emit(f"Error in dihedral angle calculation for {subdir}: {str(e)}")
            
            # Emit the signal with the dihedral angle figures
            self.dihedral_angle_figures_signal.emit(dihedral_angle_figures)
        
        except Exception as e:
            self.log_signal.emit(f"Error during dihedral angle calculation: {e}")

class Sidebar(QtWidgets.QWidget):
    # Define signals for each button click
    bond_length_triggered = pyqtSignal()
    charge_triggered = pyqtSignal()
    dihedral_angle_triggered = pyqtSignal()

    def __init__(self, parent=None):
        super(Sidebar, self).__init__(parent)
        self.layout = QtWidgets.QVBoxLayout(self)

        # Set margins and spacing to zero to avoid gaps
        self.layout.setContentsMargins(0, 0, 0, 0)  # No margins
        self.layout.setSpacing(0)  # Set minimal spacing between widgets

        # Adding buttons with minimal spacing
        self.bond_length_button = QtWidgets.QPushButton("Calculate New Bond Length")
        self.layout.addWidget(self.bond_length_button)

        self.charge_button = QtWidgets.QPushButton("Calculate New Charge")
        self.layout.addWidget(self.charge_button)

        self.dihedral_angle_button = QtWidgets.QPushButton("Calculate New Dihedral Angle")
        self.layout.addWidget(self.dihedral_angle_button)

        # Set the vertical layout for the sidebar
        self.setLayout(self.layout)

        # Connect buttons to their respective signals
        self.bond_length_button.clicked.connect(self.on_bond_length_clicked)
        self.charge_button.clicked.connect(self.on_charge_clicked)
        self.dihedral_angle_button.clicked.connect(self.on_dihedral_angle_clicked)

    def on_bond_length_clicked(self):
        """ Slot to handle bond length button click """
        self.bond_length_triggered.emit()  # Emit the signal for bond length action
        print("Bond Length button clicked")

    def on_charge_clicked(self):
        """ Slot to handle charge button click """
        self.charge_triggered.emit()  # Emit the signal for charge action
        print("Charge button clicked")

    def on_dihedral_angle_clicked(self):
        """ Slot to handle dihedral angle button click """
        self.dihedral_angle_triggered.emit()  # Emit the signal for dihedral angle action
        print("Dihedral Angle button clicked")

class Ui_MainWindow(QtWidgets.QMainWindow):
    update_output_signal = pyqtSignal(str)


    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setWindowTitle("AIASSE version 1.0 by Ayobami and Cip")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("AIASSE_logo/AIASSE.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)

        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setObjectName("centralWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralWidget)
        self.gridLayout.setObjectName("gridLayout")
        # Sidebar with vertical buttons (placed on the right)
        self.sidebar = Sidebar(self.centralWidget)
        self.gridLayout.addWidget(self.sidebar, 1, 1)  # Sidebar in row 1, column 1
        # Menu bar
        self.menuBar = QtWidgets.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 800, 22))
        self.menuBar.setObjectName("menuBar")
        
        # Only Settings and Documentation menus
        self.menuSettings = QtWidgets.QMenu(self.menuBar)
        self.menuSettings.setObjectName("menuSettings")
        self.menuDocumentation = QtWidgets.QMenu(self.menuBar)
        self.menuDocumentation.setObjectName("menuDocumentation")
        # Add new Plot menu
        self.menuPlot = QtWidgets.QMenu(self.menuBar)
        self.menuPlot.setObjectName("menuPlot")
        self.menuPlot.setTitle("Plot")
        self.menuBar.addAction(self.menuPlot.menuAction())
        
        # Create actions for the Plot menu
        self.rdfCnAction = QtWidgets.QAction("RDF & CN", MainWindow)
        self.excessEntropyAction = QtWidgets.QAction("Excess Entropy", MainWindow)
        self.AJanalysisAction = QtWidgets.QAction("Ackland-Jones (monoatomic)", MainWindow)
        self.AJanalysis_molAction = QtWidgets.QAction("Ackland-Jones (molecules)", MainWindow)
        
        # Add actions to the Plot menu
        self.menuPlot.addAction(self.rdfCnAction)
        self.menuPlot.addAction(self.excessEntropyAction)
        self.menuPlot.addAction(self.AJanalysisAction)
        self.menuPlot.addAction(self.AJanalysis_molAction)
        
        # Connect actions to respective methods (these methods need to be defined)
        self.rdfCnAction.triggered.connect(self.plot_rdf_and_cn)
        self.excessEntropyAction.triggered.connect(self.plot_excess_entropy)
        self.AJanalysisAction.triggered.connect(self.plot_local_structure)
        self.AJanalysis_molAction.triggered.connect(self.plot_local_structure_mol)
        
        MainWindow.setMenuBar(self.menuBar)
        self.menuBar.addAction(self.menuSettings.menuAction())
        self.menuBar.addAction(self.menuDocumentation.menuAction())

        self.menuSettings.setTitle("Settings")
        self.menuDocumentation.setTitle("Documentation")

        # Settings Menu Actions
        self.setEpsrPathAction = QtWidgets.QAction("Set EPSR Path", MainWindow)
        self.setCp2kPathAction = QtWidgets.QAction("Set CP2K Path", MainWindow)
        self.setCastepPathAction = QtWidgets.QAction("Set CASTEP Path", MainWindow)
        self.menuSettings.addAction(self.setEpsrPathAction)
        self.menuSettings.addAction(self.setCp2kPathAction)
        self.menuSettings.addAction(self.setCastepPathAction)

        # Button layout
        self.buttonLayout = QtWidgets.QHBoxLayout()
        
        # Run Large Box button (with actions in a menu)
        self.runLargeBoxButton = QtWidgets.QPushButton("Run Large Box", self.centralWidget)
        self.runLargeBoxButton.setObjectName("runLargeBoxButton")
        self.runLargeBoxMenu = QtWidgets.QMenu(self.runLargeBoxButton)

        self.deleteLargeBoxAction = QtWidgets.QAction("Delete Large Box", MainWindow)
        self.extractLargeBoxAction = QtWidgets.QAction("Extract Large Boxes", MainWindow)
        self.stopExtractButton = QtWidgets.QAction("Stop Extracting Large Boxes", MainWindow)
        self.updateLargeBoxButton = QtWidgets.QAction("Update Large Boxes", MainWindow)
        
    
        self.runLargeBoxMenu.addAction(self.deleteLargeBoxAction)
        self.runLargeBoxMenu.addAction(self.extractLargeBoxAction)
        self.runLargeBoxMenu.addAction(self.stopExtractButton)
        self.runLargeBoxMenu.addAction(self.updateLargeBoxButton)

        self.runLargeBoxButton.setMenu(self.runLargeBoxMenu)
        self.buttonLayout.addWidget(self.runLargeBoxButton)
        
        # Run Small Box button (with actions in a menu)
        self.runSmallBoxButton = QtWidgets.QPushButton("Run Small Box", self.centralWidget)
        self.runSmallBoxButton.setObjectName("runSmallBoxButton")
        self.runSmallBoxMenu = QtWidgets.QMenu(self.runSmallBoxButton)
        
        
        self.transferfilesAction = QtWidgets.QAction("Obtain Large Box Potential", MainWindow)
        self.createBoxButton = QtWidgets.QAction("Create Box", MainWindow)
        self.extractSmallBoxAction = QtWidgets.QAction("Extract Small Boxes", MainWindow)
        self.stopextractButton = QtWidgets.QAction("Stop Extracting Small Boxes", MainWindow)
        self.deleteSmallBoxAction = QtWidgets.QAction("Delete Small Box", MainWindow)
        self.DFTBoxAction = QtWidgets.QAction("Send DFT Box", MainWindow)
        
        self.runSmallBoxMenu.addAction(self.transferfilesAction)
        self.runSmallBoxMenu.addAction(self.createBoxButton)
        self.runSmallBoxMenu.addAction(self.extractSmallBoxAction)
        self.runSmallBoxMenu.addAction(self.stopextractButton)
        self.runSmallBoxMenu.addAction(self.deleteSmallBoxAction)
        self.runSmallBoxMenu.addAction(self.DFTBoxAction)

        self.runSmallBoxButton.setMenu(self.runSmallBoxMenu)
        self.buttonLayout.addWidget(self.runSmallBoxButton)
        
        # DFT Setup Button
        self.dftSetupButton = QtWidgets.QPushButton("DFT Setup", self.centralWidget)
        self.dftSetupButton.setObjectName("dftSetupButton")
        self.dftSetupMenu = QtWidgets.QMenu(self.dftSetupButton)
        
        self.CP2KAction = QtWidgets.QAction("CP2K", MainWindow)
        self.CASTEPAction = QtWidgets.QAction("CASTEP", MainWindow)      
        self.dftSetupMenu.addAction(self.CP2KAction)
        self.dftSetupMenu.addAction(self.CASTEPAction)
        self.dftSetupButton.setMenu(self.dftSetupMenu)
        self.buttonLayout.addWidget(self.dftSetupButton)
         
        
        # Add to layout
        self.gridLayout.addLayout(self.buttonLayout, 0, 0, 1, 1)
        
        # Container widget for EPSR outputs
        self.outputTextEdit = QtWidgets.QTextEdit(self.centralWidget)
        self.outputTextEdit.setObjectName("outputTextEdit")
        self.gridLayout.addWidget(self.outputTextEdit, 1, 0, 1, 1)
        
        MainWindow.setCentralWidget(self.centralWidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        # Bottom layout for images
        self.bottomLayout = QtWidgets.QHBoxLayout()
                # Plot area setup with QSplitter
        self.splitter = QSplitter(QtCore.Qt.Horizontal)
        self.splitter.setObjectName("splitter")

        # Add splitter to layout
        self.gridLayout.addWidget(self.splitter, 1, 0, 1, 1)


        # Add spacer on the left, then left logo, spacer, right logo, and spacer on the right
        self.leftLogoLabel = QtWidgets.QLabel(self.centralWidget)
        self.rightLogoLabel = QtWidgets.QLabel(self.centralWidget)
                # Add the MovingAtomsWidget at the bottom-right corner
        self.movingAtomsWidget = MovingAtomsWidget(self.centralWidget)
        self.gridLayout.addWidget(self.movingAtomsWidget, 2, 1, 1, 1, alignment=QtCore.Qt.AlignBottom | QtCore.Qt.AlignRight)

        # Set the pixmap for each label to the image AIASSE.png
        pixmap = QtGui.QPixmap("AIASSE_logo/AIASSE.png")

        # Scale the image to a larger size (e.g., 150x150 pixels)
        self.leftLogoLabel.setPixmap(pixmap.scaled(250, 250, QtCore.Qt.KeepAspectRatio))
        self.rightLogoLabel.setPixmap(pixmap.scaled(250, 250, QtCore.Qt.KeepAspectRatio))

        # Ensure the labels are transparent
        self.leftLogoLabel.setStyleSheet("background-color: transparent;")
        self.rightLogoLabel.setStyleSheet("background-color: transparent;")

        # Add spacers and widgets to the layout
        self.bottomLayout.addSpacerItem(QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum))
        self.bottomLayout.addWidget(self.leftLogoLabel)
        self.bottomLayout.addSpacerItem(QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum))
        self.bottomLayout.addWidget(self.rightLogoLabel)
        self.bottomLayout.addSpacerItem(QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum))

        # Add the bottom layout to the main grid layout
        self.gridLayout.addLayout(self.bottomLayout, 2, 0, 1, 1)

        # Version Label at the bottom-left corner
        self.versionLabel = QtWidgets.QLabel(self.centralWidget)
        self.versionLabel.setText("AIASSE version 1.0")
        self.versionLabel.setStyleSheet("background-color: transparent;")
        self.versionLabel.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignBottom)
        self.gridLayout.addWidget(self.versionLabel, 3, 0)

        
        # Connect actions to functions
        self.setEpsrPathAction.triggered.connect(lambda: self.set_executable_path("epsr"))
        self.setCp2kPathAction.triggered.connect(lambda: self.set_executable_path("cp2k"))
        self.setCastepPathAction.triggered.connect(lambda: self.set_executable_path("castep"))

        # Connect buttons to their functions
        self.deleteLargeBoxAction.triggered.connect(self.delete_large_box)
        self.extractLargeBoxAction.triggered.connect(self.extract_large_box)
        self.stopExtractButton.triggered.connect(self.stop_extracting_large_box)
        self.updateLargeBoxButton.triggered.connect(self.updating_large_box)
        self.transferfilesAction.triggered.connect(self.transfer_files)
        self.createBoxButton.triggered.connect(self.create_box)
        self.extractSmallBoxAction.triggered.connect(self.extract_small_box)
        self.stopextractButton.triggered.connect(self.stop_extracting_small_box)
        self.deleteSmallBoxAction.triggered.connect(self.delete_small_box)
        self.DFTBoxAction.triggered.connect(self.produce_DFT_box)
        self.runLargeBoxButton.clicked.connect(self.run_large_box)
        self.runSmallBoxButton.clicked.connect(self.run_small_box)
        self.dftSetupButton.clicked.connect(self.dft_setup)
        self.CP2KAction.triggered.connect(lambda: self.setup_cp2k(MainWindow))
        self.CASTEPAction.triggered.connect(self.setup_castep)
        # Connect the sidebar signals to the main window functions
        self.sidebar.bond_length_triggered.connect(self.calculate_new_bond_length)
        self.sidebar.charge_triggered.connect(self.calculate_new_charge)
        self.sidebar.dihedral_angle_triggered.connect(self.calculate_new_dihedral_angle)        
        self.update_output_signal.connect(self.append_to_output)
        

        # Initialize paths and process attributes
        self.epsr_path = None
        self.cp2k_path = None
        self.castep_path = None
        self.extract_process = None
        self.is_running = False
        self.current_plot_canvas = None  # Hold reference to current plot canvas
        self.entropy_canvas = None
          

        # Adjust version label position when the window is resized
        MainWindow.resizeEvent = self.resize_event

    def resize_event(self, event):
        self.versionLabel.move(10, event.size().height() - 30)
        super().resizeEvent(event)

    def set_executable_path(self, exec_type):
        options = QtWidgets.QFileDialog.Options()
        options |= QtWidgets.QFileDialog.ReadOnly
        fileName, _ = QtWidgets.QFileDialog.getOpenFileName(None, "Select Executable", "", "Executables (*);;All Files (*)", options=options)
        
        if fileName:
            if exec_type == "epsr":
                self.epsr_path = fileName
                self.statusbar.showMessage(f"EPSR path set to: {fileName}")
                # Run EPSR immediately
                self.run_large_box()
            elif exec_type == "cp2k":
                self.cp2k_path = fileName
                self.statusbar.showMessage(f"CP2K path set to: {fileName}")
            elif exec_type == "castep":
                self.castep_path = fileName
                self.statusbar.showMessage(f"CASTEP path set to: {fileName}")

    def show_error_dialog(self, message):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Critical)
        msgBox.setText(message)
        msgBox.setWindowTitle("Error")
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgBox.exec_()

    def append_to_output(self, message: str):
        self.outputTextEdit.append(message)  # Append the string directly
        
    def run_large_box(self):
        if not self.epsr_path:
            self.show_error_dialog("EPSR path is not set. Please set it in the Settings menu.")
            return

        if not os.path.isfile(self.epsr_path):
            self.show_error_dialog(f"EPSR path is not valid: {self.epsr_path}")
            return

        os.makedirs("Large_box", exist_ok=True)
        self.outputTextEdit.append("Created directory: Large_box")

        if self.extract_process and self.extract_process.state() == QtCore.QProcess.Running:
            self.extract_process.terminate()
            self.extract_process.waitForFinished()

        try:
            self.extract_process = QtCore.QProcess(self.centralWidget)
            self.extract_process.setProgram(self.epsr_path)
            
            # Optional: Set working directory if needed
            # self.extract_process.setWorkingDirectory("Large_box")

            self.extract_process.readyReadStandardOutput.connect(
                lambda: self.outputTextEdit.append(
                    self.extract_process.readAllStandardOutput().data().decode()
                )
            )
            self.extract_process.readyReadStandardError.connect(
                lambda: self.outputTextEdit.append(
                    self.extract_process.readAllStandardError().data().decode()
                )
            )
            self.extract_process.finished.connect(
                lambda: self.outputTextEdit.append("EPSR process finished")
            )
            
            self.extract_process.start()
            if not self.extract_process.waitForStarted():
                self.show_error_dialog(f"Failed to start EPSR: {self.extract_process.errorString()}")

        except Exception as e:
            self.show_error_dialog(f"Error running EPSR: {e}")

    def run_small_box(self):
        # Create Small_box and Small directories
        if not os.path.exists('Small_box'):
            os.makedirs('Small_box/Small')


        print("Small box setup complete.")        
   
    def delete_large_box(self):
        folder_path = 'Large_box'
        if os.path.exists(folder_path):
            shutil.rmtree(folder_path)
            print(f'{folder_path} deleted successfully.')
        else:
            print(f'{folder_path} does not exist.')

    def delete_small_box(self):
        folder_path = 'Small_box'
        if os.path.exists(folder_path):
            shutil.rmtree(folder_path)
            print(f'{folder_path} deleted successfully.')
        else:
            print(f'{folder_path} does not exist.')
    
    def transfer_files(self):
        """Transfer files from Large_box to Small_box."""
        try:
            # Define the absolute path to the Results directory
            source_folder = 'Large_box/Large'
            destination_folder = 'Small_box/Small'

            # Ensure the Results directory exists
            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder)
                self.outputTextEdit.append(f"Created directory: {destination_folder}")

            files_to_modify = {
                'Largebox.EPSR.p01': 'Smallbox.EPSR.p01',
                'Largebox.EPSR.inp': 'Smallbox.EPSR.inp',
                'Large.ato': 'Small.ato',
                'Largebox.pcof': 'Smallbox.pcof',
                'Large.mol': 'Small.mol',
                'Large.EPSR.pro': 'Small.EPSR.pro',
                'Large.jmol': 'Small.jmol',
            }

            # Copy and modify the primary files
            for filename, new_filename in files_to_modify.items():
                source_file = os.path.join(source_folder, filename)
                destination_file = os.path.join(destination_folder, new_filename)

                if os.path.exists(source_file) and 'Largebox.ato' not in filename:
                    shutil.copyfile(source_file, destination_file)

                    if filename == 'Largebox.EPSR.inp':
                        self.modify_epsr_inp(destination_file)

                    if filename == 'Large.EPSR.pro':
                        self.modify_epsr_pro(destination_file)

                    if filename == 'Largebox.EPSR.p01':
                        os.chmod(destination_file, 0o444)  # read-only

                    self.outputTextEdit.append(f'File {filename} copied and renamed to {new_filename}')

            # Transfer additional files without modification
            additional_files = ['.mint01', '.NWTStot.wts', 'NWTS.dat']
            for filename in os.listdir(source_folder):
                if any(filename.endswith(ext) for ext in additional_files):
                    source_file = os.path.join(source_folder, filename)
                    destination_file = os.path.join(destination_folder, filename)

                    if os.path.exists(source_file):
                        shutil.copyfile(source_file, destination_file)

                        # Modify NWTS.dat to replace the second line
                        if filename.endswith('NWTS.dat'):
                            self.modify_nwts_dat(destination_file)

                        self.outputTextEdit.append(f'File {filename} copied to {destination_folder}')

        except Exception as e:
            self.outputTextEdit.append(f"Error transferring files: {str(e)}")

    def modify_epsr_inp(self, filepath):
        """Modify the EPSR input file."""
        with open(filepath, 'r+') as file:
            content = file.read()
            content = content.replace('Largebox.EPSR', 'Smallbox.EPSR')
            content = content.replace('fnameato    Largebox.ato', 'fnameato    Smallbox.ato')
            content = content.replace('fnamepcof   Largebox.pcof', 'fnamepcof   Smallbox.pcof')
            content = content.replace('potfac      1.0', 'potfac      0.0')
            content = content.replace('nsumt       -1', 'nsumt       0')

            file.seek(0)
            file.write(content)
            file.truncate()

    def modify_epsr_pro(self, filepath):
        """Modify the EPSR pro file."""
        with open(filepath, 'r+') as file:
            content = file.read()
            content = content.replace('mol Large.mol 1000', 'mol Small.mol 300')
            content = content.replace('boxAtoFileName Largebox.ato', 'boxAtoFileName Smallbox.ato')
            content = content.replace('EPSRinp Largebox', 'EPSRinp Smallbox')

            file.seek(0)
            file.write(content)
            file.truncate()

    def modify_nwts_dat(self, filepath):
        """Modify the NWTS.dat file to change the second line."""
        with open(filepath, 'r+') as file:
            lines = file.readlines()

            if len(lines) > 1:  # Ensure there's at least two lines to modify
                lines[1] = lines[1].replace('fnameato    Largebox.ato', 'fnameato    Smallbox.ato')

            file.seek(0)
            file.writelines(lines)


    def run_shell_script(self, script_path, cwd):
        try:
            # Run the shell script using 'expect'
            process = subprocess.Popen(
                ['expect', script_path],
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout, stderr = process.communicate()

            # Display output and errors
            if stdout:
                self.outputTextEdit.append(f"Output: {stdout.decode()}")
            if stderr:
                self.outputTextEdit.append(f"Error: {stderr.decode()}")

        except Exception as e:
            self.show_error_dialog(f"Error occurred: {e}")

    def create_box(self):
        # Define directories and file paths
        small_box_dir = os.path.join("Small_box", "Small")
        script_dir = os.path.dirname(os.path.abspath(__file__))
        src_dir = os.path.join(script_dir, 'src')
        
        # Source files
        epsr25_file = os.path.join(src_dir, "epsr25")
        shell_script_file = os.path.join(src_dir, "shell.sh")

        # Destination files in the small_box_dir
        dest_epsr25_file = os.path.join(small_box_dir, os.path.basename(epsr25_file))
        dest_shell_script_file = os.path.join(small_box_dir, os.path.basename(shell_script_file))

        try:
            # Ensure the destination directory exists
            if not os.path.exists(small_box_dir):
                os.makedirs(small_box_dir)

            # Copy files
            shutil.copy(epsr25_file, dest_epsr25_file)
            shutil.copy(shell_script_file, dest_shell_script_file)

            # Make the copied files executable
            os.chmod(dest_epsr25_file, 0o755)
            os.chmod(dest_shell_script_file, 0o755)

            # Debug messages to verify success
            if not os.path.isfile(dest_epsr25_file):
                self.show_error_dialog(f"File '{dest_epsr25_file}' not found after copy.")
            if not os.path.isfile(dest_shell_script_file):
                self.show_error_dialog(f"File '{dest_shell_script_file}' not found after copy.")
            
            # Output success message
            self.outputTextEdit.append(f"Files '{epsr25_file}' and '{shell_script_file}' successfully copied to '{small_box_dir}'.")

            # Print the current working directory for debugging
            self.outputTextEdit.append(f"Current working directory: {os.getcwd()}")
            
            # Print files in the target directory
            self.outputTextEdit.append(f"Files in '{small_box_dir}': {os.listdir(small_box_dir)}")

            # Run the shell script in a separate thread
            script_thread = threading.Thread(
                target=self.run_shell_script,
                args=(shell_script_file, small_box_dir)
            )
            script_thread.start()

        except Exception as e:
            # Show error message in case of any exceptions
            self.show_error_dialog(f"Error occurred: {e}")
                        
    def read_output(self):
        output = self.process.readAllStandardOutput().data().decode()
        self.outputTextEdit.append(output)

    def send_command(self):
        command = self.inputLineEdit.text().strip()
        if self.process and self.process.state() == QtCore.QProcess.Running:
            self.process.write((command + '\n').encode())
            self.inputLineEdit.clear()
        else:
            self.outputTextEdit.append("No active process to send command to.")

    def on_epsr_process_finished(self, exit_code, exit_status):
        if exit_code == 0:
            self.outputTextEdit.append("EPSR file execution completed successfully.")
        else:
            self.outputTextEdit.append(f"EPSR process finished with exit code {exit_code} and status {exit_status}")

    def extract_large_box(self):
        large_dir = "Large_box/Large"
        
        # Ensure the Large directory exists
        if not os.path.exists(large_dir):
            self.show_error_dialog(f"Directory does not exist: {large_dir}")
            return

        # Define the script path in the current directory
        script_source_path = os.path.join('src', 'run_epsr.sh')
        
        # Define the destination script path in the Large directory
        script_destination_path = os.path.join(large_dir, "run_epsr.sh")
        
        # Check if the source script file exists
        if not os.path.isfile(script_source_path):
            self.show_error_dialog(f"Script file does not exist: {script_source_path}")
            return

        # Copy the script file to the Large directory
        shutil.copy(script_source_path, script_destination_path)

        # Make the script executable
        os.chmod(script_destination_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(large_dir)  # Set working directory to the Large directory
        self.extract_process.setProgram("/bin/bash")
        self.extract_process.setArguments([f"./run_epsr.sh"])
        self.extract_process.start()

        # Connect signals to handle output and completion
        self.extract_process.readyReadStandardOutput.connect(lambda: self.outputTextEdit.append(self.extract_process.readAllStandardOutput().data().decode()))
        self.extract_process.readyReadStandardError.connect(lambda: self.outputTextEdit.append(f"Error: {self.extract_process.readAllStandardError().data().decode()}"))
        self.extract_process.finished.connect(self.on_extraction_finished)

    def on_extraction_finished(self, exit_code, exit_status):
        self.outputTextEdit.append(f"Extraction script finished with exit code {exit_code} and status {exit_status}")
        
        # Check if the expected folder was created
        expected_folder = os.path.join("Large_box/Large", "Accumulation_dependence")
        if os.path.exists(expected_folder):
            self.outputTextEdit.append(f"Success: {expected_folder} was created.")
        else:
            self.outputTextEdit.append(f"Error: {expected_folder} was not created. Check the script output for details.")        

    def stop_extracting_large_box(self):
        if hasattr(self, 'extract_process') and self.extract_process.state() == QtCore.QProcess.Running:
            self.extract_process.terminate()
            self.outputTextEdit.append("Extraction script terminated")

            # Define the source and destination paths for LB_xyz.sh
            script_source_path = os.path.join('src', 'LB_xyz.sh')  # LB_xyz.sh in the same folder as AIASSE.py
            accumulation_folder = "Large_box/Large/Accumulation_dependence"

            # Ensure the accumulation folder exists, or show an error
            if not os.path.exists(accumulation_folder):
                self.show_error_dialog(f"Accumulation directory does not exist: {accumulation_folder}")
                return

            # Define the destination path for LB_xyz.sh in the accumulation folder
            script_destination_path = os.path.join(accumulation_folder, "LB_xyz.sh")
            
            # Copy the LB_xyz.sh script to the accumulation folder
            shutil.copy(script_source_path, script_destination_path)

            # After copying the script, execute it
            self.produce_LB_xyz_box()

    def produce_LB_xyz_box(self):
        # Get the current working directory
        current_directory = os.getcwd()

        # Define the relative path to Accumulation_dependence folder
        accumulation_folder = os.path.join(current_directory, "Large_box", "Large", "Accumulation_dependence")

        # Check if the accumulation folder exists
        if not os.path.exists(accumulation_folder):
            self.outputTextEdit.append(f"Error: Accumulation directory does not exist: {accumulation_folder}")
            return

        # Define the path to the LB_xyz.sh script within that directory
        script_path = os.path.join(accumulation_folder, "LB_xyz.sh")

        # Check if LB_xyz.sh exists
        if not os.path.isfile(script_path):
            self.outputTextEdit.append(f"Error: Script {script_path} does not exist.")
            return

        # Make sure the script is executable
        os.chmod(script_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(accumulation_folder)  # Set working directory
        self.extract_process.setProgram("/usr/bin/expect")
        self.extract_process.setArguments([script_path])
        self.extract_process.start()

        # Connect signals for handling process output and completion
        self.extract_process.readyReadStandardOutput.connect(self.handle_output)
        self.extract_process.readyReadStandardError.connect(self.handle_error)
        self.extract_process.finished.connect(self.handle_finished)

        # Output message
        self.outputTextEdit.append("Started running LB_xyz.sh script in Accumulation_dependence folder.")



    def extract_small_box(self):
        small_dir = "Small_box/Small"
        
        # Ensure the Small directory exists
        if not os.path.exists(small_dir):
            self.show_error_dialog(f"Directory does not exist: {Small_dir}")
            return

        # Define the script path in the current directory
        script_source_path = os.path.join("src", "run_epsr.sh")
        
        # Define the destination script path in the small directory
        script_destination_path = os.path.join(small_dir, "run_epsr.sh")
        
        # Check if the source script file exists
        if not os.path.isfile(script_source_path):
            self.show_error_dialog(f"Script file does not exist: {script_source_path}")
            return

        # Copy the script file to the Large directory
        shutil.copy(script_source_path, script_destination_path)

        # Make the script executable
        os.chmod(script_destination_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(small_dir)  # Set working directory to the Small directory
        self.extract_process.setProgram("/bin/bash")
        self.extract_process.setArguments([f"./run_epsr.sh"])
        self.extract_process.start()

        # Connect signals to handle output and completion
        self.extract_process.readyReadStandardOutput.connect(lambda: self.outputTextEdit.append(self.extract_process.readAllStandardOutput().data().decode()))
        self.extract_process.readyReadStandardError.connect(lambda: self.outputTextEdit.append(f"Error: {self.extract_process.readAllStandardError().data().decode()}"))
        self.extract_process.finished.connect(self.on_extraction_finished)

    def on_extraction_finished_small(self, exit_code, exit_status):
        self.outputTextEdit.append(f"Extraction script finished with exit code {exit_code} and status {exit_status}")
        
        # Check if the expected folder was created
        expected_folder = os.path.join("Small_box/Small", "accumulation_dependence")
        if os.path.exists(expected_folder):
            self.outputTextEdit.append(f"Success: {expected_folder} was created.")
        else:
            self.outputTextEdit.append(f"Error: {expected_folder} was not created. Check the script output for details.")
            
    def stop_extracting_small_box(self):
        if hasattr(self, 'extract_process') and self.extract_process.state() == QtCore.QProcess.Running:
            self.extract_process.terminate()
            self.outputTextEdit.append("Extraction script terminated")

            # Define the source and destination paths for xyz.sh
            script_source_path = os.path.join("src", "xyz.sh")  # xyz.sh in the same folder as AIASSE.py
            accumulation_folder = "Small_box/Small/Accumulation_dependence"

            # Ensure the accumulation folder exists, or show an error
            if not os.path.exists(accumulation_folder):
                self.show_error_dialog(f"Accumulation directory does not exist: {accumulation_folder}")
                return

            # Define the destination path for xyz.sh in the accumulation folder
            script_destination_path = os.path.join(accumulation_folder, "xyz.sh")
            
            # Copy the xyz.sh script to the accumulation folder
            shutil.copy(script_source_path, script_destination_path)

    def produce_DFT_box(self):
        # Get the current working directory
        current_directory = os.getcwd()

        # Define the relative path to Accumulation_dependence folder
        accumulation_folder = os.path.join(current_directory, "Small_box", "Small", "Accumulation_dependence")

        # Check if the accumulation folder exists
        if not os.path.exists(accumulation_folder):
            self.outputTextEdit.append(f"Error: Accumulation directory does not exist: {accumulation_folder}")
            return

        # Define the path to the xyz.sh script within that directory
        script_path = os.path.join(accumulation_folder, "xyz.sh")

        # Check if xyz.sh exists
        if not os.path.isfile(script_path):
            self.outputTextEdit.append(f"Error: Script {script_path} does not exist.")
            return

        # Make sure the script is executable
        os.chmod(script_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(accumulation_folder)  # Set working directory
        self.extract_process.setProgram("/usr/bin/expect")
        self.extract_process.setArguments([script_path])
        self.extract_process.start()

        # Connect signals for handling process output and completion
        self.extract_process.readyReadStandardOutput.connect(self.handle_output)
        self.extract_process.readyReadStandardError.connect(self.handle_error)
        self.extract_process.finished.connect(self.handle_finished)

        # Output message
        self.outputTextEdit.append("Started running xyz.sh script in Accumulation_dependence folder.")

    def handle_output(self):
        # Read the output from the process and append it to the output text edit
        output = self.extract_process.readAllStandardOutput().data().decode()
        self.outputTextEdit.append(output)

    def handle_error(self):
        # Read the error output from the process and append it to the output text edit
        error = self.extract_process.readAllStandardError().data().decode()
        self.outputTextEdit.append(f"Error: {error}")

    def handle_finished(self, exit_code, exit_status):
        # Display message when the script finishes
        self.outputTextEdit.append(f"Script finished with exit code {exit_code} and status {exit_status}")

    # Function for DFT setup
    def dft_setup(self):
        pass
# CP2K and CASTEP setup functions

    def setup_cp2k(self, MainWindow):
        """Set up CP2K by copying required files and executing CP2K on .xyz files."""
        # Define paths
        current_directory = os.getcwd()

        # Path to the folder where .xyz files are located
        source_folder = os.path.join(current_directory, "Small_box", "Small", "Accumulation_dependence", "DFT_box")

        # Path to the home folder where static files are located (assuming it's the same directory as this script)
        home_folder = os.path.join(current_directory, "src")

        # Destination folder where CP2K runs will happen, now under "Results"
        cp2k_folder = os.path.join(current_directory, "C2PK")

        # List of required static files with paths pointing to the home folder
        required_files = [
            os.path.join(home_folder, "GTH_POTENTIALS"),
            os.path.join(home_folder, "dftd3.dat"),
            os.path.join(home_folder, "BASIS_MOLOPT"),
            os.path.join(home_folder, "cp2k.psmp"),
            os.path.join(home_folder, "aiasse.inp")  # Template input file
        ]


        # Create C2PK folder if it doesn't exist
        if not os.path.exists(cp2k_folder):
            os.makedirs(cp2k_folder)
            self.outputTextEdit.append("C2PK folder created.")

        # Select the CP2K executable file
        cp2k_executable, _ = QFileDialog.getOpenFileName(MainWindow, "Select CP2K Executable", "", "Executable Files (*)")
        if not cp2k_executable:
            self.outputTextEdit.append("No CP2K executable selected.")
            return

        # Set CP2K executable path
        self.cp2k_path = cp2k_executable
        self.statusbar.showMessage(f"CP2K path set to: {cp2k_executable}")

        # Change permissions of the selected executable
        try:
            os.chmod(cp2k_executable, 0o755)  # Sets the permission to rwxr-xr-x
            self.outputTextEdit.append("CP2K executable permissions set to executable.")
        except Exception as e:
            self.outputTextEdit.append(f"Error setting permissions for CP2K executable: {e}")
            return

        # Function to search and copy required static files
        def search_and_copy_file(filepath, destination):
            if os.path.exists(filepath):
                shutil.copy(filepath, destination)
                filename = os.path.basename(filepath)
                self.outputTextEdit.append(f"{filename} found and copied to {destination}.")
            else:
                filename = os.path.basename(filepath)
                self.outputTextEdit.append(f"{filename} not found in {os.path.dirname(filepath)}.")

        # Search and copy required static files from the src folder
        for file_path in required_files:
            search_and_copy_file(file_path, cp2k_folder)

        # Process all .xyz files from the DFT_Box folder
        xyz_files = [f for f in os.listdir(source_folder) if f.endswith(".xyz")]

        if not xyz_files:
            self.outputTextEdit.append("No .xyz files found in DFT_Box.")
            return

        self.outputTextEdit.append(f"Found {len(xyz_files)} .xyz files. Starting CP2K runs...")

        # Start CP2K runs in a new thread to avoid freezing the GUI
        self.is_running = True
        threading.Thread(target=self.run_all_cp2k, args=(xyz_files, cp2k_folder, cp2k_executable, source_folder)).start()

    def run_all_cp2k(self, xyz_files, cp2k_folder, cp2k_executable, source_folder):
        """Create a SLURM array job to run CP2K for multiple .xyz files."""
        def submit_job():
            try:
                # Create a file listing all the xyz files
                xyz_list_file = os.path.join(castep_folder, "xyz_file_list.txt")
                with open(xyz_list_file, "w") as f:
                    for xyz_file in xyz_files:
                        f.write(f"{xyz_file}\n")
                
                # Create the SLURM batch script for the array job
                slurm_script_path = os.path.join(cp2k_folder, "cp2k_array_job.sh")
                with open(slurm_script_path, "w") as slurm_script:
                    slurm_script.write(f"""#!/bin/bash
#SBATCH --job-name=AIASSE
#SBATCH --partition=long
#SBATCH --time=7-00:00:00
#SBATCH --ntasks=48
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --array=0-{len(xyz_files)-1}  # Job array index based on number of xyz files

# Get the xyz file for this array task
xyz_file=$(sed -n "${{SLURM_ARRAY_TASK_ID}}p" {xyz_list_file})
base_name=$(basename ${{xyz_file}} .xyz)

# Create output folder for this job
output_folder={cp2k_folder}/$base_name
mkdir -p $output_folder

# Set SLURM output and error files in the job folder
#SBATCH --output=$output_folder/%A_%a_DFT.output
#SBATCH --error=$output_folder/%A_%a_DFT.error

# Load CP2K module

# Copy static files
cp {cp2k_folder}/GTH_POTENTIALS $output_folder
cp {cp2k_folder}/dftd3.dat $output_folder
cp {cp2k_folder}/BASIS_MOLOPT $output_folder

# Create input file by replacing the XYZ file in the template
input_file=$output_folder/${{base_name}}_aiasse.inp
sed "s|COORD_FILE_NAME.*|COORD_FILE_NAME {source_folder}/${{xyz_file}}|" {cp2k_folder}/aiasse.inp > $input_file

# Run CP2K
cd $output_folder
srun {cp2k_executable} -in $input_file > $output_folder/${{base_name}}_DFT.output
""")
            
                submit_command = f"sbatch {slurm_script_path}"
                result = subprocess.run(submit_command, shell=True, check=True)
                self.update_output_signal.emit(f"Submitted SLURM array job for {len(xyz_files)} XYZ files.")
            except subprocess.CalledProcessError as e:
                self.update_output_signal.emit(f"SLURM job submission failed: {e}")
            except Exception as e:
                self.update_output_signal.emit(f"Unexpected error occurred: {e}")

        submission_thread = threading.Thread(target=submit_job)
        submission_thread.start()

    def setup_castep(self):
        # Define the source and destination paths
        source_folder = os.path.join(os.getcwd(), "Small_box", "Small", "Accumulation_dependence")
        destination_folder = os.path.join(os.getcwd(), "CASTEP", "DFT box")
        
        castep_folder = os.path.join(os.getcwd(), "CASTEP")
        if not os.path.exists(castep_folder):
            os.makedirs(castep_folder)
            print("CASTEP folder created.")
        
        # Step 2: Check if source folder exists
        if os.path.exists(source_folder):
            # Step 3: Copy and rename the Accumulation_dependence folder to DFT box
            shutil.copytree(source_folder, destination_folder)
            print(f"Accumulation_dependence folder copied and renamed to {destination_folder}.")
        else:
            print("Source folder Accumulation_dependence does not exist.")

        self.outputTextEdit.append("CASTEP setup completed. DFT box folder created.")

        self.current_plot_canvas = None
        self.rdf_canvas = None
        self.cn_canvas2 = None
        self.entropy_canvas = None
        self.gridLayout = QVBoxLayout()
        self.outputTextEdit = None  # Assume this is set up elsewhere

    def remove_previous_plot(self):
        """Remove the current plot from the layout."""
        if self.current_plot_canvas:
            self.gridLayout.removeWidget(self.current_plot_canvas)
            self.current_plot_canvas.deleteLater()
            self.current_plot_canvas = None

    def save_plot_to_folder(self, fig, plot_name):
        """Save the plot figure to a designated folder with full size."""
        # Define the directory to save plots
        save_dir = os.path.join(os.getcwd(), "AIASSE_Plots")
        os.makedirs(save_dir, exist_ok=True)

        # Set a custom figure size for saving, if needed
        original_size = fig.get_size_inches()  # Store original size
        fig.set_size_inches(12, 8)  # Set desired size for saving (adjust as needed)

        # Save the figure to the specified directory
        save_path = os.path.join(save_dir, f"{plot_name}.png")
        fig.savefig(save_path, bbox_inches='tight', dpi=300)  # Use 'tight' and high dpi for full detail

        # Restore the original figure size after saving
        fig.set_size_inches(original_size)

        # Update output with save confirmation
        self.outputTextEdit.append(f"Plot saved to: {save_path}")

    def show_error_dialog(self, message):
        """Display an error dialog with the provided message."""
        QMessageBox.critical(self, "Error", message)

    def clear_splitter(self):
        """Clear existing canvases from the splitter layout."""
        for i in range(self.splitter.count()):
            widget = self.splitter.widget(i)
            if widget is not None:  # Ensure the widget exists before trying to remove it
                widget.setParent(None)
        self.rdf_canvas = None
        self.cn_canvas2 = None
        self.remove_previous_plot()

    def show_error_dialog(self, message):
        """Display an error dialog with the provided message."""
        QMessageBox.critical(self, "Error", message)

    def update_canvas(self, fig, plot_name):
        """Update the display canvas with the provided figure."""
        self.remove_previous_plot()  # Remove current plot if it exists
        self.clear_splitter()  # Ensure all plots are removed
        self.current_plot_canvas = FigureCanvas(fig)
        self.gridLayout.addWidget(self.current_plot_canvas, 1, 0, 1, 1)
        self.save_plot_to_folder(fig, plot_name)
        self.gridLayout.update()
        self.outputTextEdit.append(f"{plot_name} displayed successfully.")

    def plot_rdf_and_cn(self):
        """Generate and display the RDF and Coordination Number plots side by side."""
        try:
            # Clear any existing plots in the splitter
            self.clear_splitter()

            # Define the directory path for plotting
            destination_folder = os.path.join("Large_box", "Large", "Accumulation_dependence")

            # Generate the RDF plot
            rdf_fig = plot_rdf_gr(directory=destination_folder)
            self.rdf_canvas = FigureCanvas(rdf_fig)
            self.splitter.addWidget(self.rdf_canvas)

            # Save RDF plot to designated folder
            self.save_plot_to_folder(rdf_fig, "RDF_Plot")

            # Prompt the user to choose the bonding type for the CN plot
            bonded, ok = QInputDialog.getItem(self.centralWidget, "Select Bonding Type",
                                              "Choose bonding type:", ["Bonded", "Non-Bonded"], 0, False)
            if ok and bonded:
                # Generate the CN plots based on the selected bonding type
                cn_fig1 = plot_cn(directory=destination_folder)

                # Display the CN plots
                self.cn_canvas2 = FigureCanvas(cn_fig1)

                # Add CN plots to the splitter
                self.splitter.addWidget(self.cn_canvas2)

                # Save CN plots to designated folder
                self.save_plot_to_folder(cn_fig1, "CN_Plot")

                # Optionally adjust splitter proportions
                self.splitter.setStretchFactor(0, 1)  # RDF plot
                self.splitter.setStretchFactor(2, 1)  # CN Plot

        except Exception as e:
            self.show_error_dialog(f"Error displaying RDF and CN plots: {e}")

    def plot_excess_entropy(self):
        """Generate and display the Excess Entropy plot."""
        try:
            destination_folder = os.path.join("Large_box", "Large", "Accumulation_dependence")
            file_path = os.path.join("Large_box", "Large", "Largebox.ato")
            with open(file_path, 'r') as file:
                lines = file.readlines()
                num_atoms = int(re.match(r'^\s*(\d+)', lines[0]).group(1))
                cell_length = float(re.match(r'^\s*\d+\s+([\d\.E+-]+)', lines[0]).group(1))
                num_bonds = int(re.match(r'^\s*(\d+)', lines[2]).group(1))
                total_atoms = num_atoms * num_bonds
            fig = plot_excess_entropy(directory=destination_folder, num_atoms=total_atoms, cell_length=cell_length)
            self.update_canvas(fig, "Excess_Entropy_Plot")
        except Exception as e:
            self.show_error_dialog(f"Error displaying entropy plot: {e}")


    def plot_local_structure(self):
        """Generate and display the local structure plot."""
        try:
            directory_path = os.path.join("Large_box", "Large", "Accumulation_dependence", "DFT_box")

            # Ensure scripts in the background
            self.worker = Worker(self.ensure_scripts_in_directory, args=(directory_path,))
            self.worker.finished.connect(lambda _: self.on_local_structure_ready(directory_path))
            self.worker.error.connect(self.show_error_dialog)
            self.worker.finished.connect(self.cleanup_worker)  # Ensure cleanup
            self.worker.start()
        except Exception as e:
            self.show_error_dialog(f"Error displaying local structure plot: {e}")

    def on_local_structure_ready(self, directory_path):
        """Callback after scripts are ensured."""
        try:
            fig = plot_local_structure(directory_path)
            self.update_canvas(fig, "Local_Structure_Plot_Monoatomic")
        except Exception as e:
            self.show_error_dialog(f"Error generating local structure plot: {e}")

    def plot_local_structure_mol(self):
        """Generate and display the local structure plot for 'mol' directory."""
        directory_path = os.path.join("Large_box", "Large", "Accumulation_dependence", "DFT_box")

        try:
            # Generate .xyz files in the background
            self.worker = Worker(generate_com_xyz_files, args=(directory_path, os.path.join(directory_path, "mol")))
            self.worker.finished.connect(lambda success: self.on_xyz_files_ready(success, directory_path))
            self.worker.error.connect(self.show_error_dialog)
            self.worker.finished.connect(self.cleanup_worker)  # Ensure cleanup
            self.worker.start()

            self.outputTextEdit.append("Generating .xyz files... Please wait.")
        except Exception as e:
            self.show_error_dialog(f"Error preparing molecular plot: {e}")

    def on_xyz_files_ready(self, success, directory_path):
        """Callback after .xyz files are generated."""
        if not success:
            self.show_error_dialog("Failed to generate .xyz files. Cannot proceed with plotting.")
            return

        # Ensure scripts in the background
        self.worker = Worker(self.ensure_scripts_in_directory_mol, args=(directory_path,))
        self.worker.finished.connect(lambda _: self.on_mol_scripts_ready(directory_path))
        self.worker.error.connect(self.show_error_dialog)
        self.worker.finished.connect(self.cleanup_worker)  # Ensure cleanup
        self.worker.start()

    def on_mol_scripts_ready(self, directory_path):
        """Callback after scripts for 'mol' are ensured."""
        self.worker = Worker(self.run_lammps_reader_mol, args=(directory_path,))
        self.worker.finished.connect(lambda _: self.on_lammps_reader_done(directory_path))
        self.worker.error.connect(self.show_error_dialog)
        self.worker.finished.connect(self.cleanup_worker)  # Ensure cleanup
        self.worker.start()

    def on_lammps_reader_done(self, directory_path):
        """Callback after lammps_reader_mol script is done."""
        try:
            fig = plot_local_structure_mol(os.path.join(directory_path, "mol"))
            self.update_canvas(fig, "Local_Structure_Plot_Molecules")
        except Exception as e:
            self.show_error_dialog(f"Error generating molecular plot: {e}")

    def ensure_scripts_in_directory(self, directory_path):
        """Ensure necessary scripts are copied to the target directory."""
        atom_array_source_path = os.path.join(os.getcwd(), "src", "atom_array.py")
        lammps_reader_source_path = os.path.join(os.getcwd(), "src", "lammps_reader.py")

        if not os.path.exists(os.path.join(directory_path, "atom_array.py")):
            shutil.copy2(atom_array_source_path, directory_path)
        if not os.path.exists(os.path.join(directory_path, "lammps_reader.py")):
            shutil.copy2(lammps_reader_source_path, directory_path)

    def ensure_scripts_in_directory_mol(self, directory_path):
        """Ensure necessary scripts are copied to the 'mol' directory."""
        mol_directory = os.path.join(directory_path, "mol")
        atom_array_mol_source_path = os.path.join(os.getcwd(), "src", "atom_array_mol.py")
        lammps_reader_mol_source_path = os.path.join(os.getcwd(), "src", "lammps_reader_mol.py")

        if not os.path.exists(mol_directory):
            os.makedirs(mol_directory)
        if not os.path.exists(os.path.join(mol_directory, "atom_array_mol.py")):
            shutil.copy2(atom_array_mol_source_path, mol_directory)
        if not os.path.exists(os.path.join(mol_directory, "lammps_reader_mol.py")):
            shutil.copy2(lammps_reader_mol_source_path, mol_directory)

    def run_lammps_reader_mol(self, directory_path):
        """Run the lammps_reader_mol.py script inside the 'mol' directory."""
        mol_directory = os.path.join(directory_path, "mol")
        script_path = os.path.join(mol_directory, "lammps_reader_mol.py")
        print(f"Directory Path: {directory_path}")
        print(f"Mol Directory: {mol_directory}")
        print(f"Script Path: {script_path}")

        try:
            process = subprocess.run(
                ["python3", "lammps_reader_mol.py"],
                cwd=mol_directory,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout = process.stdout.decode()
            stderr = process.stderr.decode()

            if stdout:
                print(f"stdout: {stdout}")
            if stderr:
                print(f"stderr: {stderr}")

            return "Lammps reader script completed successfully."
        except subprocess.CalledProcessError as e:
            raise Exception(f"Error running {script_path}: {e.stderr.decode()}")

    def cleanup_worker(self):
        """Clean up the worker thread after it finishes."""
        if self.worker:
            self.worker.quit()
            self.worker.wait()
            self.worker = None

    def show_error_dialog(self, message):
        """Display an error dialog with the provided message."""
        QtWidgets.QMessageBox.critical(self, "Error", message)


    def calculate_dihedral_angle(self):
        """Run dihedral angle calculation directly using imported functions."""
        try:
            # Check if the CP2K directory exists
            if not os.path.exists(self.cp2k_directory):
                self.log_signal.emit(f"CP2K directory not found: {self.cp2k_directory}")
                return

            # Identify subdirectories in CP2K (e.g., 100acc, 200acc)
            subdirectories = [d for d in os.listdir(self.cp2k_directory) if os.path.isdir(os.path.join(self.cp2k_directory, d))]

            # Process each subdirectory
            dihedral_angle_figures = []  # To hold the figures from the bond angle plots
            for subdir in subdirectories:
                subdir_path = os.path.join(self.cp2k_directory, subdir)
                try:
                    # Use the process_folders function (modified to calculate dihedral angles) to calculate dihedral angles
                    result = process_folders([subdir_path], self.box_size, self.dr)
                    fig_dihedral = result[1] if isinstance(result, tuple) else result
                    dihedral_angle_figures.append(fig_dihedral)
                    self.log_signal.emit(f"Dihedral angle calculation successful for {subdir}")
                except Exception as e:
                    self.log_signal.emit(f"Error in Dihedral angle calculation for {subdir}: {str(e)}")
            
            # Emit the signal with the dihedral angle figures
            self.dihedral_angle_figures_signal.emit(dihedral_angle_figures)
        
        except Exception as e:
            self.log_signal.emit(f"Error during dihedral angle calculation: {e}")

    def calculate_new_bond_length(self):
        """Run bond length calculation using imported functions."""
        try:
            self.outputTextEdit.append("Please be patient, bond length calculation ongoing...")
            cp2k_directory = os.path.join(os.getcwd(), "CP2K")
            
            if not os.path.exists(cp2k_directory):
                self.outputTextEdit.append(f"CP2K directory not found: {cp2k_directory}")
                return

            box_size = 15.0  # Example box size for bond length calculation
            dr = 0.05  # Example dr for bond length calculation

            # Create the bond length calculator object
            self.bond_length_calculator = BondLengthCalculator(cp2k_directory, box_size, dr)

            # Connect signals for logging and plotting
            self.bond_length_calculator.log_signal.connect(self.append_to_output)
            self.bond_length_calculator.bond_length_figures_signal.connect(self.show_bond_length_plot_on_gui)

            # Create a thread for running the calculation
            self.bond_length_thread = QThread()
            self.bond_length_calculator.moveToThread(self.bond_length_thread)

            # Start the calculation when the thread starts
            self.bond_length_thread.started.connect(self.bond_length_calculator.calculate_bond_length)

            # Start the thread
            self.bond_length_thread.start()

        except Exception as e:
            self.outputTextEdit.append(f"Error occurred during bond length calculation setup: {e}")

    def show_bond_length_plot_on_gui(self, bond_length_figures):
        """Display the given plot figures for bond lengths in the GUI."""
        # Remove the old canvas if it exists
        if hasattr(self, 'bond_length_canvas'):
            self.gridLayout.removeWidget(self.bond_length_canvas)
            self.bond_length_canvas.deleteLater()

        # Display each figure
        for fig in bond_length_figures:
            if isinstance(fig, tuple):  # Ensure only a Figure object is passed
                fig = fig[0]
            self.bond_length_canvas = FigureCanvas(fig)
            self.gridLayout.addWidget(self.bond_length_canvas, 1, 0, 1, 1)
            self.gridLayout.update()

        self.append_to_output("Bond length plot(s) displayed successfully.")

    def calculate_new_charge(self):
        """Run charge calculation using the ChargeCalculator class."""
        try:
            self.outputTextEdit.append("Please be patient, charge calculation ongoing...")
            cp2k_directory = os.path.join(os.getcwd(), "CP2K")
            
            if not os.path.exists(cp2k_directory):
                self.outputTextEdit.append(f"CP2K directory not found: {cp2k_directory}")
                return

            # Create the charge calculator object
            self.charge_calculator = ChargeCalculator(cp2k_directory)

            # Connect signals for logging and plotting
            self.charge_calculator.log_signal.connect(self.append_to_output)
            self.charge_calculator.charge_figures_signal.connect(self.show_charge_plot_on_gui)

            # Create a thread for running the calculation
            self.charge_thread = QThread()
            self.charge_calculator.moveToThread(self.charge_thread)

            # Start the calculation when the thread starts
            self.charge_thread.started.connect(self.charge_calculator.calculate_charge)

            # Start the thread
            self.charge_thread.start()

        except Exception as e:
            self.outputTextEdit.append(f"Error occurred during charge calculation setup: {e}")

    def show_charge_plot_on_gui(self, charge_figures):
        """Display the given plot figures for charge in the GUI."""
        # Remove the old canvas if it exists
        if hasattr(self, 'charge_canvas'):
            self.gridLayout.removeWidget(self.charge_canvas)
            self.charge_canvas.deleteLater()

        # Display each figure
        if charge_figures:
            for fig in charge_figures:
                self.charge_canvas = FigureCanvas(fig)
            self.charge_canvas = FigureCanvas(fig)
            self.gridLayout.addWidget(self.charge_canvas, 1, 0, 1, 1)
            self.gridLayout.update()
            self.append_to_output("Charge plot displayed successfully.")
        else:
            self.append_to_output("No charge plots to display.")

    def calculate_new_dihedral_angle(self):
        """Run dihedral angle calculation using imported functions."""
        try:
            self.outputTextEdit.append("Please be patient, dihedral angle calculation ongoing...")
            cp2k_directory = os.path.join(os.getcwd(), "CP2K")
            
            if not os.path.exists(cp2k_directory):
                self.outputTextEdit.append(f"CP2K directory not found: {cp2k_directory}")
                return

            box_size = 20.565067  # Example box size for dihedral angle calculation
            dr = 0.01  # Example dr for dihedral angle calculation

            # Create the dihedral angle calculator object
            self.dihedral_angle_calculator = DihedralAngleCalculator(cp2k_directory, box_size, dr)

            # Connect signals for logging and plotting
            self.dihedral_angle_calculator.log_signal.connect(self.append_to_output)
            self.dihedral_angle_calculator.dihedral_angle_figures_signal.connect(self.show_dihedral_angle_plot_on_gui)

            # Create a thread for running the calculation
            self.dihedral_angle_thread = QThread()
            self.dihedral_angle_calculator.moveToThread(self.dihedral_angle_thread)

            # Start the calculation when the thread starts
            self.dihedral_angle_thread.started.connect(self.dihedral_angle_calculator.calculate_dihedral_angle)

            # Start the thread
            self.dihedral_angle_thread.start()

        except Exception as e:
            self.outputTextEdit.append(f"Error occurred during dihedral angle calculation setup: {e}")

    def show_dihedral_angle_plot_on_gui(self, dihedral_angle_figures):
        """Display the given plot figures for dihedral angles in the GUI."""
        # Remove the old canvas if it exists
        if hasattr(self, 'dihedral_angle_canvas'):
            self.gridLayout.removeWidget(self.dihedral_angle_canvas)
            self.dihedral_angle_canvas.deleteLater()

        # Display each figure
        for fig in dihedral_angle_figures:
            if isinstance(fig, tuple):  # Ensure only a Figure object is passed
                fig = fig[0]
            self.dihedral_angle_canvas = FigureCanvas(fig)
            self.gridLayout.addWidget(self.dihedral_angle_canvas, 1, 0, 1, 1)
            self.gridLayout.update()

        self.append_to_output("Dihedral angle plot(s) displayed successfully.")



    def updating_large_box(self):
        """Updates the Large.mol file with new bond length and modifies shell.sh for running."""
        
        mean_bond_length = self.calculate_mean_bond_length()
        
        if mean_bond_length is None:
            print("Could not retrieve mean bond length.")
            return
        
        large_box_path = os.path.join("Large_box", "Large")
        large_mol_path = os.path.join(large_box_path, "Large.mol")
        new_shell_script_path = os.path.join(self.src_folder, "update.sh")
        home_epsr25_path = os.path.join(self.src_folder, "epsr25")  # Path to epsr25 in src folder
        destination_epsr25_path = os.path.join(large_box_path, "epsr25")  # Destination path
        destination_shell_script_path = os.path.join(large_box_path, "update.sh")
        epsr_inp_path = os.path.join(large_box_path, "Largebox.EPSR.inp")

        # Step 1: Delete all files except the specified ones and rename Accumulation_dependence to iteration_1
        self.clean_large_directory(large_box_path)

        # Update Large.mol file with new bond length
        try:
            if os.path.exists(large_mol_path):
                with open(large_mol_path, 'r') as mol_file:
                    mol_content = mol_file.readlines()

                # Modify line 4
                if len(mol_content) >= 4:
                    parts = mol_content[3].split()
                    if len(parts) >= 4:
                        parts[3] = f"{mean_bond_length:.5f}"
                        mol_content[3] = "    ".join(parts) + "\n"

                        # Write changes to the file
                        with open(large_mol_path, 'w') as mol_file:
                            mol_file.writelines(mol_content)
                else:
                    print("Large.mol file has insufficient lines.")
                    return

            else:
                print("Large.mol file not found.")
                return  # Exit if the file doesn't exist

            # Step 2: Modify Largebox.EPSR.inp file
            self.modify_epsr_inp(epsr_inp_path)

            # Copy epsr25 to the destination directory
            shutil.copy2(home_epsr25_path, destination_epsr25_path)
            print(f"Copied epsr25 to {destination_epsr25_path}")
            shutil.copy2(new_shell_script_path, destination_shell_script_path)
            print(f"Copied update.sh to {destination_shell_script_path}")

            # Verify the shell script was copied successfully
            if not os.path.exists(destination_shell_script_path):
                print(f"Error: The specified shell script {destination_shell_script_path} was not found after copying.")
                return
            else:
                print(f"Confirmed: {destination_shell_script_path} exists.")

            # Run the shell script in a new thread
            thread = threading.Thread(target=self.updating_large_box, args=(destination_shell_script_path, large_box_path))
            thread.start()

        except Exception as e:
            print(f"Error occurred: {e}")

    def clean_large_directory(self, directory_path):
        """Deletes all files in the directory except the specified files based on extensions and renames Accumulation_dependence to iteration_1."""
        
        # Define allowed file extensions
        allowed_extensions = {".mint01", ".wts", ".ato", ".pro", ".jmol", ".mol", ".inp"}
        
        # Create a set to hold files to keep based on their extensions
        files_to_keep = set()
        
        # Populate files_to_keep based on the directory contents and allowed extensions
        for filename in os.listdir(directory_path):
            if any(filename.endswith(ext) for ext in allowed_extensions):
                files_to_keep.add(filename)

        # Define paths for accumulation_dependence and iteration_1
        accumulation_dependence_path = os.path.join(directory_path, "Accumulation_dependence")
        iteration_1_path = os.path.join(directory_path, "iteration_1")

        # Rename Accumulation_dependence to iteration_1 if it exists
        if os.path.exists(accumulation_dependence_path):
            if os.path.exists(iteration_1_path):
                print(f"Removing existing directory: {iteration_1_path}")
                shutil.rmtree(iteration_1_path)  # Remove existing iteration_1 if it exists
            os.rename(accumulation_dependence_path, iteration_1_path)
            print(f"Renamed {accumulation_dependence_path} to {iteration_1_path}")

        # Now, delete the other files and directories
        for filename in os.listdir(directory_path):
            file_path = os.path.join(directory_path, filename)
            if filename not in files_to_keep and file_path != iteration_1_path:
                try:
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                        print(f"Deleted {file_path}")
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                        print(f"Deleted directory {file_path}")
                except Exception as e:
                    print(f"Error deleting {file_path}: {e}")

    def modify_LB_update_inp(self, epsr_inp_path):
        """Modifies the Largebox.EPSR.inp file to set nsumt to -1."""
        try:
            if os.path.exists(epsr_inp_path):
                with open(epsr_inp_path, 'r') as inp_file:
                    inp_content = inp_file.readlines()

                # Modify the line containing nsumt
                for i in range(len(inp_content)):
                    if 'nsumt' in inp_content[i]:
                        parts = inp_content[i].split()
                        if len(parts) > 1:
                            parts[1] = '-1'  # Set the second part to -1
                            inp_content[i] = " ".join(parts) + "\n"
                        break  # Stop after modifying the first occurrence

                # Write changes to the file
                with open(epsr_inp_path, 'w') as inp_file:
                    inp_file.writelines(inp_content)
                print(f"Modified {epsr_inp_path} to set nsumt to -1.")
            else:
                print("Largebox.EPSR.inp file not found.")
        except Exception as e:
            print(f"Error modifying Largebox.EPSR.inp: {e}")

    def run_update_script(self, destination_shell_script_path, cwd):
        """Runs the update script in a separate thread to avoid GUI freezing."""
        try:
            print(f"Running shell script: {destination_shell_script_path} in directory {cwd}")
            
            # Ensure the script is executable
            os.chmod(destination_shell_script_path, 0o755)  # Set executable permission
            print(f"Set executable permissions for {destination_shell_script_path}")

            # Print current working directory for debugging
            print(f"Current working directory for running script: {cwd}")
            
            # Print the absolute path of the script
            abs_script_path = os.path.abspath(destination_shell_script_path)
            print(f"Absolute path of the script: {abs_script_path}")

            subprocess.run(["expect", abs_script_path], check=True, cwd=cwd)
            print("Shell script executed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Shell script error: {e}")
        except FileNotFoundError:
            print(f"Error: The specified script {destination_shell_script_path} was not found.")
        except Exception as e:
            print(f"Unexpected error while running shell script: {e}")

    def calculate_mean_bond_length(self):
        """Reads the mean bond length from New_bond_length_and_angle.txt."""
        file_path = os.path.join(os.getcwd(), "New_bond_length_and_angle.txt")

        try:
            with open(file_path, 'r') as file:
                lines = file.readlines()

                if len(lines) < 2:
                    print("The file does not contain sufficient data.")
                    return None
                
                # Skip the header and go to the last data line
                last_line = lines[-1].strip()
                parts = last_line.split()
                
                if len(parts) >= 3:  # Ensure that there are at least three elements
                    mean_bond_length = float(parts[1])  # Assuming the 2nd column is mean_bond_length
                    print(f"Mean bond length obtained: {mean_bond_length:.5f}")
                    return mean_bond_length
                else:
                    print("Unexpected file format.")
                    return None
        except Exception as e:
            print(f"Error reading mean bond length: {e}")
            return None



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

