# Prior to apply this code, please, check for updates at public Gitlab
#
# The code is supported by Dr. Ayobami D. Daramola adaramo2@ed.ac.uk and Dr. Ciprian G. Pruteanu cip.pruteanu@ed.ac.uk
#
##############################################################################
# Section 1: Import all necessary python libraries                           #
##############################################################################

import os
import sys
import pty
import select
import shutil
import threading
import random
import subprocess
import time
import re

import numpy as np
import matplotlib.pyplot as plt
import pexpect

from subprocess import Popen, PIPE
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtWidgets import (
    QMainWindow, QAction, QMenu, QFileDialog, QMessageBox, QTextEdit, QLineEdit, QInputDialog
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

# Project-specific imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))
from gr_plots import plot_rdf_gr
from Coordination_num import plot_cn
from gr_dft import process_folders
from excess_entropy import plot_excess_entropy
from lammps_reader import plot_local_structure


##############################################################################
# Section 2: Define class for moving atoms at right bottom corner Gui        #
##############################################################################

class MovingAtomsWidget(QtWidgets.QWidget):
    """A widget to display moving atoms represented by colored circles."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(200, 200)  # Set widget size
        self.atoms = self._initialize_atoms(300)  # Initialize 300 atoms with random properties

        # Set up a timer to update atom positions periodically
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._update_positions)
        self.timer.start(50)  # Update every 50 milliseconds

    def _initialize_atoms(self, count):
        """Generates a list of atoms with random colors, positions, and movement directions."""
        atoms = []
        colors = [QtGui.QColor("red"), QtGui.QColor("green"), QtGui.QColor("blue"),
                  QtGui.QColor("yellow"), QtGui.QColor("cyan"), QtGui.QColor("magenta")]

        for _ in range(count):
            atom = {
                "color": random.choice(colors),
                "x": random.randint(0, self.width() - 10),
                "y": random.randint(0, self.height() - 10),
                "dx": random.choice([-2, -1, 1, 2]),
                "dy": random.choice([-2, -1, 1, 2])
            }
            atoms.append(atom)
        return atoms

    def _update_positions(self):
        """Update the position of each atom, bouncing off edges."""
        for atom in self.atoms:
            atom["x"] += atom["dx"]
            atom["y"] += atom["dy"]

            # Check horizontal bounds
            if atom["x"] <= 0 or atom["x"] >= self.width() - 10:
                atom["dx"] *= -1  # Reverse direction on x-axis

            # Check vertical bounds
            if atom["y"] <= 0 or atom["y"] >= self.height() - 10:
                atom["dy"] *= -1  # Reverse direction on y-axis

        self.update()  # Trigger a repaint to reflect updated positions

    def paintEvent(self, event):
        """Custom painting of atoms as circles."""
        painter = QtGui.QPainter(self)
        try:
            painter.setRenderHint(QtGui.QPainter.Antialiasing)
            for atom in self.atoms:
                painter.setBrush(QtGui.QBrush(atom["color"]))
                painter.drawEllipse(atom["x"], atom["y"], 10, 10)  # Draw each atom as a circle
        finally:
            painter.end()  # Ensure painter is properly ended
            
##############################################################################
# Section 3: Define class for Bond length and Bond angle calculation         #
##############################################################################

class BondLengthCalculator(QtCore.QObject):
    bond_length_figures_signal = pyqtSignal(list)  # Signal to send figures back to the GUI
    log_signal = pyqtSignal(str)  # Signal to send log messages

    def __init__(self, cp2k_directory, box_size, dr):
        super().__init__()
        self.cp2k_directory = cp2k_directory
        self.box_size = box_size
        self.dr = dr

    def calculate_bond_length(self):
        """Run bond length calculation directly using imported functions."""
        try:
            # Check if the CP2K directory exists
            if not os.path.exists(self.cp2k_directory):
                self.log_signal.emit(f"CP2K directory not found: {self.cp2k_directory}")
                return

            # Identify subdirectories in CP2K (e.g., 100acc, 200acc)
            subdirectories = [d for d in os.listdir(self.cp2k_directory) if os.path.isdir(os.path.join(self.cp2k_directory, d))]
            
            # Process each subdirectory
            bond_length_figures = []  # To hold the figures from the plots
            for subdir in subdirectories:
                subdir_path = os.path.join(self.cp2k_directory, subdir)
                try:
                    # Use the process_folders function from gr_dft to calculate bond lengths
                    fig = process_folders([subdir_path], self.box_size, self.dr)
                    bond_length_figures.append(fig)
                    self.log_signal.emit(f"Bond length calculation successful for {subdir}")
                except Exception as e:
                    self.log_signal.emit(f"Error in bond length calculation for {subdir}: {str(e)}")
            
            # Emit the signal with the bond length figures
            self.bond_length_figures_signal.emit(bond_length_figures)
        
        except Exception as e:
            self.log_signal.emit(f"Error during bond length calculation: {e}")

class BondAngleCalculator(QtCore.QObject):
    bond_angle_figures_signal = pyqtSignal(list)  # Signal to send figures back to the GUI
    log_signal = pyqtSignal(str)  # Signal to send log messages

    def __init__(self, cp2k_directory, box_size, dr):
        super().__init__()
        self.cp2k_directory = cp2k_directory
        self.box_size = box_size
        self.dr = dr

    def calculate_bond_angle(self):
        """Run bond angle calculation directly using imported functions."""
        try:
            # Check if the CP2K directory exists
            if not os.path.exists(self.cp2k_directory):
                self.log_signal.emit(f"CP2K directory not found: {self.cp2k_directory}")
                return

            # Identify subdirectories in CP2K (e.g., 100acc, 200acc)
            subdirectories = [d for d in os.listdir(self.cp2k_directory) if os.path.isdir(os.path.join(self.cp2k_directory, d))]

            # Process each subdirectory
            bond_angle_figures = []  # To hold the figures from the bond angle plots
            for subdir in subdirectories:
                subdir_path = os.path.join(self.cp2k_directory, subdir)
                try:
                    # Use the process_folders function (modified to calculate bond angles) to calculate bond angles
                    _, fig_angle = process_folders([subdir_path], self.box_size, self.dr)  # Returns bond length and bond angle figures
                    bond_angle_figures.append(fig_angle)
                    self.log_signal.emit(f"Bond angle calculation successful for {subdir}")
                except Exception as e:
                    self.log_signal.emit(f"Error in bond angle calculation for {subdir}: {str(e)}")
            
            # Emit the signal with the bond angle figures
            self.bond_angle_figures_signal.emit(bond_angle_figures)
        
        except Exception as e:
            self.log_signal.emit(f"Error during bond angle calculation: {e}")
            

class EPSRWorker(QtCore.QObject):
    """ Worker class to run EPSR process in a separate thread. """
    # Signal to communicate with the main thread
    finished = QtCore.pyqtSignal()
    output_signal = QtCore.pyqtSignal(str)
    error_signal = QtCore.pyqtSignal(str)

    def __init__(self, epsr_path, large_box_dir):
        super().__init__()
        self.epsr_path = epsr_path
        self.large_box_dir = large_box_dir

    def run(self):
        """ Method to run the EPSR process in the worker thread. """
        try:
            # Change directory to the Large_box directory
            os.chdir(self.large_box_dir)

            # Run EPSR using subprocess
            self.output_signal.emit(f"Running EPSR process with executable: {self.epsr_path}")
            process = subprocess.Popen([self.epsr_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Capture stdout and stderr
            stdout, stderr = process.communicate()

            # Process output
            if process.returncode == 0:
                self.output_signal.emit("EPSR process completed successfully.")
                self.output_signal.emit(stdout.decode())  # Display stdout
            else:
                self.error_signal.emit("EPSR process failed.")
                self.error_signal.emit(stderr.decode())  # Display stderr

        except Exception as e:
            self.error_signal.emit(f"Error occurred while running EPSR: {str(e)}")
        finally:
            self.finished.emit()  # Emit finished signal when done

##############################################################################
# Section 4: Define class for AIASS.py Gui Mainwindow and interface          #
##############################################################################
            
class Ui_MainWindow(QtWidgets.QMainWindow):
    update_output_signal = pyqtSignal(str)


    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setWindowTitle("AIASSE version 1.0 by Ayobami and Cip")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("AIASSE_logo/AIASSE.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)

        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setObjectName("centralWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralWidget)
        self.gridLayout.setObjectName("gridLayout")
        
        # Menu bar
        self.menuBar = QtWidgets.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 800, 22))
        self.menuBar.setObjectName("menuBar")
        
        # Only Settings and Documentation menus
        self.menuSettings = QtWidgets.QMenu(self.menuBar)
        self.menuSettings.setObjectName("menuSettings")
        self.menuDocumentation = QtWidgets.QMenu(self.menuBar)
        self.menuDocumentation.setObjectName("menuDocumentation")
        # Add new Plot menu
        self.menuPlot = QtWidgets.QMenu(self.menuBar)
        self.menuPlot.setObjectName("menuPlot")
        self.menuPlot.setTitle("Plot")
        self.menuBar.addAction(self.menuPlot.menuAction())
        
        # Create actions for the Plot menu
        self.rdfAction = QtWidgets.QAction("RDF", MainWindow)
        self.cnAction = QtWidgets.QAction("CN", MainWindow)
        self.excessEntropyAction = QtWidgets.QAction("Excess Entropy", MainWindow)
        self.AJanalysisAction = QtWidgets.QAction("Ackland-Jones", MainWindow)
        
        # Add actions to the Plot menu
        self.menuPlot.addAction(self.rdfAction)
        self.menuPlot.addAction(self.cnAction)
        self.menuPlot.addAction(self.excessEntropyAction)
        self.menuPlot.addAction(self.AJanalysisAction)
        
        # Connect actions to respective methods (these methods need to be defined)
        self.rdfAction.triggered.connect(self.plot_rdf)
        self.cnAction.triggered.connect(self.plot_cn)
        self.excessEntropyAction.triggered.connect(self.plot_excess_entropy)
        self.AJanalysisAction.triggered.connect(self.plot_local_structure)
        
        MainWindow.setMenuBar(self.menuBar)
        self.menuBar.addAction(self.menuSettings.menuAction())
        self.menuBar.addAction(self.menuDocumentation.menuAction())

        self.menuSettings.setTitle("Settings")
        self.menuDocumentation.setTitle("Documentation")

        # Settings Menu Actions
        self.setEpsrPathAction = QtWidgets.QAction("Set EPSR Path", MainWindow)
        self.setCp2kPathAction = QtWidgets.QAction("Set CP2K Path", MainWindow)
        self.setCastepPathAction = QtWidgets.QAction("Set CASTEP Path", MainWindow)
        self.menuSettings.addAction(self.setEpsrPathAction)
        self.menuSettings.addAction(self.setCp2kPathAction)
        self.menuSettings.addAction(self.setCastepPathAction)

        # Button layout
        self.buttonLayout = QtWidgets.QHBoxLayout()
        
        # Run Large Box button (with actions in a menu)
        self.runLargeBoxButton = QtWidgets.QPushButton("Run Large Box", self.centralWidget)
        self.runLargeBoxButton.setObjectName("runLargeBoxButton")
        self.runLargeBoxMenu = QtWidgets.QMenu(self.runLargeBoxButton)

        self.deleteLargeBoxAction = QtWidgets.QAction("Delete Large Box", MainWindow)
        self.extractLargeBoxAction = QtWidgets.QAction("Extract Large Boxes", MainWindow)
        self.stopExtractButton = QtWidgets.QAction("Stop Extracting Large Boxes", MainWindow)
        self.updateLargeBoxButton = QtWidgets.QAction("Update Large Boxes", MainWindow)
        
    
        self.runLargeBoxMenu.addAction(self.deleteLargeBoxAction)
        self.runLargeBoxMenu.addAction(self.extractLargeBoxAction)
        self.runLargeBoxMenu.addAction(self.stopExtractButton)
        self.runLargeBoxMenu.addAction(self.updateLargeBoxButton)

        self.runLargeBoxButton.setMenu(self.runLargeBoxMenu)
        self.buttonLayout.addWidget(self.runLargeBoxButton)
        
        # Run Small Box button (with actions in a menu)
        self.runSmallBoxButton = QtWidgets.QPushButton("Run Small Box", self.centralWidget)
        self.runSmallBoxButton.setObjectName("runSmallBoxButton")
        self.runSmallBoxMenu = QtWidgets.QMenu(self.runSmallBoxButton)
        
        
        self.transferfilesAction = QtWidgets.QAction("Obtain Large Box Potential", MainWindow)
        self.createBoxButton = QtWidgets.QAction("Create Box", MainWindow)
        self.extractSmallBoxAction = QtWidgets.QAction("Extract Small Boxes", MainWindow)
        self.stopextractButton = QtWidgets.QAction("Stop Extracting Small Boxes", MainWindow)
        self.deleteSmallBoxAction = QtWidgets.QAction("Delete Small Box", MainWindow)
        self.DFTBoxAction = QtWidgets.QAction("Send DFT Box", MainWindow)
        
        self.runSmallBoxMenu.addAction(self.transferfilesAction)
        self.runSmallBoxMenu.addAction(self.createBoxButton)
        self.runSmallBoxMenu.addAction(self.extractSmallBoxAction)
        self.runSmallBoxMenu.addAction(self.stopextractButton)
        self.runSmallBoxMenu.addAction(self.deleteSmallBoxAction)
        self.runSmallBoxMenu.addAction(self.DFTBoxAction)

        self.runSmallBoxButton.setMenu(self.runSmallBoxMenu)
        self.buttonLayout.addWidget(self.runSmallBoxButton)
        
        # DFT Setup Button
        self.dftSetupButton = QtWidgets.QPushButton("DFT Setup", self.centralWidget)
        self.dftSetupButton.setObjectName("dftSetupButton")
        self.dftSetupMenu = QtWidgets.QMenu(self.dftSetupButton)
        
        self.CP2KAction = QtWidgets.QAction("CP2K", MainWindow)
        self.CASTEPAction = QtWidgets.QAction("CASTEP", MainWindow)
        self.calculateBondLengthAction = QtWidgets.QAction("Calculate New Bond Length", MainWindow)
        self.calculateBondAngleAction = QtWidgets.QAction("Calculate New Bond Angle", MainWindow)
        
        
        self.dftSetupMenu.addAction(self.CP2KAction)
        self.dftSetupMenu.addAction(self.CASTEPAction)
        self.dftSetupMenu.addAction(self.calculateBondLengthAction)
        self.dftSetupMenu.addAction(self.calculateBondAngleAction)
        self.dftSetupButton.setMenu(self.dftSetupMenu)
        self.buttonLayout.addWidget(self.dftSetupButton)
         
        
        # Add to layout
        self.gridLayout.addLayout(self.buttonLayout, 0, 0, 1, 1)
        
        # Container widget for EPSR outputs
        self.outputTextEdit = QtWidgets.QTextEdit(self.centralWidget)
        self.outputTextEdit.setObjectName("outputTextEdit")
        self.gridLayout.addWidget(self.outputTextEdit, 1, 0, 1, 1)
        
        MainWindow.setCentralWidget(self.centralWidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        # Bottom layout for images
        self.bottomLayout = QtWidgets.QHBoxLayout()

        # Add spacer on the left, then left logo, spacer, right logo, and spacer on the right
        self.leftLogoLabel = QtWidgets.QLabel(self.centralWidget)
        self.rightLogoLabel = QtWidgets.QLabel(self.centralWidget)
                # Add the MovingAtomsWidget at the bottom-right corner
        self.movingAtomsWidget = MovingAtomsWidget(self.centralWidget)
        self.gridLayout.addWidget(self.movingAtomsWidget, 2, 1, 1, 1, alignment=QtCore.Qt.AlignBottom | QtCore.Qt.AlignRight)

        # Set the pixmap for each label to the image AIASSE.png
        pixmap = QtGui.QPixmap("AIASSE_logo/AIASSE.png")

        # Scale the image to a larger size (e.g., 150x150 pixels)
        self.leftLogoLabel.setPixmap(pixmap.scaled(250, 250, QtCore.Qt.KeepAspectRatio))
        self.rightLogoLabel.setPixmap(pixmap.scaled(250, 250, QtCore.Qt.KeepAspectRatio))

        # Ensure the labels are transparent
        self.leftLogoLabel.setStyleSheet("background-color: transparent;")
        self.rightLogoLabel.setStyleSheet("background-color: transparent;")

        # Add spacers and widgets to the layout
        self.bottomLayout.addSpacerItem(QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum))
        self.bottomLayout.addWidget(self.leftLogoLabel)
        self.bottomLayout.addSpacerItem(QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum))
        self.bottomLayout.addWidget(self.rightLogoLabel)
        self.bottomLayout.addSpacerItem(QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum))

        # Add the bottom layout to the main grid layout
        self.gridLayout.addLayout(self.bottomLayout, 2, 0, 1, 1)

        # Version Label at the bottom-left corner
        self.versionLabel = QtWidgets.QLabel(self.centralWidget)
        self.versionLabel.setText("AIASSE version 1.0")
        self.versionLabel.setStyleSheet("background-color: transparent;")
        self.versionLabel.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignBottom)
        self.gridLayout.addWidget(self.versionLabel, 3, 0)

        
        # Connect actions to functions
        self.setEpsrPathAction.triggered.connect(lambda: self.set_executable_path("epsr"))
        self.setCp2kPathAction.triggered.connect(lambda: self.set_executable_path("cp2k"))
        self.setCastepPathAction.triggered.connect(lambda: self.set_executable_path("castep"))

        # Connect buttons to their functions
        self.deleteLargeBoxAction.triggered.connect(self.delete_large_box)
        self.extractLargeBoxAction.triggered.connect(self.extract_large_box)
        self.stopExtractButton.triggered.connect(self.stop_extracting_large_box)
        self.updateLargeBoxButton.triggered.connect(self.updating_large_box)
        self.transferfilesAction.triggered.connect(self.transfer_files)
        self.createBoxButton.triggered.connect(self.create_box)
        self.extractSmallBoxAction.triggered.connect(self.extract_small_box)
        self.stopextractButton.triggered.connect(self.stop_extracting_small_box)
        self.deleteSmallBoxAction.triggered.connect(self.delete_small_box)
        self.DFTBoxAction.triggered.connect(self.produce_DFT_box)
        self.runLargeBoxButton.clicked.connect(self.run_large_box)
        self.runSmallBoxButton.clicked.connect(self.run_small_box)
        self.dftSetupButton.clicked.connect(self.dft_setup)
        self.CP2KAction.triggered.connect(lambda: self.setup_cp2k(MainWindow))
        self.CASTEPAction.triggered.connect(self.setup_castep)
        self.calculateBondLengthAction.triggered.connect(self.calculate_new_bond_length)
        self.calculateBondAngleAction.triggered.connect(self.calculate_new_bond_angle)
        self.update_output_signal.connect(self.append_to_output)
        

        # Initialize paths and process attributes
        self.epsr_path = None
        self.cp2k_path = None
        self.castep_path = None
        self.extract_process = None
        self.is_running = False
        self.current_plot_canvas = None  # Hold reference to current plot canvas
        self.entropy_canvas = None
          

        # Adjust version label position when the window is resized
        MainWindow.resizeEvent = self.resize_event

    def resize_event(self, event):
        self.versionLabel.move(10, event.size().height() - 30)
        super().resizeEvent(event)

    def set_executable_path(self, exec_type):
        options = QtWidgets.QFileDialog.Options()
        options |= QtWidgets.QFileDialog.ReadOnly
        fileName, _ = QtWidgets.QFileDialog.getOpenFileName(None, "Select Executable", "", "Executables (*);;All Files (*)", options=options)

        if fileName:
            if exec_type == "epsr":
                self.epsr_path = fileName
                self.statusbar.showMessage(f"EPSR path set to: {fileName}")
                # Run EPSR immediately
                self.run_large_box()
            elif exec_type == "cp2k":
                self.cp2k_path = fileName
                self.statusbar.showMessage(f"CP2K path set to: {fileName}")
            elif exec_type == "castep":
                self.castep_path = fileName
                self.statusbar.showMessage(f"CASTEP path set to: {fileName}")

    def show_error_dialog(self, message):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Critical)
        msgBox.setText(message)
        msgBox.setWindowTitle("Error")
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgBox.exec_()

    def append_to_output(self, message: str):
        self.outputTextEdit.append(message)  # Append the string directly

    def run_large_box(self):
        """ Run the EPSR process with large box handling inside the Results folder. """
        results_dir = os.path.join(os.getcwd(), "Results")
        large_box_dir = os.path.join(results_dir, "Large_box")

        # Create the Results directory if it doesn't exist
        os.makedirs(results_dir, exist_ok=True)
        self.outputTextEdit.append(f"Created directory: {results_dir}")

        # Check if Large_box exists in Results and ensure not to create it
        if os.path.exists(large_box_dir):
            self.show_error_dialog("The 'Large_box' directory already exists. It should not be created.")
            return

        os.makedirs(large_box_dir, exist_ok=True)
        self.outputTextEdit.append(f"Created directory: {large_box_dir}")

        # Ensure that EPSR executable is set before running
        if not self.epsr_path:
            self.show_error_dialog("EPSR executable path is not set!")
            return

        # Create and start worker thread for EPSR process
        self.worker = EPSRWorker(self.epsr_path, large_box_dir)
        self.worker.output_signal.connect(self.append_to_output)
        self.worker.error_signal.connect(self.show_error_dialog)
        self.worker.finished.connect(self.on_process_finished)

        self.worker_thread = QtCore.QThread()
        self.worker.moveToThread(self.worker_thread)

        self.worker_thread.started.connect(self.worker.run)
        self.worker_thread.start()

    def on_process_finished(self):
        """ Handle when the EPSR process finishes. """
        self.worker_thread.quit()
        self.worker_thread.wait()
        self.worker = None
        self.worker_thread = None
        self.append_to_output("EPSR process finished.")

    def run_small_box(self):
        """Create Small_box and Small directories inside Results folder."""
        results_dir = os.path.join(os.getcwd(), "Results")
        small_box_dir = os.path.join(results_dir, "Small_box")
        small_dir = os.path.join(small_box_dir, "Small")

        # Ensure the Results/Small_box/Small directories exist
        os.makedirs(small_dir, exist_ok=True)
        self.outputTextEdit.append(f"Created directory: {small_dir}")

    def delete_large_box(self):
        """Delete the Large_box directory if it exists."""
        large_box_dir = os.path.join(os.getcwd(), "Results", "Large_box")
        if os.path.exists(large_box_dir):
            shutil.rmtree(large_box_dir)
            self.outputTextEdit.append(f'{large_box_dir} deleted successfully.')
        else:
            self.outputTextEdit.append(f'{large_box_dir} does not exist.')

    def delete_small_box(self):
        """Delete the Small_box directory if it exists."""
        small_box_dir = os.path.join(os.getcwd(), "Results", "Small_box")
        if os.path.exists(small_box_dir):
            shutil.rmtree(small_box_dir)
            self.outputTextEdit.append(f'{small_box_dir} deleted successfully.')
        else:
            self.outputTextEdit.append(f'{small_box_dir} does not exist.')

    def transfer_files(self):
        """Transfer files from Large_box to Small_box."""
        results_dir = os.path.join(os.getcwd(), "Results")
        large_box_dir = os.path.join(results_dir, "Large_box", "Large")
        small_box_dir = os.path.join(results_dir, "Small_box", "Small")

        if not os.path.exists(small_box_dir):
            os.makedirs(small_box_dir)

        files_to_modify = {
            'Largebox.EPSR.p01': 'Smallbox.EPSR.p01',
            'Largebox.EPSR.inp': 'Smallbox.EPSR.inp',
            'Large.ato': 'Small.ato',
            'Largebox.pcof': 'Smallbox.pcof',
            'Large.mol': 'Small.mol',
            'Large.EPSR.pro': 'Small.EPSR.pro',
            'Large.jmol': 'Small.jmol',
        }

        # Copy and modify the primary files
        for filename, new_filename in files_to_modify.items():
            source_file = os.path.join(large_box_dir, filename)
            destination_file = os.path.join(small_box_dir, new_filename)

            if os.path.exists(source_file) and 'Largebox.ato' not in filename:
                shutil.copyfile(source_file, destination_file)

                if filename == 'Largebox.EPSR.inp':
                    self.modify_epsr_inp(destination_file)

                if filename == 'Large.EPSR.pro':
                    self.modify_epsr_pro(destination_file)

                if filename == 'Largebox.EPSR.p01':
                    os.chmod(destination_file, 0o444)  # read-only

                self.outputTextEdit.append(f'File {filename} copied and renamed to {new_filename}')

        # Transfer additional files without modification
        additional_files = ['.mint01', '.NWTStot.wts', 'NWTS.dat']
        for filename in os.listdir(large_box_dir):
            if any(filename.endswith(ext) for ext in additional_files):
                source_file = os.path.join(large_box_dir, filename)
                destination_file = os.path.join(small_box_dir, filename)

                if os.path.exists(source_file):
                    shutil.copyfile(source_file, destination_file)
                    
                    # Modify NWTS.dat to replace the second line
                    if filename.endswith('NWTS.dat'):
                        self.modify_nwts_dat(destination_file)

                    self.outputTextEdit.append(f'File {filename} copied to {small_box_dir}')

    def modify_epsr_inp(self, filepath):
        """Modify the EPSR input file."""
        with open(filepath, 'r+') as file:
            content = file.read()
            content = content.replace('Largebox.EPSR', 'Smallbox.EPSR')
            content = content.replace('fnameato    Largebox.ato', 'fnameato    Smallbox.ato')
            content = content.replace('fnamepcof   Largebox.pcof', 'fnamepcof   Smallbox.pcof')
            content = content.replace('potfac      1.0', 'potfac      0.0')
            content = content.replace('nsumt       -1', 'nsumt       0')

            file.seek(0)
            file.write(content)
            file.truncate()

    def modify_epsr_pro(self, filepath):
        """Modify the EPSR pro file."""
        with open(filepath, 'r+') as file:
            content = file.read()
            content = content.replace('mol Large.mol 1000', 'mol Small.mol 300')
            content = content.replace('boxAtoFileName Largebox.ato', 'boxAtoFileName Smallbox.ato')
            content = content.replace('EPSRinp Largebox', 'EPSRinp Smallbox')

            file.seek(0)
            file.write(content)
            file.truncate()

    def modify_nwts_dat(self, filepath):
        """Modify the NWTS.dat file to change the second line."""
        with open(filepath, 'r+') as file:
            lines = file.readlines()
            
            if len(lines) > 1:  # Ensure there's at least two lines to modify
                lines[1] = lines[1].replace('fnameato    Largebox.ato', 'fnameato    Smallbox.ato')

            file.seek(0)
            file.writelines(lines)

    def create_box(self):
        """Sets up the Small_box directory, copies necessary files, and runs the shell script."""
        
        # Get the directory where the script is located (this works across different machines)
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Define base directories
        results_dir = os.path.join(os.getcwd(), 'Results')
        small_box_dir = os.path.join(results_dir, 'Small_box', 'Small')
        
        # Paths for files from src
        src_dir = os.path.join(script_dir, 'src')  # Assuming src folder exists in the same directory as the script
        epsr25_file = os.path.join(src_dir, "epsr25")
        script_file = os.path.join(src_dir, "shell.sh")

        # Destination paths
        dest_epsr25_file = os.path.join(small_box_dir, "epsr25")
        dest_script_file = os.path.join(small_box_dir, "shell.sh")

        try:
            # Ensure the Small_box/Small directory exists (it should already exist as per your setup)
            if not os.path.exists(small_box_dir):
                self.update_output_signal.emit(f"Error: Directory does not exist: {small_box_dir}")
                return

            # Debugging output
            self.update_output_signal.emit(f"Source epsr25 file path: {epsr25_file}")
            self.update_output_signal.emit(f"Source script file path: {script_file}")
            self.update_output_signal.emit(f"Destination epsr25 file path: {dest_epsr25_file}")
            self.update_output_signal.emit(f"Destination script file path: {dest_script_file}")

            # Copy epsr25 and the script to the Small_box/Small directory
            shutil.copy(epsr25_file, dest_epsr25_file)
            shutil.copy(script_file, dest_script_file)

            # Set the copied files as executable
            os.chmod(dest_epsr25_file, 0o755)
            os.chmod(dest_script_file, 0o755)

            # Verify the script file has been copied correctly
            if not os.path.isfile(dest_script_file):
                self.update_output_signal.emit(f"Error: '{dest_script_file}' not found after copying.")
                return  # Exit if file is missing

            # Debugging output for the files
            self.update_output_signal.emit(f"Files '{epsr25_file}' and '{script_file}' successfully copied to '{small_box_dir}'.")
            self.update_output_signal.emit(f"Current working directory: {os.getcwd()}")
            self.update_output_signal.emit(f"Files in '{small_box_dir}': {os.listdir(small_box_dir)}")

            # Ensure the current working directory is correct
            if os.getcwd() != small_box_dir:
                self.update_output_signal.emit(f"Changing working directory to: {small_box_dir}")
                os.chdir(small_box_dir)

            # Run the script in a new thread
            threading.Thread(
                target=self.run_shell_script,
                args=(dest_script_file, small_box_dir)
            ).start()

        except Exception as e:
            self.update_output_signal.emit(f"Error during create_box: {str(e)}")

    def run_shell_script(self, script_path, cwd):
        """Executes the specified shell script in the given directory using subprocess."""
        def run_script():
            try:
                # Confirm the existence of the script file before running
                if not os.path.isfile(script_path):
                    self.update_output_signal.emit(f"Script not found: {script_path}")
                    return

                # Print the command for debugging
                self.update_output_signal.emit(f"Running command: bash {script_path}")

                # Run the shell script using subprocess
                result = subprocess.run(['bash', script_path], cwd=cwd, capture_output=True, text=True)

                # Capture the output and error messages
                if result.returncode != 0:
                    self.update_output_signal.emit(f"Error occurred while running the script:\n{result.stderr}")
                else:
                    self.update_output_signal.emit(f"Shell script executed successfully.\n{result.stdout}")

            except Exception as e:
                self.update_output_signal.emit(f"Error occurred while running the script: {str(e)}")

        # Start the script in a separate thread
        threading.Thread(target=run_script).start()

    def extract_large_box(self):
        large_dir = os.path.join("Results", "Large_box", "Large")
        
        # Ensure the Large directory exists
        if not os.path.exists(large_dir):
            self.show_error_dialog(f"Directory does not exist: {large_dir}")
            return

        # Define the script path in the src folder
        script_source_path = os.path.join('src', 'run_epsr.sh')
        
        # Define the destination script path in the Large directory
        script_destination_path = os.path.join(large_dir, "run_epsr.sh")
        
        # Check if the source script file exists
        if not os.path.isfile(script_source_path):
            self.show_error_dialog(f"Script file does not exist: {script_source_path}")
            return

        # Copy the script file to the Large directory
        shutil.copy(script_source_path, script_destination_path)

        # Make the script executable
        os.chmod(script_destination_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(large_dir)  # Set working directory to the Large directory
        self.extract_process.setProgram("/bin/bash")
        self.extract_process.setArguments([f"./run_epsr.sh"])
        self.extract_process.start()

        # Connect signals to handle output and completion
        self.extract_process.readyReadStandardOutput.connect(lambda: self.outputTextEdit.append(self.extract_process.readAllStandardOutput().data().decode()))
        self.extract_process.readyReadStandardError.connect(lambda: self.outputTextEdit.append(f"Error: {self.extract_process.readAllStandardError().data().decode()}"))
        self.extract_process.finished.connect(self.on_extraction_finished)

    def on_extraction_finished(self, exit_code, exit_status):
        self.outputTextEdit.append(f"Extraction script finished with exit code {exit_code} and status {exit_status}")
        
        # Check if the expected folder was created
        expected_folder = os.path.join("Results", "Large_box", "Large", "Accumulation_dependence")
        if os.path.exists(expected_folder):
            self.outputTextEdit.append(f"Success: {expected_folder} was created.")
        else:
            self.outputTextEdit.append(f"Error: {expected_folder} was not created. Check the script output for details.")        

    def stop_extracting_large_box(self):
        if hasattr(self, 'extract_process') and self.extract_process.state() == QtCore.QProcess.Running:
            self.extract_process.terminate()
            self.outputTextEdit.append("Extraction script terminated")

            # Define the source and destination paths for LB_xyz.sh
            script_source_path = os.path.join('src', 'LB_xyz.sh')  # LB_xyz.sh in the src folder
            accumulation_folder = os.path.join("Results", "Large_box", "Large", "Accumulation_dependence")

            # Ensure the accumulation folder exists, or show an error
            if not os.path.exists(accumulation_folder):
                self.show_error_dialog(f"Accumulation directory does not exist: {accumulation_folder}")
                return

            # Define the destination path for LB_xyz.sh in the accumulation folder
            script_destination_path = os.path.join(accumulation_folder, "LB_xyz.sh")
            
            # Copy the LB_xyz.sh script to the accumulation folder
            shutil.copy(script_source_path, script_destination_path)

            # After copying the script, execute it
            self.produce_LB_xyz_box()

    def produce_LB_xyz_box(self):
        # Get the current working directory
        current_directory = os.getcwd()

        # Define the relative path to Accumulation_dependence folder
        accumulation_folder = os.path.join(current_directory, "Results", "Large_box", "Large", "Accumulation_dependence")

        # Check if the accumulation folder exists
        if not os.path.exists(accumulation_folder):
            self.outputTextEdit.append(f"Error: Accumulation directory does not exist: {accumulation_folder}")
            return

        # Define the path to the LB_xyz.sh script within that directory
        script_path = os.path.join(accumulation_folder, "LB_xyz.sh")

        # Check if LB_xyz.sh exists
        if not os.path.isfile(script_path):
            self.outputTextEdit.append(f"Error: Script {script_path} does not exist.")
            return

        # Make sure the script is executable
        os.chmod(script_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(accumulation_folder)  # Set working directory
        self.extract_process.setProgram("/usr/bin/expect")
        self.extract_process.setArguments([script_path])
        self.extract_process.start()

        # Connect signals for handling process output and completion
        self.extract_process.readyReadStandardOutput.connect(lambda: self.outputTextEdit.append(self.extract_process.readAllStandardOutput().data().decode()))
        self.extract_process.readyReadStandardError.connect(lambda: self.outputTextEdit.append(f"Error: {self.extract_process.readAllStandardError().data().decode()}"))
        self.extract_process.finished.connect(self.on_LB_xyz_finished)

    def on_LB_xyz_finished(self, exit_code, exit_status):
        self.outputTextEdit.append(f"LB_xyz script finished with exit code {exit_code} and status {exit_status}")

    def extract_small_box(self):
        small_dir = os.path.join("Results", "Small_box", "Small")
        
        # Ensure the Small directory exists
        if not os.path.exists(small_dir):
            self.show_error_dialog(f"Directory does not exist: {small_dir}")
            return

        # Define the script path in the src folder
        script_source_path = os.path.join("src", "run_epsr.sh")
        
        # Define the destination script path in the Small directory
        script_destination_path = os.path.join(small_dir, "run_epsr.sh")
        
        # Check if the source script file exists
        if not os.path.isfile(script_source_path):
            self.show_error_dialog(f"Script file does not exist: {script_source_path}")
            return

        # Copy the script file to the Small directory
        shutil.copy(script_source_path, script_destination_path)

        # Make the script executable
        os.chmod(script_destination_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(small_dir)  # Set working directory to the Small directory
        self.extract_process.setProgram("/bin/bash")
        self.extract_process.setArguments([f"./run_epsr.sh"])
        self.extract_process.start()

        # Connect signals to handle output and completion
        self.extract_process.readyReadStandardOutput.connect(lambda: self.outputTextEdit.append(self.extract_process.readAllStandardOutput().data().decode()))
        self.extract_process.readyReadStandardError.connect(lambda: self.outputTextEdit.append(f"Error: {self.extract_process.readAllStandardError().data().decode()}"))
        self.extract_process.finished.connect(self.on_extraction_finished_small)

    def on_extraction_finished_small(self, exit_code, exit_status):
        self.outputTextEdit.append(f"Extraction script finished with exit code {exit_code} and status {exit_status}")
        
        # Check if the expected folder was created
        expected_folder = os.path.join("Results", "Small_box", "Small", "accumulation_dependence")
        if os.path.exists(expected_folder):
            self.outputTextEdit.append(f"Success: {expected_folder} was created.")
        else:
            self.outputTextEdit.append(f"Error: {expected_folder} was not created. Check the script output for details.")

    def stop_extracting_small_box(self):
        if hasattr(self, 'extract_process') and self.extract_process.state() == QtCore.QProcess.Running:
            self.extract_process.terminate()
            self.outputTextEdit.append("Extraction script terminated")

            # Define the source and destination paths for xyz.sh
            script_source_path = os.path.join("src", "xyz.sh")  # xyz.sh in the src folder
            accumulation_folder = os.path.join("Results", "Small_box", "Small", "Accumulation_dependence")

            # Ensure the accumulation folder exists, or show an error
            if not os.path.exists(accumulation_folder):
                self.show_error_dialog(f"Accumulation directory does not exist: {accumulation_folder}")
                return

            # Define the destination path for xyz.sh in the accumulation folder
            script_destination_path = os.path.join(accumulation_folder, "xyz.sh")
            
            # Copy the xyz.sh script to the accumulation folder
            shutil.copy(script_source_path, script_destination_path)

    def produce_DFT_box(self):
        # Get the current working directory
        current_directory = os.getcwd()

        # Define the relative path to Accumulation_dependence folder
        accumulation_folder = os.path.join(current_directory, "Results", "Small_box", "Small", "Accumulation_dependence")

        # Check if the accumulation folder exists
        if not os.path.exists(accumulation_folder):
            self.outputTextEdit.append(f"Error: Accumulation directory does not exist: {accumulation_folder}")
            return

        # Define the path to the xyz.sh script within that directory
        script_path = os.path.join(accumulation_folder, "xyz.sh")

        # Check if xyz.sh exists
        if not os.path.isfile(script_path):
            self.outputTextEdit.append(f"Error: Script {script_path} does not exist.")
            return

        # Make sure the script is executable
        os.chmod(script_path, 0o755)

        # Create a QProcess to run the script
        self.extract_process = QtCore.QProcess(self.centralWidget)
        self.extract_process.setWorkingDirectory(accumulation_folder)  # Set working directory
        self.extract_process.setProgram("/usr/bin/expect")
        self.extract_process.setArguments([script_path])
        self.extract_process.start()

        # Connect signals for handling process output and completion
        self.extract_process.readyReadStandardOutput.connect(self.handle_output)
        self.extract_process.readyReadStandardError.connect(self.handle_error)
        self.extract_process.finished.connect(self.handle_finished)

        # Output message
        self.outputTextEdit.append("Started running xyz.sh script in Accumulation_dependence folder.")

    def handle_output(self):
        # Read the output from the process and append it to the output text edit
        output = self.extract_process.readAllStandardOutput().data().decode()
        self.outputTextEdit.append(output)

    def handle_error(self):
        # Read the error output from the process and append it to the output text edit
        error = self.extract_process.readAllStandardError().data().decode()
        self.outputTextEdit.append(f"Error: {error}")

    def handle_finished(self, exit_code, exit_status):
        # Display message when the script finishes
        self.outputTextEdit.append(f"Script finished with exit code {exit_code} and status {exit_status}")

    # Function for DFT setup
    def dft_setup(self):
        pass

    # CP2K setup functions
    def setup_cp2k(self, MainWindow):
        """Set up CP2K by copying required files and executing CP2K on .xyz files."""
        # Define paths
        current_directory = os.getcwd()

        # Path to the folder where .xyz files are located
        source_folder = os.path.join(current_directory, "Results", "Small_box", "Small", "Accumulation_dependence", "DFT_box")

        # Path to the home folder where static files are located (assuming it's the same directory as this script)
        home_folder = os.path.join(current_directory, "src")

        # Destination folder where CP2K runs will happen, now under "Results"
        cp2k_folder = os.path.join(current_directory, "Results", "C2PK")

        # List of required static files with paths pointing to the home folder
        required_files = [
            os.path.join(home_folder, "GTH_POTENTIALS"),
            os.path.join(home_folder, "dftd3.dat"),
            os.path.join(home_folder, "BASIS_MOLOPT"),
            os.path.join(home_folder, "cp2k.psmp"),
            os.path.join(home_folder, "aiasse.inp")  # Template input file
        ]

        # Create C2PK folder if it doesn't exist
        if not os.path.exists(cp2k_folder):
            os.makedirs(cp2k_folder)
            self.outputTextEdit.append("C2PK folder created.")

        # Select the CP2K executable file
        cp2k_executable, _ = QFileDialog.getOpenFileName(MainWindow, "Select CP2K Executable", "", "Executable Files (*)")
        if not cp2k_executable:
            self.outputTextEdit.append("No CP2K executable selected.")
            return

        # Set CP2K executable path
        self.cp2k_path = cp2k_executable
        self.statusbar.showMessage(f"CP2K path set to: {cp2k_executable}")

        # Change permissions of the selected executable
        try:
            os.chmod(cp2k_executable, 0o755)  # Sets the permission to rwxr-xr-x
            self.outputTextEdit.append("CP2K executable permissions set to executable.")
        except Exception as e:
            self.outputTextEdit.append(f"Error setting permissions for CP2K executable: {e}")
            return

        # Function to search and copy required static files
        def search_and_copy_file(filepath, destination):
            if os.path.exists(filepath):
                shutil.copy(filepath, destination)
                filename = os.path.basename(filepath)
                self.outputTextEdit.append(f"{filename} found and copied to {destination}.")
            else:
                filename = os.path.basename(filepath)
                self.outputTextEdit.append(f"{filename} not found in {os.path.dirname(filepath)}.")

        # Search and copy required static files from the src folder
        for file_path in required_files:
            search_and_copy_file(file_path, cp2k_folder)

        # Process all .xyz files from the DFT_Box folder
        xyz_files = [f for f in os.listdir(source_folder) if f.endswith(".xyz")]

        if not xyz_files:
            self.outputTextEdit.append("No .xyz files found in DFT_Box.")
            return

        self.outputTextEdit.append(f"Found {len(xyz_files)} .xyz files. Starting CP2K runs...")

        # Start CP2K runs in a new thread to avoid freezing the GUI
        self.is_running = True
        threading.Thread(target=self.run_all_cp2k, args=(xyz_files, cp2k_folder, cp2k_executable, source_folder)).start()

    def run_all_cp2k(self, xyz_files, cp2k_folder, cp2k_executable, source_folder):
        """Create a SLURM array job to run CP2K for multiple .xyz files."""
        def submit_job():
            try:
                # Create a file listing all the xyz files
                xyz_list_file = os.path.join(cp2k_folder, "xyz_file_list.txt")
                with open(xyz_list_file, "w") as f:
                    for xyz_file in xyz_files:
                        f.write(f"{xyz_file}\n")
                
                # Create the SLURM batch script for the array job
                slurm_script_path = os.path.join(cp2k_folder, "cp2k_array_job.sh")
                with open(slurm_script_path, "w") as slurm_script:
                    slurm_script.write(f"""#!/bin/bash
#SBATCH --job-name=AIASSE
#SBATCH --partition=long
#SBATCH --time=7-00:00:00
#SBATCH --ntasks=48
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --array=0-{len(xyz_files)-1}  # Job array index based on number of xyz files

# Get the xyz file for this array task
xyz_file=$(sed -n "${{SLURM_ARRAY_TASK_ID}}p" {xyz_list_file})
base_name=$(basename ${{xyz_file}} .xyz)

# Create output folder for this job
output_folder={cp2k_folder}/$base_name
mkdir -p $output_folder

# Set SLURM output and error files in the job folder
#SBATCH --output=$output_folder/%A_%a_DFT.output
#SBATCH --error=$output_folder/%A_%a_DFT.error

# Load CP2K module

# Copy static files
cp {cp2k_folder}/GTH_POTENTIALS $output_folder
cp {cp2k_folder}/dftd3.dat $output_folder
cp {cp2k_folder}/BASIS_MOLOPT $output_folder

# Create input file by replacing the XYZ file in the template
input_file=$output_folder/${{base_name}}_aiasse.inp
sed "s|COORD_FILE_NAME.*|COORD_FILE_NAME {source_folder}/${{xyz_file}}|" {cp2k_folder}/aiasse.inp > $input_file

# Run CP2K
cd $output_folder
srun {cp2k_executable} -in $input_file > $output_folder/${{base_name}}_DFT.output
""")
            
                submit_command = f"sbatch {slurm_script_path}"
                result = subprocess.run(submit_command, shell=True, check=True)
                self.update_output_signal.emit(f"Submitted SLURM array job for {len(xyz_files)} XYZ files.")
            except subprocess.CalledProcessError as e:
                self.update_output_signal.emit(f"SLURM job submission failed: {e}")
            except Exception as e:
                self.update_output_signal.emit(f"Unexpected error occurred: {e}")

        submission_thread = threading.Thread(target=submit_job)
        submission_thread.start()

    def setup_castep(self):
        # Define the source and destination paths
        source_folder = os.path.join(os.getcwd(), "src", "Accumulation_dependence")
        destination_folder = os.path.join(os.getcwd(), "Results", "CASTEP", "DFT box")
        
        castep_folder = os.path.join(os.getcwd(), "Results", "CASTEP")
        if not os.path.exists(castep_folder):
            os.makedirs(castep_folder)
            self.outputTextEdit.append("CASTEP folder created.")
        
        # Step 2: Check if source folder exists
        if os.path.exists(source_folder):
            # Step 3: Copy and rename the Accumulation_dependence folder to DFT box
            shutil.copytree(source_folder, destination_folder)
            self.outputTextEdit.append(f"Accumulation_dependence folder copied and renamed to {destination_folder}.")
        else:
            self.outputTextEdit.append("Source folder Accumulation_dependence does not exist.")

    def __init__(self):
        super(Ui_MainWindow, self).__init__()
        
        # Initialize the necessary paths
        self.results_folder = os.path.join(os.getcwd(), "Results")
        self.cp2k_directory = os.path.join(self.results_folder, "CP2K")
        self.aiasse_plots_folder = os.path.join(self.results_folder, "AIASSE_Plots")
        self.large_box_folder = os.path.join(self.results_folder, "Large_box", "Large", "Accumulation_dependence")
        
        # Initialize the plot canvas and output text edit
        self.current_plot_canvas = None
        self.rdf_canvas = None
        self.cn_canvas1 = None
        self.cn_canvas2 = None
        self.entropy_canvas = None
        self.outputTextEdit = None  # Assume this is set up elsewhere
        
        # Ensure the necessary directories are created
        self.ensure_directories()

    def ensure_directories(self):
        """Ensure the necessary directories are created."""
        os.makedirs(self.aiasse_plots_folder, exist_ok=True)
        os.makedirs(self.large_box_folder, exist_ok=True)
        os.makedirs(self.cp2k_directory, exist_ok=True)

    def remove_previous_plot(self):
        """Remove the current plot from the layout."""
        if self.current_plot_canvas:
            self.gridLayout.removeWidget(self.current_plot_canvas)
            self.current_plot_canvas.deleteLater()
            self.current_plot_canvas = None

    def save_plot_to_folder(self, fig, plot_name):
        """Save the plot figure to a designated folder."""
        save_path = os.path.join(self.aiasse_plots_folder, f"{plot_name}.png")
        fig.savefig(save_path)
        self.outputTextEdit.append(f"Plot saved to: {save_path}")

    def update_canvas(self, fig, plot_name):
        """Update the display canvas with the provided figure."""
        self.remove_previous_plot()  # Remove current plot if it exists
        self.current_plot_canvas = FigureCanvas(fig)
        self.gridLayout.addWidget(self.current_plot_canvas, 1, 0, 1, 1)
        self.save_plot_to_folder(fig, plot_name)
        self.gridLayout.update()
        self.outputTextEdit.append(f"{plot_name} displayed successfully.")

    def show_error_dialog(self, message):
        """Display an error dialog with the provided message."""
        QMessageBox.critical(self, "Error", message)

    def plot_rdf(self):
        """Generate and display the RDF plot."""
        try:
            # Ensure that the large_box_folder path is valid
            if not hasattr(self, 'large_box_folder') or not os.path.exists(self.large_box_folder):
                self.show_error_dialog("Large_box folder does not exist!")
                return
            
            # Assuming plot_rdf_gr() is defined elsewhere and correctly handles the directory
            fig = plot_rdf_gr(directory=self.large_box_folder)
            self.update_canvas(fig, "RDF_Plot")
        except Exception as e:
            self.show_error_dialog(f"Error displaying RDF plot: {e}")

    def plot_cn(self):
        """Generate and display the Coordination Number plots."""
        try:
            bonded, ok = QInputDialog.getItem(self.centralWidget, "Select Bonding Type",
                                              "Choose bonding type:", ["Bonded", "Non-Bonded"], 0, False)
            if ok and bonded:
                # Assuming plot_cn() is defined elsewhere and correctly handles the directory
                fig1, fig2 = plot_cn(directory=self.large_box_folder)
                self.update_canvas(fig1, "CN_Peaks")
                self.update_canvas(fig2, "CN_Plot")
        except Exception as e:
            self.show_error_dialog(f"Error displaying CN plots: {e}")

    def plot_excess_entropy(self):
        """Generate and display the Excess Entropy plot."""
        try:
            file_path = os.path.join(self.results_folder, "Large_box", "Large", "Largebox.ato")
            with open(file_path, 'r') as file:
                lines = file.readlines()
                num_atoms = int(re.match(r'^\s*(\d+)', lines[0]).group(1))
                cell_length = float(re.match(r'^\s*\d+\s+([\d\.E+-]+)', lines[0]).group(1))
                num_bonds = int(re.match(r'^\s*(\d+)', lines[2]).group(1))
                total_atoms = num_atoms * num_bonds
            # Assuming plot_excess_entropy() is defined elsewhere and correctly handles the directory
            fig = plot_excess_entropy(directory=self.large_box_folder, num_atoms=total_atoms, cell_length=cell_length)
            self.update_canvas(fig, "Excess_Entropy_Plot")
        except Exception as e:
            self.show_error_dialog(f"Error displaying entropy plot: {e}")

    def plot_local_structure(self):
        """Generate and display the local structure plot."""
        try:
            directory_path = os.path.join(self.large_box_folder, "DFT_box")
            self.ensure_scripts_in_directory(directory_path)
            # Assuming plot_local_structure() is defined elsewhere and correctly handles the directory
            fig = plot_local_structure(directory_path)
            self.update_canvas(fig, "Local_Structure_Plot")
        except Exception as e:
            self.show_error_dialog(f"Error displaying local structure plot: {e}")

    def ensure_scripts_in_directory(self, directory_path):
        """Ensure necessary scripts are copied to the target directory."""
        atom_array_source_path = os.path.join(os.getcwd(), "src", "atom_array.py")
        lammps_reader_source_path = os.path.join(os.getcwd(), "src", "lammps_reader.py")
        
        # Copy the files to the target directory if needed
        if not os.path.exists(os.path.join(directory_path, "atom_array.py")):
            shutil.copy2(atom_array_source_path, directory_path)
            print(f"Copied atom_array.py to {directory_path}")
        
        if not os.path.exists(os.path.join(directory_path, "lammps_reader.py")):
            shutil.copy2(lammps_reader_source_path, directory_path)
            print(f"Copied lammps_reader.py to {directory_path}")

    def calculate_new_bond_length(self):
        """Run bond length calculation using imported functions."""
        try:
            self.outputTextEdit.append("Please be patient, bond length calculation ongoing...")
            cp2k_directory = os.path.join(self.results_folder, "CP2K")
            
            if not os.path.exists(cp2k_directory):
                self.outputTextEdit.append(f"CP2K directory not found: {cp2k_directory}")
                return

            box_size = 20.565067  # Example box size for bond length calculation
            dr = 0.05  # Example dr for bond length calculation

            # Create the bond length calculator object
            self.bond_length_calculator = BondLengthCalculator(cp2k_directory, box_size, dr)

            # Connect signals for logging and plotting
            self.bond_length_calculator.log_signal.connect(self.append_to_output)
            self.bond_length_calculator.bond_length_figures_signal.connect(self.show_bond_length_plot_on_gui, Qt.QueuedConnection)

            # Create a thread for running the calculation
            self.bond_length_thread = QThread()
            self.bond_length_calculator.moveToThread(self.bond_length_thread)

            # Start the calculation when the thread starts
            self.bond_length_thread.started.connect(self.bond_length_calculator.calculate_bond_length)

            # Start the thread
            self.bond_length_thread.start()

        except Exception as e:
            self.outputTextEdit.append(f"Error occurred during bond length calculation setup: {e}")

    def show_bond_length_plot_on_gui(self, bond_length_figures):
        """Display the given plot figures for bond lengths in the GUI."""
        if hasattr(self, 'bond_length_canvas'):
            self.gridLayout.removeWidget(self.bond_length_canvas)
            self.bond_length_canvas.deleteLater()

        for fig in bond_length_figures:
            if isinstance(fig, tuple):  # Ensure only a Figure object is passed
                fig = fig[0]
            self.bond_length_canvas = FigureCanvas(fig)
            self.gridLayout.addWidget(self.bond_length_canvas, 1, 0, 1, 1)
            self.gridLayout.update()

        self.outputTextEdit.append("Bond length plot(s) displayed successfully.")

    def calculate_new_bond_angle(self):
        """Run bond angle calculation using imported functions."""
        try:
            self.outputTextEdit.append("Please be patient, bond angle calculation ongoing...")
            cp2k_directory = os.path.join(self.results_folder, "CP2K")
            
            if not os.path.exists(cp2k_directory):
                self.outputTextEdit.append(f"CP2K directory not found: {cp2k_directory}")
                return

            box_size = 20.565067  # Example box size for bond angle calculation
            dr = 0.01  # Example dr for bond angle calculation

            # Create the bond angle calculator object
            self.bond_angle_calculator = BondAngleCalculator(cp2k_directory, box_size, dr)

            # Connect signals for logging and plotting
            self.bond_angle_calculator.log_signal.connect(self.append_to_output)
            self.bond_angle_calculator.bond_angle_figures_signal.connect(self.show_bond_angle_plot_on_gui, Qt.QueuedConnection)

            # Create a thread for running the calculation
            self.bond_angle_thread = QThread()
            self.bond_angle_calculator.moveToThread(self.bond_angle_thread)

            # Start the calculation when the thread starts
            self.bond_angle_thread.started.connect(self.bond_angle_calculator.calculate_bond_angle)

            # Start the thread
            self.bond_angle_thread.start()

        except Exception as e:
            self.outputTextEdit.append(f"Error occurred during bond angle calculation setup: {e}")

    def show_bond_angle_plot_on_gui(self, bond_angle_figures):
        """Display the given plot figures for bond angles in the GUI."""
        if hasattr(self, 'bond_angle_canvas'):
            self.gridLayout.removeWidget(self.bond_angle_canvas)
            self.bond_angle_canvas.deleteLater()

        for fig in bond_angle_figures:
            if isinstance(fig, tuple):  # Ensure only a Figure object is passed
                fig = fig[0]
            self.bond_angle_canvas = FigureCanvas(fig)
            self.gridLayout.addWidget(self.bond_angle_canvas, 1, 0, 1, 1)
            self.gridLayout.update()

        self.outputTextEdit.append("Bond angle plot(s) displayed successfully.")

    def updating_large_box(self):
        """Updates the Large.mol file with new bond length and modifies update.sh for running."""
        
        mean_bond_length = self.calculate_mean_bond_length()
        
        if mean_bond_length is None:
            print("Could not retrieve mean bond length.")
            return
        
        # Paths to Large.mol and related files in the Results folder
        large_mol_path = os.path.join(self.large_folder, "Large.mol")
        new_shell_script_path = os.path.join(self.src_folder, "update.sh")
        home_epsr25_path = os.path.join(self.src_folder, "epsr25")  # Path to epsr25 in src folder
        destination_epsr25_path = os.path.join(self.large_folder, "epsr25")  # Destination path in Large folder
        destination_shell_script_path = os.path.join(self.large_folder, "update.sh")
        epsr_inp_path = os.path.join(self.large_folder, "Largebox.EPSR.inp")

        # Step 1: Delete all files except the specified ones and rename Accumulation_dependence to iteration_1
        self.clean_large_directory(self.large_folder)

        # Update Large.mol file with new bond length
        try:
            if os.path.exists(large_mol_path):
                with open(large_mol_path, 'r') as mol_file:
                    mol_content = mol_file.readlines()

                # Modify line 4
                if len(mol_content) >= 4:
                    parts = mol_content[3].split()
                    if len(parts) >= 4:
                        parts[3] = f"{mean_bond_length:.5f}"
                        mol_content[3] = "    ".join(parts) + "\n"

                        # Write changes to the file
                        with open(large_mol_path, 'w') as mol_file:
                            mol_file.writelines(mol_content)
                else:
                    print("Large.mol file has insufficient lines.")
                    return

            else:
                print("Large.mol file not found.")
                return  # Exit if the file doesn't exist

            # Step 2: Modify Largebox.EPSR.inp file
            self.modify_LB_update_inp(epsr_inp_path)

            # Copy epsr25 to the destination directory
            shutil.copy2(home_epsr25_path, destination_epsr25_path)
            print(f"Copied epsr25 to {destination_epsr25_path}")
            shutil.copy2(new_shell_script_path, destination_shell_script_path)
            print(f"Copied update.sh to {destination_shell_script_path}")

            # Verify the shell script was copied successfully
            if not os.path.exists(destination_shell_script_path):
                print(f"Error: The specified shell script {destination_shell_script_path} was not found after copying.")
                return
            else:
                print(f"Confirmed: {destination_shell_script_path} exists.")

            # Run the shell script in a new thread
            thread = threading.Thread(target=self.run_update_script, args=(destination_shell_script_path, self.large_folder))
            thread.start()

        except Exception as e:
            print(f"Error occurred: {e}")

    def clean_large_directory(self, directory_path):
        """Deletes all files in the directory except the specified files based on extensions and renames Accumulation_dependence to iteration_1."""
        
        # Define allowed file extensions
        allowed_extensions = {".mint01", ".wts", ".ato", ".pro", ".jmol", ".mol", ".inp"}
        
        # Create a set to hold files to keep based on their extensions
        files_to_keep = set()
        
        # Populate files_to_keep based on the directory contents and allowed extensions
        for filename in os.listdir(directory_path):
            if any(filename.endswith(ext) for ext in allowed_extensions):
                files_to_keep.add(filename)

        # Define paths for accumulation_dependence and iteration_1
        accumulation_dependence_path = os.path.join(directory_path, "Accumulation_dependence")
        iteration_1_path = os.path.join(directory_path, "iteration_1")

        # Rename Accumulation_dependence to iteration_1 if it exists
        if os.path.exists(accumulation_dependence_path):
            if os.path.exists(iteration_1_path):
                print(f"Removing existing directory: {iteration_1_path}")
                shutil.rmtree(iteration_1_path)  # Remove existing iteration_1 if it exists
            os.rename(accumulation_dependence_path, iteration_1_path)
            print(f"Renamed {accumulation_dependence_path} to {iteration_1_path}")

        # Now, delete the other files and directories
        for filename in os.listdir(directory_path):
            file_path = os.path.join(directory_path, filename)
            if filename not in files_to_keep and file_path != iteration_1_path:
                try:
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                        print(f"Deleted {file_path}")
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                        print(f"Deleted directory {file_path}")
                except Exception as e:
                    print(f"Error deleting {file_path}: {e}")

    def modify_LB_update_inp(self, epsr_inp_path):
        """Modifies the Largebox.EPSR.inp file to set nsumt to -1."""
        try:
            if os.path.exists(epsr_inp_path):
                with open(epsr_inp_path, 'r') as inp_file:
                    inp_content = inp_file.readlines()

                # Modify the line containing nsumt
                for i in range(len(inp_content)):
                    if 'nsumt' in inp_content[i]:
                        parts = inp_content[i].split()
                        if len(parts) > 1:
                            parts[1] = '-1'  # Set the second part to -1
                            inp_content[i] = " ".join(parts) + "\n"
                        break  # Stop after modifying the first occurrence

                # Write changes to the file
                with open(epsr_inp_path, 'w') as inp_file:
                    inp_file.writelines(inp_content)
                print(f"Modified {epsr_inp_path} to set nsumt to -1.")
            else:
                print("Largebox.EPSR.inp file not found.")
        except Exception as e:
            print(f"Error modifying Largebox.EPSR.inp: {e}")

    def run_update_script(self, destination_shell_script_path, cwd):
        """Runs the update script in a separate thread to avoid GUI freezing."""
        try:
            print(f"Running shell script: {destination_shell_script_path} in directory {cwd}")
            
            # Ensure the script is executable
            os.chmod(destination_shell_script_path, 0o755)  # Set executable permission
            print(f"Set executable permissions for {destination_shell_script_path}")

            # Print current working directory for debugging
            print(f"Current working directory for running script: {cwd}")
            
            # Print the absolute path of the script
            abs_script_path = os.path.abspath(destination_shell_script_path)
            print(f"Absolute path of the script: {abs_script_path}")

            subprocess.run(["expect", abs_script_path], check=True, cwd=cwd)
            print("Shell script executed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Shell script error: {e}")
        except FileNotFoundError:
            print(f"Error: The specified script {destination_shell_script_path} was not found.")
        except Exception as e:
            print(f"Unexpected error while running shell script: {e}")

    def calculate_mean_bond_length(self):
        """Reads the mean bond length from New_bond_length_and_angle.txt."""
        file_path = os.path.join(os.getcwd(), "New_bond_length_and_angle.txt")

        try:
            with open(file_path, 'r') as file:
                lines = file.readlines()

                if len(lines) < 2:
                    print("The file does not contain sufficient data.")
                    return None
                
                # Skip the header and go to the last data line
                last_line = lines[-1].strip()
                parts = last_line.split()
                
                if len(parts) >= 3:  # Ensure that there are at least three elements
                    mean_bond_length = float(parts[1])  # Assuming the 2nd column is mean_bond_length
                    print(f"Mean bond length obtained: {mean_bond_length:.5f}")
                    return mean_bond_length
                else:
                    print("Unexpected file format.")
                    return None
        except Exception as e:
            print(f"Error reading mean bond length: {e}")
            return None

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
