# AIASSE version 1.0

Disordered structures can be characterised using neutron or X-ray scattering techniques through diffraction experiments.

Aim: Combine first-principles quantum mechanical calculations using ab initio molecular dynamics (AIMD) with RMC refinement of diffraction data.

Ab initio Augmented Structure Solving Engine: AIASSE structure

==> EPSR operates independently of first-principles quantum mechanical calculations, such as those facilitated by Density Functional Theory (DFT). While classical potentials may fall short in accurately describing materials, quantum mechanical solutions, which are widely understood, offer significantly more precise depictions. Nonetheless, the effectiveness of quantum mechanical calculations is constrained by the scale and duration of the simulations.

==> AIASSE aims to combine ab initio molecular dynamics (AIMD) simulation via DFT codes like CASTEP/CP2K/VASP with Reverse Monte Carlo(RMC) refinement of diffraction data.

AIASSE Application

Simple liquid: Shock compressed metals, Supercritical fluids, Frenkel line and quantum effects
Glasses: Metallic Glasses, Topologies of mixed H-bond networks, Highly disordered solids
Liquid mixtures:Light fluid mixtures, Geophysical melts, Hydrocarbon mixtures (fuels)
Biomolecules in solution: Molecular drug design, Pharmaceuticals in fluid medium, In situ biochemical activity

# AIASSE Application Setup

Ensure the `EPSRgui` executable is installed and accessible. The application will automatically search for it in the system PATH and the following common directories:

- `~/EPSR/EPSRgui-master/`
- `/usr/local/bin/`
- `/usr/bin/`
- `/bin/`

If `EPSRgui` is not found, please install it in one of these directories or add its location to your system PATH.

## Running the Application

To start the application, run:

```sh
python3 epsr.py

Ensure the latest python3 version is installed. 

